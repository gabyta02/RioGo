from typing import Literal

from pydantic import BaseModel, Field

AlcanceAplicado = Literal["todos", "categoria", "subcategoria", "ids_candidatos"]


class CategoriaSubcategoriaRequest(BaseModel):
    categoria: str | None = None
    subcategoria: str | None = None
    excluir_categorias: list[str] = Field(default_factory=list)
    ids_sitios_candidatos: list[int] = Field(default_factory=list)


class SitioCategoriaItem(BaseModel):
    id_sitio: int
    nombre: str


class CategoriaSubcategoriaResponse(BaseModel):
    ok: bool
    total: int
    ids_sitios: list[int] = Field(default_factory=list)
    sitios: list[SitioCategoriaItem] = Field(default_factory=list)
    alcance_aplicado: AlcanceAplicado = "todos"
    categoria_resuelta: str | None = None
    subcategoria_resuelta: str | None = None
    ids_sitios_candidatos_aplicados: list[int] = Field(default_factory=list)
    excluir_categorias_aplicadas: list[str] = Field(default_factory=list)
    tiempo_ms: float
    mensaje: str


class BusquedaAproximadaRequest(BaseModel):
    direccion_referencia: str = Field(min_length=1, max_length=300)
    excluir: list[str] = Field(default_factory=list)
    categoria: str | None = None
    subcategoria: str | None = None
    ids_sitios_candidatos: list[int] = Field(default_factory=list)


class CandidatoSitioDebugItem(BaseModel):
    id_sitio: int
    nombre: str
    direccion_texto: str
    score: float
    score_trgm: float
    score_rapidfuzz: float
    similitud_porcentaje: float
    campo_match: Literal["direccion_texto", "referencia_adicional"]
    descartado_por_exclusion: bool = False


class SitioBusquedaAproximadaItem(BaseModel):
    id_sitio: int
    nombre: str
    direccion_texto: str
    referencia_adicional: str | None = None


class BusquedaAproximadaResponse(BaseModel):
    ok: bool
    direccion_referencia_consultada: str
    texto_sin_prefijos_via: str = ""
    tipo_resultado: Literal["sitio", "parroquia", "plataforma", "ninguno"]
    fuente: Literal["direccion", "parroquia", "plataforma", "ninguna"]
    ids_sitios: list[int] = Field(default_factory=list)
    sitios: list[SitioBusquedaAproximadaItem] = Field(default_factory=list)
    nombre: str | None = None
    alcance_aplicado: AlcanceAplicado = "todos"
    categoria_resuelta: str | None = None
    subcategoria_resuelta: str | None = None
    ids_sitios_candidatos_aplicados: list[int] = Field(default_factory=list)
    excluir_aplicado: list[str] = Field(default_factory=list)
    top_sitios_direccion: list[CandidatoSitioDebugItem] = Field(default_factory=list)
    tiempo_ms: float
    mensaje: str


class CamposParametrizadosRequest(BaseModel):
    tiene_wifi: bool | None = None
    permite_mascotas: bool | None = None
    accesibilidad: bool | None = None
    parqueadero: bool | None = None
    es_gratuito: bool | None = None
    excluir: list[str] = Field(default_factory=list)
    categoria: str | None = None
    subcategoria: str | None = None
    ids_sitios_candidatos: list[int] = Field(default_factory=list)


class SitioCampoParamItem(BaseModel):
    id_sitio: int
    nombre: str
    tiene_wifi: bool | None = None
    permite_mascotas: bool | None = None
    accesibilidad: bool | None = None
    parqueadero: bool | None = None
    es_gratuito: bool | None = None


class CamposParametrizadosResponse(BaseModel):
    ok: bool
    total: int
    ids_sitios: list[int] = Field(default_factory=list)
    sitios: list[SitioCampoParamItem] = Field(default_factory=list)
    filtros_aplicados: dict[str, bool] = Field(default_factory=dict)
    alcance_aplicado: AlcanceAplicado = "todos"
    categoria_resuelta: str | None = None
    subcategoria_resuelta: str | None = None
    ids_sitios_candidatos_aplicados: list[int] = Field(default_factory=list)
    excluir_aplicado: list[str] = Field(default_factory=list)
    tiempo_ms: float
    mensaje: str


class ContactosRequest(BaseModel):
    contacto_sugerido: str = Field(min_length=1, max_length=100)
    excluir_contactos: list[str] = Field(default_factory=list)
    categoria: str | None = None
    subcategoria: str | None = None
    ids_sitios_candidatos: list[int] = Field(default_factory=list)


class ContactoItem(BaseModel):
    tipo: str
    contenido: str


class SitioContactoItem(BaseModel):
    id_sitio: int
    nombre: str
    tiene_contacto_sugerido: bool
    contactos: list[ContactoItem] = Field(default_factory=list)


class ContactosResponse(BaseModel):
    ok: bool
    contacto_sugerido: str
    contacto_sugerido_resuelto: str | None = None
    ids_sitios: list[int] = Field(default_factory=list)
    sitios: list[SitioContactoItem] = Field(default_factory=list)
    alcance_aplicado: AlcanceAplicado = "todos"
    categoria_resuelta: str | None = None
    subcategoria_resuelta: str | None = None
    ids_sitios_candidatos_aplicados: list[int] = Field(default_factory=list)
    excluir_contactos_aplicados: list[str] = Field(default_factory=list)
    tipos_contacto_excluidos: list[str] = Field(default_factory=list)
    tiempo_ms: float
    mensaje: str


TipoHorario = Literal[
    "ninguno",
    "abierto_ahora",
    "atiende_dia",
    "abierto_en_hora",
    "abierto_en_rango",
    "abierto_24h",
]
ComparadorHorario = Literal["exacto", "antes_de", "despues_de"]


class RangoHoraRequest(BaseModel):
    inicio: str | None = None
    fin: str | None = None


class HorarioRequest(BaseModel):
    tipo: TipoHorario = "ninguno"
    dia_semana: str | int | None = None
    hora: str | None = None
    rango_hora: RangoHoraRequest = Field(default_factory=RangoHoraRequest)
    comparador: ComparadorHorario | None = None
    meridiano: Literal["AM", "PM"] | None = None
    excluir_dias: list[str | int] = Field(default_factory=list)
    categoria: str | None = None
    subcategoria: str | None = None
    ids_sitios_candidatos: list[int] = Field(default_factory=list)


class HorarioDetalleItem(BaseModel):
    dia_semana: int
    hora_inicio: str
    hora_fin: str


class SitioHorarioItem(BaseModel):
    id_sitio: int
    nombre: str
    abierto_24h: bool = False
    detalles: list[HorarioDetalleItem] = Field(default_factory=list)


class HorarioResponse(BaseModel):
    ok: bool
    total: int
    ids_sitios: list[int] = Field(default_factory=list)
    sitios: list[SitioHorarioItem] = Field(default_factory=list)
    tipo_aplicado: TipoHorario = "ninguno"
    dia_semana_resuelto: int | None = None
    hora_resuelta: str | None = None
    rango_hora_aplicado: dict[str, str | None] = Field(default_factory=dict)
    filtros_aplicados: dict = Field(default_factory=dict)
    alcance_aplicado: AlcanceAplicado = "todos"
    categoria_resuelta: str | None = None
    subcategoria_resuelta: str | None = None
    ids_sitios_candidatos_aplicados: list[int] = Field(default_factory=list)
    excluir_dias_aplicados: list[int] = Field(default_factory=list)
    tiempo_ms: float
    mensaje: str


OperadorPrecio = Literal["min", "max", "exacto"]
EtiquetaPrecio = Literal["economico", "medio", "alto", "desconocido"]


class PrecioRequest(BaseModel):
    precio_numero: float | None = None
    operador: OperadorPrecio | None = None
    etiqueta: str | None = None
    excluir_etiquetas: list[str] = Field(default_factory=list)
    categoria: str | None = None
    subcategoria: str | None = None
    ids_sitios_candidatos: list[int] = Field(default_factory=list)


class SitioPrecioItem(BaseModel):
    id_sitio: int
    nombre: str
    fuente_precio: Literal["tarifa_acceso", "rango_precio"] | None = None
    precio_min: float
    precio_max: float
    etiqueta_precio: str | None = None


class PrecioResponse(BaseModel):
    ok: bool
    total: int
    ids_sitios: list[int] = Field(default_factory=list)
    sitios: list[SitioPrecioItem] = Field(default_factory=list)
    etiqueta_resuelta: str | None = None
    operador_aplicado: OperadorPrecio | None = None
    precio_numero_aplicado: float | None = None
    filtros_aplicados: dict = Field(default_factory=dict)
    alcance_aplicado: AlcanceAplicado = "todos"
    categoria_resuelta: str | None = None
    subcategoria_resuelta: str | None = None
    ids_sitios_candidatos_aplicados: list[int] = Field(default_factory=list)
    excluir_etiquetas_aplicadas: list[str] = Field(default_factory=list)
    tiempo_ms: float
    mensaje: str


class TarifaAccesoRequest(BaseModel):
    precio_numero: float | None = None
    operador: OperadorPrecio | None = None
    etiqueta: str | None = None
    condicion: str | None = None
    excluir_condiciones: list[str] = Field(default_factory=list)
    categoria: str | None = None
    subcategoria: str | None = None
    ids_sitios_candidatos: list[int] = Field(default_factory=list)


class SitioTarifaAccesoItem(BaseModel):
    id_sitio: int
    nombre: str
    fuente_precio: Literal["tarifa_acceso", "rango_precio"]
    precio: float
    precio_min: float | None = None
    precio_max: float | None = None
    condicion: str | None = None
    etiqueta_precio: str


class TarifaAccesoResponse(BaseModel):
    ok: bool
    total: int
    ids_sitios: list[int] = Field(default_factory=list)
    sitios: list[SitioTarifaAccesoItem] = Field(default_factory=list)
    etiqueta_resuelta: str | None = None
    operador_aplicado: OperadorPrecio | None = None
    precio_numero_aplicado: float | None = None
    condicion_resuelta: str | None = None
    filtros_aplicados: dict = Field(default_factory=dict)
    alcance_aplicado: AlcanceAplicado = "todos"
    categoria_resuelta: str | None = None
    subcategoria_resuelta: str | None = None
    ids_sitios_candidatos_aplicados: list[int] = Field(default_factory=list)
    excluir_condiciones_aplicadas: list[str] = Field(default_factory=list)
    tiempo_ms: float
    mensaje: str


class RutaRequest(BaseModel):
    tipo_ruta: str = Field(min_length=1, max_length=100)
    excluir_tipos: list[str] = Field(default_factory=list)
    ids_rutas_candidatos: list[int] = Field(default_factory=list)


class RutaItem(BaseModel):
    id_ruta: int
    titulo: str
    tipo_ruta: str


class RutaResponse(BaseModel):
    ok: bool
    total: int
    ids_rutas: list[int] = Field(default_factory=list)
    rutas: list[RutaItem] = Field(default_factory=list)
    tipo_ruta_consultado: str
    tipo_ruta_resuelto: str | None = None
    filtros_aplicados: dict = Field(default_factory=dict)
    excluir_tipos_aplicados: list[str] = Field(default_factory=list)
    tipos_ruta_excluidos: list[str] = Field(default_factory=list)
    ids_rutas_candidatos_aplicados: list[int] = Field(default_factory=list)
    tiempo_ms: float
    mensaje: str


class GisRequest(BaseModel):
    usar_ubicacion_usuario: bool = False
    distancia: float | None = None
    unidad: Literal["m", "km"] | None = None
    punto_referencia: str | None = None
    excluir_zonas: list[str] = Field(default_factory=list)
    categoria: str | None = None
    subcategoria: str | None = None
    ids_sitios_candidatos: list[int] = Field(default_factory=list)


class SitioGisItem(BaseModel):
    id_sitio: int
    nombre: str
    distancia_metros: float
    latitud: float
    longitud: float


class GisResponse(BaseModel):
    ok: bool
    total: int
    ids_sitios: list[int] = Field(default_factory=list)
    sitios: list[SitioGisItem] = Field(default_factory=list)
    punto_origen_lat: float | None = None
    punto_origen_lon: float | None = None
    punto_origen_fuente: Literal["usuario", "bd", "nominatim", "ninguno"] = "ninguno"
    punto_origen_nombre: str | None = None
    radio_busqueda_metros: float
    radio_expandido: bool = False
    radios_intentados_metros: list[float] = Field(default_factory=list)
    gis_fallback_mapa: bool = False
    filtros_aplicados: dict = Field(default_factory=dict)
    alcance_aplicado: AlcanceAplicado = "todos"
    categoria_resuelta: str | None = None
    subcategoria_resuelta: str | None = None
    ids_sitios_candidatos_aplicados: list[int] = Field(default_factory=list)
    excluir_zonas_aplicadas: list[str] = Field(default_factory=list)
    tiempo_ms: float
    mensaje: str


class BusquedaSemanticaRequest(BaseModel):
    texto_embeddings: str = Field(min_length=1, max_length=1000)
    posibles_match: list[str] = Field(default_factory=list)
    excluir_terminos: list[str] = Field(default_factory=list)
    categoria: str | None = None
    subcategoria: str | None = None
    ids_sitios_candidatos: list[int] = Field(default_factory=list)


class SitioSemanticoItem(BaseModel):
    id_sitio: int
    nombre: str
    score_similitud: float
    score_embedding: float
    score_palabras_clave: float
    titulo_chunk: str
    contenido_chunk: str
    palabras_clave_match: list[str] = Field(default_factory=list)


class CandidatoSemanticoDebugItem(SitioSemanticoItem):
    supera_umbral: bool
    similitud_porcentaje: float
    motivo: str


class BusquedaSemanticaResponse(BaseModel):
    ok: bool
    total: int
    ids_sitios: list[int] = Field(default_factory=list)
    sitios: list[SitioSemanticoItem] = Field(default_factory=list)
    top_sitios_semantica: list[CandidatoSemanticoDebugItem] = Field(default_factory=list)
    filtros_aplicados: dict = Field(default_factory=dict)
    alcance_aplicado: AlcanceAplicado = "todos"
    categoria_resuelta: str | None = None
    subcategoria_resuelta: str | None = None
    ids_sitios_candidatos_aplicados: list[int] = Field(default_factory=list)
    excluir_terminos_aplicados: list[str] = Field(default_factory=list)
    posibles_match_aplicados: list[str] = Field(default_factory=list)
    umbral_minimo: float = 0.70
    tiempo_ms: float
    mensaje: str


class HerramientaPlan(BaseModel):
    herramienta: str
    ubicacion_usuario: dict[str, float] | None = None
    grupo: str | None = None
    rama: str | None = None
    orden: int
    parametros: dict


class EjecutarPlanRequest(BaseModel):
    tipo_ejecucion: Literal["secuencial", "paralelo"] = "secuencial"
    client_mensaje_id: str | None = None
    herramientas: list[HerramientaPlan]


class TarjetaSitio(BaseModel):
    id_sitio: int
    nombre: str
    subcategoria: str | None = None
    imagen: str | None = None
    contacto: dict | None = None
    precio: dict | None = None
    direccion: str | None = None
    campos_dinamicos: dict = Field(default_factory=dict)


class TarjetaRuta(BaseModel):
    id_ruta: int
    titulo: str
    tipo_ruta: str
    campos_dinamicos: dict = Field(default_factory=dict)


class EjecutarPlanResponse(BaseModel):
    ok: bool
    client_mensaje_id: str | None = None
    tarjetas: list[TarjetaSitio] = Field(default_factory=list)
    tarjetas_rutas: list[TarjetaRuta] = Field(default_factory=list)
    sitios_relacionados: list[int] = Field(default_factory=list)
    candidatos_semanticos: list[CandidatoSemanticoDebugItem] = Field(default_factory=list)
    semantic_fallback_aplicado: bool = False
    gis_fallback_mapa_aplicado: bool = False
    filtro_passthrough_aplicado: bool = False
    gis_alcance_passthrough_aplicado: bool = False
    retroalimentacion_semantica_gis: str | None = None
    recomendacion_fallback_aplicado: bool = False
    recomendacion_turistica: str | None = None
    sugerencias_exploracion: list[str] = Field(default_factory=list)
    tiempo_ms: float
    mensaje: str
