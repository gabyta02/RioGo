import json
import sys
from pathlib import Path

import pytest

APIS_ROOT = Path(__file__).resolve().parents[1]
if str(APIS_ROOT) not in sys.path:
    sys.path.insert(0, str(APIS_ROOT))

from servicios.exploracion_fallback import (
    MENSAJE_FALLBACK_FRIO,
    construir_mensaje_recomendacion,
    debe_aplicar_recomendacion_calida,
    generar_fallback_frio,
)


def _tiene_criterio_precio(_nombre: str, params: dict) -> bool:
    return bool(params.get("etiqueta"))


def test_debe_aplicar_recomendacion_calida_precio() -> None:
    assert debe_aplicar_recomendacion_calida(
        "precio",
        {"etiqueta": "economico"},
        [1, 2, 3],
        [],
        _tiene_criterio_precio,
    )


def test_no_aplica_sin_candidatos_previos() -> None:
    assert not debe_aplicar_recomendacion_calida(
        "precio",
        {"etiqueta": "economico"},
        [],
        [],
        _tiene_criterio_precio,
    )


def test_mensaje_precio_economico_alojamiento() -> None:
    mensaje = construir_mensaje_recomendacion(
        "precio",
        {"etiqueta": "economico"},
        subcategoria="Hotel",
        categoria="Alojamiento",
    )
    assert "económicos" in mensaje
    assert "hospedaje" in mensaje


def test_generar_fallback_frio_prioriza_categoria_inferida() -> None:
    class Paso:
        def __init__(self, parametros: dict):
            self.parametros = parametros

    sugerencias = generar_fallback_frio(
        [
            Paso(
                {
                    "categoria": "Alojamiento",
                    "texto_embeddings": "hostal economico en riobamba",
                    "posibles_match": ["hostal barato"],
                }
            )
        ]
    )
    assert sugerencias[0] == "Alojamiento"
    assert len(sugerencias) >= 4


PLAN_HOSTAL_ECONOMICO = {
    "tipo_ejecucion": "secuencial",
    "herramientas": [
        {
            "herramienta": "categoria_subcategoria",
            "orden": 1,
            "parametros": {
                "categoria": "Alojamiento",
                "subcategoria": "Hotel",
                "excluir_categorias": [],
            },
        },
        {
            "herramienta": "precio",
            "orden": 2,
            "parametros": {
                "precio_numero": None,
                "operador": "min",
                "etiqueta": "economico",
                "excluir_etiquetas": [],
            },
        },
    ],
}

PLAN_SEMANTICA_FRIO = {
    "tipo_ejecucion": "secuencial",
    "herramientas": [
        {
            "herramienta": "busqueda_semantica",
            "orden": 1,
            "parametros": {
                "texto_embeddings": (
                    "xyzqwerty sitio inexistente sin ancla en riobamba 99999"
                ),
                "posibles_match": ["xyzqwerty inexistente"],
                "excluir_terminos": [],
            },
        }
    ],
}


@pytest.mark.integration
def test_ejecutar_plan_recomendacion_hostal_economico() -> None:
    requests = pytest.importorskip("requests")

    respuesta = requests.post(
        "http://127.0.0.1:8000/api/v1/chatboot/ejecutar-plan",
        json=PLAN_HOSTAL_ECONOMICO,
        timeout=120,
    )
    respuesta.raise_for_status()
    data = respuesta.json()

    if data.get("recomendacion_fallback_aplicado"):
        assert data.get("ok") is True
        assert len(data.get("tarjetas", [])) > 0
        assert "económic" in (data.get("recomendacion_turistica") or "").lower()


@pytest.mark.integration
def test_ejecutar_plan_fallback_frio_semantica() -> None:
    requests = pytest.importorskip("requests")

    respuesta = requests.post(
        "http://127.0.0.1:8000/api/v1/chatboot/ejecutar-plan",
        json=PLAN_SEMANTICA_FRIO,
        timeout=120,
    )
    respuesta.raise_for_status()
    data = respuesta.json()

    if not data.get("tarjetas"):
        assert data.get("sugerencias_exploracion")
        assert data.get("mensaje") == MENSAJE_FALLBACK_FRIO
