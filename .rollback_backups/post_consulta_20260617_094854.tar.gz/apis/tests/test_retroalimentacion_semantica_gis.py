import sys
from pathlib import Path

import pytest

APIS_ROOT = Path(__file__).resolve().parents[1]
if str(APIS_ROOT) not in sys.path:
    sys.path.insert(0, str(APIS_ROOT))

from servicios.chatboot import (
    _aplicar_retroalimentacion_semantica_gis_rama,
    _construir_mensaje_retroalimentacion_semantica_gis,
    _extraer_criterio_semantico,
)


def test_extraer_criterio_semantico_prefiere_posibles_match() -> None:
    criterio = _extraer_criterio_semantico(
        {
            "texto_embeddings": "laguna con acceso vehicular",
            "posibles_match": ["acceso en carro", "llegar en vehículo"],
        }
    )
    assert criterio == "acceso en carro"


def test_construir_mensaje_retroalimentacion_laguna() -> None:
    mensaje = _construir_mensaje_retroalimentacion_semantica_gis(
        "acceso en carro",
        "Laguna",
    )
    assert "acceso en carro" in mensaje
    assert "laguna más cercana" in mensaje


def test_aplicar_retroalimentacion_en_campos_dinamicos() -> None:
    campos = {10: {"semantica_sin_coincidencias": True, "gis_fallback_mapa": True}}
    mensaje = _aplicar_retroalimentacion_semantica_gis_rama(
        [10],
        campos,
        "acceso en carro",
        "Laguna",
    )
    assert mensaje is not None
    assert campos[10]["retroalimentacion_turistica"] == mensaje


@pytest.mark.integration
def test_ejecutar_plan_retroalimentacion_semantica_gis() -> None:
    requests = pytest.importorskip("requests")

    plan = {
        "tipo_ejecucion": "secuencial",
        "herramientas": [
            {
                "herramienta": "categoria_subcategoria",
                "orden": 1,
                "parametros": {
                    "categoria": "Atractivos Naturales",
                    "subcategoria": "Laguna",
                    "excluir_categorias": [],
                },
            },
            {
                "herramienta": "busqueda_semantica",
                "orden": 2,
                "parametros": {
                    "texto_embeddings": (
                        "laguna con fácil acceso en vehículo, se puede llegar en carro"
                    ),
                    "posibles_match": [
                        "acceso en carro",
                        "llegar en vehículo",
                        "entrada para autos",
                    ],
                    "excluir_terminos": [],
                },
            },
            {
                "herramienta": "gis",
                "orden": 3,
                "parametros": {
                    "usar_ubicacion_usuario": False,
                    "distancia": None,
                    "unidad": None,
                    "punto_referencia": "Riobamba",
                    "excluir_zonas": [],
                },
            },
        ],
    }

    respuesta = requests.post(
        "http://127.0.0.1:8000/api/v1/chatboot/ejecutar-plan",
        json=plan,
        timeout=120,
    )
    respuesta.raise_for_status()
    data = respuesta.json()

    if data.get("semantic_fallback_aplicado") and data.get(
        "gis_fallback_mapa_aplicado"
    ):
        assert data.get("retroalimentacion_semantica_gis")
        assert "acceso en carro" in data["retroalimentacion_semantica_gis"]
        for tarjeta in data.get("tarjetas", []):
            dinamicos = tarjeta.get("campos_dinamicos") or {}
            if dinamicos.get("semantica_sin_coincidencias") and dinamicos.get(
                "gis_fallback_mapa"
            ):
                assert dinamicos.get("retroalimentacion_turistica")
