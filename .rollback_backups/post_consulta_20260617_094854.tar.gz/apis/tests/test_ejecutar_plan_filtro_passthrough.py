import sys
from pathlib import Path

import pytest

APIS_ROOT = Path(__file__).resolve().parents[1]
if str(APIS_ROOT) not in sys.path:
    sys.path.insert(0, str(APIS_ROOT))

from servicios.chatboot import _tiene_criterio_filtro


@pytest.mark.parametrize(
    ("herramienta", "params", "esperado"),
    [
        ("tarifa_acceso", {"etiqueta": None, "precio_numero": None}, False),
        ("tarifa_acceso", {"etiqueta": "economico", "precio_numero": None}, True),
        ("tarifa_acceso", {"etiqueta": None, "precio_numero": 2.5}, True),
        ("precio", {"etiqueta": None, "precio_numero": None}, False),
        ("precio", {"etiqueta": "medio"}, True),
        ("horario", {"tipo": "ninguno"}, False),
        ("horario", {"tipo": "abierto_ahora"}, True),
        ("horario", {"tipo": "atiende_dia", "dia_semana": "7"}, True),
        ("horario", {"tipo": "atiende_dia", "dia_semana": None}, False),
        ("contactos", {"contacto_sugerido": ""}, False),
        ("contactos", {"contacto_sugerido": "whatsapp"}, True),
        (
            "campos_parametrizados",
            {
                "tiene_wifi": None,
                "permite_mascotas": None,
                "accesibilidad": None,
                "parqueadero": None,
                "es_gratuito": None,
                "excluir": [],
            },
            False,
        ),
        (
            "campos_parametrizados",
            {
                "tiene_wifi": True,
                "permite_mascotas": None,
                "accesibilidad": None,
                "parqueadero": None,
                "es_gratuito": None,
                "excluir": [],
            },
            True,
        ),
    ],
)
def test_tiene_criterio_filtro(
    herramienta: str,
    params: dict,
    esperado: bool,
) -> None:
    assert _tiene_criterio_filtro(herramienta, params) is esperado


PLAN_MUSEO_SEMANTICA = {
    "tipo_ejecucion": "secuencial",
    "herramientas": [
        {
            "herramienta": "categoria_subcategoria",
            "orden": 1,
            "parametros": {
                "categoria": "Manifestaciones Culturales",
                "subcategoria": "Museo",
            },
        },
        {
            "herramienta": "busqueda_semantica",
            "orden": 2,
            "parametros": {
                "texto_embeddings": (
                    "museo con exhibiciones históricas y arte religioso"
                ),
                "posibles_match": [
                    "arte religioso",
                    "patrimonio histórico",
                    "historia local",
                ],
                "excluir_terminos": [],
            },
        },
    ],
}

PLAN_MUSEO_TARIFA_VACIA = {
    **PLAN_MUSEO_SEMANTICA,
    "herramientas": [
        *PLAN_MUSEO_SEMANTICA["herramientas"],
        {
            "herramienta": "tarifa_acceso",
            "orden": 3,
            "parametros": {
                "precio_numero": None,
                "operador": None,
                "etiqueta": None,
                "condicion": None,
                "excluir_condiciones": [],
            },
        },
    ],
}


@pytest.mark.integration
def test_ejecutar_plan_tarifa_vacia_conserva_tarjetas() -> None:
    requests = pytest.importorskip("requests")

    respuesta = requests.post(
        "http://127.0.0.1:8000/api/v1/chatboot/ejecutar-plan",
        json=PLAN_MUSEO_TARIFA_VACIA,
        timeout=120,
    )
    respuesta.raise_for_status()
    data = respuesta.json()

    assert data["ok"] is True
    assert len(data["tarjetas"]) >= 1
    assert data["filtro_passthrough_aplicado"] is True


@pytest.mark.integration
def test_ejecutar_plan_sin_tarifa_devuelve_precio_en_tarjeta() -> None:
    requests = pytest.importorskip("requests")

    respuesta = requests.post(
        "http://127.0.0.1:8000/api/v1/chatboot/ejecutar-plan",
        json=PLAN_MUSEO_SEMANTICA,
        timeout=120,
    )
    respuesta.raise_for_status()
    data = respuesta.json()

    assert data["ok"] is True
    assert len(data["tarjetas"]) >= 1
    assert any(tarjeta.get("precio") for tarjeta in data["tarjetas"])


@pytest.mark.integration
def test_ejecutar_plan_filtro_valido_sin_coincidencias() -> None:
    requests = pytest.importorskip("requests")

    plan = {
        "tipo_ejecucion": "secuencial",
        "herramientas": [
            {
                "herramienta": "categoria_subcategoria",
                "orden": 1,
                "parametros": {
                    "categoria": "Manifestaciones Culturales",
                    "subcategoria": "Museo",
                },
            },
            {
                "herramienta": "busqueda_semantica",
                "orden": 2,
                "parametros": {
                    "texto_embeddings": "museo con exhibiciones históricas",
                    "posibles_match": ["arte religioso", "historia"],
                    "excluir_terminos": [],
                },
            },
            {
                "herramienta": "tarifa_acceso",
                "orden": 3,
                "parametros": {
                    "precio_numero": None,
                    "operador": None,
                    "etiqueta": "economico",
                    "condicion": "perfil_inexistente",
                    "excluir_condiciones": [],
                },
            },
        ],
    }

    respuesta = requests.post(
        "http://127.0.0.1:8000/api/v1/chatboot/ejecutar-plan",
        json=plan,
        timeout=120,
    )
    respuesta.raise_for_status()
    data = respuesta.json()

    assert data["ok"] is False
    assert len(data["tarjetas"]) == 0
    assert data["filtro_passthrough_aplicado"] is False
