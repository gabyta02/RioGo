import sys
from pathlib import Path
from unittest.mock import MagicMock

import pytest

APIS_ROOT = Path(__file__).resolve().parents[1]
if str(APIS_ROOT) not in sys.path:
    sys.path.insert(0, str(APIS_ROOT))

from esquemas.chatboot import ResolverSitioRequest
from servicios.chatboot import resolver_sitio_por_entidad


def test_resolver_sitio_entidad_vacia() -> None:
    db = MagicMock()
    resultado = resolver_sitio_por_entidad(db, ResolverSitioRequest(entidad="   "))
    assert resultado.encontrado is False
    assert resultado.mensaje == "La entidad consultada no puede estar vacia."


def test_resolver_sitio_no_encontrado() -> None:
    db = MagicMock()
    db.execute.return_value.mappings.return_value.first.return_value = None

    resultado = resolver_sitio_por_entidad(
        db,
        ResolverSitioRequest(entidad="hotel inventado"),
    )

    assert resultado.encontrado is False
    assert resultado.id_sitio is None
    assert resultado.mensaje == "No existe el sitio en la base de datos."


def test_resolver_sitio_encontrado() -> None:
    db = MagicMock()
    db.execute.return_value.mappings.return_value.first.return_value = {
        "id_sitio": 15,
        "nombre": "Basílica del Sagrado Corazón",
        "score": 0.93,
    }

    resultado = resolver_sitio_por_entidad(
        db,
        ResolverSitioRequest(entidad="basilica del sagrado corazon"),
    )

    assert resultado.encontrado is True
    assert resultado.id_sitio == 15
    assert resultado.nombre == "Basílica del Sagrado Corazón"
    assert resultado.score == 0.93
