import sys
from pathlib import Path
from unittest.mock import MagicMock

import pytest

APIS_ROOT = Path(__file__).resolve().parents[1]
CHATBOOT_UTILITES = (
    Path(__file__).resolve().parents[2]
    / "chatboot/ application/chatboot_exploracion/utilites"
)
for path in (APIS_ROOT, CHATBOOT_UTILITES):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from esquemas.chatboot import GisRequest
from servicios.chatboot import (
    _gis_params_tienen_alcance_previo,
    _gis_tiene_alcance,
    gis,
)

try:
    from construir_plan_tool import PlanClasificacion, validar_formato_plan
except ImportError:
    PlanClasificacion = None
    validar_formato_plan = None


def test_gis_tiene_alcance_rechaza_todos() -> None:
    assert _gis_tiene_alcance("todos") is False
    assert _gis_tiene_alcance("categoria") is True
    assert _gis_tiene_alcance("ids_candidatos") is True


@pytest.mark.parametrize(
    ("params", "ids_previos", "esperado"),
    [
        ({}, [], False),
        ({}, [1, 2], True),
        ({"categoria": "Atractivos Naturales"}, [], True),
        ({"subcategoria": "Laguna"}, [], True),
        ({"punto_referencia": "Riobamba"}, [], False),
    ],
)
def test_gis_params_tienen_alcance_previo(
    params: dict,
    ids_previos: list[int],
    esperado: bool,
) -> None:
    assert (
        _gis_params_tienen_alcance_previo(params, ids_previos) is esperado
    )


def test_gis_api_rechaza_sin_alcance() -> None:
    from unittest.mock import patch

    db = MagicMock()
    with (
        patch(
            "servicios.chatboot._resolver_punto_origen",
            return_value=(-1.67, -78.65, "nominatim", "Riobamba"),
        ),
        patch(
            "servicios.chatboot._construir_alcance_sitios",
            return_value=([], {}, "todos", {}),
        ),
    ):
        resultado = gis(
            db,
            GisRequest(
                usar_ubicacion_usuario=False,
                distancia=None,
                unidad=None,
                punto_referencia="Riobamba",
            ),
            ubicacion_usuario=None,
        )
    assert resultado.ok is False
    assert "alcance previo" in resultado.mensaje.lower()


PLAN_MIRADOR_SIN_CATEGORIA = {
    "tipo_ejecucion": "paralelo",
    "herramientas": [
        {
            "herramienta": "categoria_subcategoria",
            "grupo": "laguna",
            "orden": 1,
            "parametros": {
                "categoria": "Atractivos Naturales",
                "subcategoria": "Laguna",
                "excluir_categorias": [],
            },
        },
        {
            "herramienta": "busqueda_semantica",
            "grupo": "laguna",
            "orden": 2,
            "parametros": {
                "texto_embeddings": "laguna con fácil acceso en vehículo",
                "posibles_match": ["acceso en carro", "llegar en vehículo"],
                "excluir_terminos": [],
            },
        },
        {
            "herramienta": "gis",
            "grupo": "laguna",
            "orden": 3,
            "parametros": {
                "usar_ubicacion_usuario": False,
                "distancia": None,
                "unidad": None,
                "punto_referencia": "Riobamba",
                "excluir_zonas": [],
            },
        },
        {
            "herramienta": "busqueda_semantica",
            "grupo": "mirador",
            "orden": 1,
            "parametros": {
                "texto_embeddings": "mirador con vista panorámica y acceso en carro",
                "posibles_match": ["mirador panorámico", "vista al paisaje"],
                "excluir_terminos": [],
            },
        },
        {
            "herramienta": "gis",
            "grupo": "mirador",
            "orden": 2,
            "parametros": {
                "usar_ubicacion_usuario": False,
                "distancia": 30,
                "unidad": "km",
                "punto_referencia": "Riobamba",
                "excluir_zonas": [],
            },
        },
    ],
}

PLAN_LAGUNA_MIRADOR_CORREGIDO = {
    "tipo_ejecucion": "paralelo",
    "herramientas": [
        {
            "herramienta": "categoria_subcategoria",
            "grupo": "laguna",
            "orden": 1,
            "parametros": {
                "categoria": "Atractivos Naturales",
                "subcategoria": "Laguna",
                "excluir_categorias": [],
            },
        },
        {
            "herramienta": "busqueda_semantica",
            "grupo": "laguna",
            "orden": 2,
            "parametros": {
                "texto_embeddings": "laguna de fácil acceso en vehículo",
                "posibles_match": ["acceso en carro", "llegar en vehículo"],
                "excluir_terminos": [],
            },
        },
        {
            "herramienta": "gis",
            "grupo": "laguna",
            "orden": 3,
            "parametros": {
                "usar_ubicacion_usuario": False,
                "distancia": None,
                "unidad": None,
                "punto_referencia": "Riobamba",
                "excluir_zonas": [],
            },
        },
        {
            "herramienta": "categoria_subcategoria",
            "grupo": "mirador",
            "orden": 1,
            "parametros": {
                "categoria": "Atractivos Naturales",
                "subcategoria": "Montaña",
                "excluir_categorias": [],
            },
        },
        {
            "herramienta": "busqueda_semantica",
            "grupo": "mirador",
            "orden": 2,
            "parametros": {
                "texto_embeddings": "mirador con vista panorámica y acceso en vehículo",
                "posibles_match": ["mirador panorámico", "vista al paisaje"],
                "excluir_terminos": [],
            },
        },
        {
            "herramienta": "gis",
            "grupo": "mirador",
            "orden": 3,
            "parametros": {
                "usar_ubicacion_usuario": False,
                "distancia": None,
                "unidad": None,
                "punto_referencia": "Riobamba",
                "excluir_zonas": [],
            },
        },
    ],
}

PLAN_LAGUNA_SOLO_GIS = {
    "tipo_ejecucion": "secuencial",
    "herramientas": [
        {
            "herramienta": "categoria_subcategoria",
            "orden": 1,
            "parametros": {
                "categoria": "Atractivos Naturales",
                "subcategoria": "Laguna",
                "excluir_categorias": [],
            },
        },
        {
            "herramienta": "gis",
            "orden": 2,
            "parametros": {
                "usar_ubicacion_usuario": False,
                "distancia": None,
                "unidad": None,
                "punto_referencia": "Riobamba",
                "excluir_zonas": [],
            },
        },
    ],
}


@pytest.mark.skipif(validar_formato_plan is None, reason="chatboot utilites no disponible")
def test_plan_validator_rechaza_gis_sin_alcance() -> None:
    with pytest.raises(ValueError, match="sin ancla fuerte"):
        validar_formato_plan(PLAN_MIRADOR_SIN_CATEGORIA)


@pytest.mark.skipif(validar_formato_plan is None, reason="chatboot utilites no disponible")
def test_plan_validator_acepta_plan_corregido() -> None:
    plan = validar_formato_plan(PLAN_LAGUNA_MIRADOR_CORREGIDO)
    assert plan.tipo_ejecucion == "paralelo"
    assert len(plan.herramientas) == 6


@pytest.mark.integration
def test_ejecutar_plan_mirador_sin_categoria_no_contamina() -> None:
    requests = pytest.importorskip("requests")

    respuesta = requests.post(
        "http://127.0.0.1:8000/api/v1/chatboot/ejecutar-plan",
        json=PLAN_MIRADOR_SIN_CATEGORIA,
        timeout=120,
    )
    respuesta.raise_for_status()
    data = respuesta.json()

    subcategorias = {
        (tarjeta.get("subcategoria") or "").lower()
        for tarjeta in data.get("tarjetas", [])
    }
    irrelevantes = {"restaurante", "hotel", "hostal", "cafeteria"}
    assert not subcategorias & irrelevantes
    assert data.get("gis_alcance_passthrough_aplicado") is True


@pytest.mark.integration
def test_ejecutar_plan_laguna_mirador_corregido() -> None:
    requests = pytest.importorskip("requests")

    respuesta = requests.post(
        "http://127.0.0.1:8000/api/v1/chatboot/ejecutar-plan",
        json=PLAN_LAGUNA_MIRADOR_CORREGIDO,
        timeout=120,
    )
    respuesta.raise_for_status()
    data = respuesta.json()

    assert data["ok"] is True
    assert len(data["tarjetas"]) >= 1
    naturaleza = {"laguna", "montaña", "montana", "cascada", "quebrada"}
    assert any(
        (tarjeta.get("subcategoria") or "").lower() in naturaleza
        for tarjeta in data["tarjetas"]
    )


@pytest.mark.integration
def test_ejecutar_plan_laguna_categoria_gis() -> None:
    requests = pytest.importorskip("requests")

    respuesta = requests.post(
        "http://127.0.0.1:8000/api/v1/chatboot/ejecutar-plan",
        json=PLAN_LAGUNA_SOLO_GIS,
        timeout=120,
    )
    respuesta.raise_for_status()
    data = respuesta.json()

    assert data.get("gis_alcance_passthrough_aplicado") is False
    if data["ok"]:
        assert all(
            (tarjeta.get("subcategoria") or "").lower() == "laguna"
            for tarjeta in data["tarjetas"]
        )
