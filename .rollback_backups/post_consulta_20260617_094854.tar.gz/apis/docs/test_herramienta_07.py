import argparse
import json
import os
import sys
import time
from pathlib import Path

import requests
from dotenv import load_dotenv

ROOT_DIR = Path(__file__).resolve().parents[1]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

load_dotenv(ROOT_DIR / ".env")

COMANDOS_SALIDA = {"salir", "exit", "quit", "q"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Prueba manual de la herramienta H8 ruta."
    )
    parser.add_argument(
        "--base-url",
        default=os.getenv("APIS_BASE_URL", "http://127.0.0.1:8000"),
        help="URL base de la API",
    )
    return parser.parse_args()


def resolver_base_url(base_url: str) -> str:
    url = base_url.rstrip("/")
    if "://apis:" in url or url.endswith("://apis:8000"):
        return "http://127.0.0.1"
    return url


def _parsear_excluir(texto: str) -> list[str]:
    if not texto.strip():
        return []
    return [parte.strip() for parte in texto.split(",") if parte.strip()]


def ejecutar_consulta(base_url: str, payload: dict) -> None:
    endpoint = f"{base_url}/api/v1/chatboot/ruta"

    print(f"\n{'=' * 60}")
    print(f"POST {endpoint}")
    print(f"Payload: {json.dumps(payload, ensure_ascii=False)}")

    inicio = time.perf_counter()
    try:
        response = requests.post(endpoint, json=payload, timeout=30)
        http_ms = round((time.perf_counter() - inicio) * 1000, 2)
        response.raise_for_status()
        data = response.json()
    except requests.RequestException as exc:
        http_ms = round((time.perf_counter() - inicio) * 1000, 2)
        print(f"Error HTTP ({http_ms} ms): {exc}")
        return

    print(f"HTTP {response.status_code} en {http_ms} ms")
    print(f"ok: {data.get('ok')}")
    print(f"tipo_ruta_resuelto: {data.get('tipo_ruta_resuelto')}")
    print(f"ids_rutas: {data.get('ids_rutas')}")
    print(f"mensaje: {data.get('mensaje')}")
    print(json.dumps(data, ensure_ascii=False, indent=2))


def modo_interactivo(base_url: str) -> None:
    print(f"Base URL: {base_url}")
    print("Modo interactivo — H8 ruta")
    print("Tipos: senderismo, ciclismo, caminata_urbana, montanismo, otro")
    print("Comandos de salida: salir, exit, quit, q")
    print("-" * 60)

    while True:
        try:
            tipo_ruta = input("\ntipo_ruta> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nFin de la sesion.")
            break

        if not tipo_ruta:
            print("Indica un tipo de ruta o un comando de salida.")
            continue
        if tipo_ruta.lower() in COMANDOS_SALIDA:
            print("Fin de la sesion.")
            break

        try:
            excluir_texto = input("excluir_tipos (coma, Enter=vacio)> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nFin de la sesion.")
            break

        payload = {
            "tipo_ruta": tipo_ruta,
            "excluir_tipos": _parsear_excluir(excluir_texto),
        }
        ejecutar_consulta(base_url, payload)


def main() -> None:
    args = parse_args()
    modo_interactivo(resolver_base_url(args.base_url))


if __name__ == "__main__":
    main()
