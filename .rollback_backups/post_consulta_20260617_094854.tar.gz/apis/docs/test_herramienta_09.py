import json
import sys
from pathlib import Path

import requests

# Agregar el directorio raíz al path para poder importar módulos si fuera necesario
sys.path.append(str(Path(__file__).resolve().parents[1]))

API_URL = "http://localhost:8000/api/v1/chatboot/busqueda-semantica"

def probar_busqueda_semantica(
    texto_embeddings: str,
    excluir_terminos: list[str] | None = None,
    categoria: str | None = None,
    subcategoria: str | None = None,
    ids_sitios_candidatos: list[int] | None = None,
):
    print(f"\n--- Probando H12: busqueda_semantica ---")
    payload = {
        "texto_embeddings": texto_embeddings,
    }
    if excluir_terminos is not None:
        payload["excluir_terminos"] = excluir_terminos
    if categoria is not None:
        payload["categoria"] = categoria
    if subcategoria is not None:
        payload["subcategoria"] = subcategoria
    if ids_sitios_candidatos is not None:
        payload["ids_sitios_candidatos"] = ids_sitios_candidatos

    print(f"Payload:\n{json.dumps(payload, indent=2)}")

    try:
        response = requests.post(API_URL, json=payload)
        response.raise_for_status()
        data = response.json()
        print(f"\nRespuesta (Status: {response.status_code}):")
        print(json.dumps(data, indent=2, ensure_ascii=False))
        return data
    except requests.exceptions.RequestException as e:
        print(f"\nError en la petición: {e}")
        if hasattr(e, "response") and e.response is not None:
            print(f"Detalle del error: {e.response.text}")
        return None

if __name__ == "__main__":
    print("Iniciando pruebas de la herramienta H12: busqueda_semantica")

    # Prueba 1: Búsqueda básica
    probar_busqueda_semantica(
        texto_embeddings="un lugar con mucha historia y arquitectura antigua",
    )

    # Prueba 2: Búsqueda con exclusión de términos
    probar_busqueda_semantica(
        texto_embeddings="un lugar con mucha historia y arquitectura antigua",
        excluir_terminos=["iglesia", "religioso"]
    )

    # Prueba 3: Búsqueda con categoría
    probar_busqueda_semantica(
        texto_embeddings="un lugar para comer platos tradicionales",
        categoria="gastronomia"
    )

    # Prueba 4: Búsqueda con ids específicos
    probar_busqueda_semantica(
        texto_embeddings="un lugar con mucha historia",
        ids_sitios_candidatos=[1, 2, 3, 4, 5]
    )
