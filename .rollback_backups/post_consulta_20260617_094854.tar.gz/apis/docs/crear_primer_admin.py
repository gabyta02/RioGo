import argparse
import getpass
import os
import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[1]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from dotenv import load_dotenv
from sqlalchemy import create_engine, text
from sqlalchemy.engine import make_url
from sqlalchemy.orm import sessionmaker

from core.encriptacion import encriptar_texto

load_dotenv(ROOT_DIR / ".env")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Crea el primer usuario administrador de RiobambaTour."
    )
    parser.add_argument("--username", default=os.getenv("ADMIN_USERNAME"))
    parser.add_argument("--email", default=os.getenv("ADMIN_EMAIL"))
    parser.add_argument("--password", default=os.getenv("ADMIN_PASSWORD"))
    parser.add_argument("--database-url", default=os.getenv("ADMIN_DATABASE_URL"))
    return parser.parse_args()


def pedir_valor(nombre: str, valor_actual: str | None, secreto: bool = False) -> str:
    if valor_actual:
        return valor_actual

    if secreto:
        return getpass.getpass(f"{nombre}: ").strip()

    return input(f"{nombre}: ").strip()


def resolver_database_url(database_url: str | None) -> str:
    url = database_url or os.getenv("DATABASE_URL")
    if not url:
        raise RuntimeError("DATABASE_URL no esta configurada")

    parsed = make_url(url)
    if parsed.host == "postgres-apis" and not Path("/.dockerenv").exists():
        parsed = parsed.set(host="127.0.0.1")

    return parsed.render_as_string(hide_password=False)


def crear_admin(username: str, email: str, password: str, database_url: str | None) -> None:
    engine = create_engine(resolver_database_url(database_url), pool_pre_ping=True)
    SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

    with SessionLocal() as db:
        existe = db.execute(
            text(
                """
                SELECT id_usuario, activo
                FROM chatbot.usuario
                WHERE username = :username OR email = :email
                """
            ),
            {"username": username, "email": email},
        ).mappings().first()

        if existe:
            raise RuntimeError(
                "Ya existe un usuario con ese username o email "
                f"(id_usuario={existe['id_usuario']})"
            )

        id_rol = db.execute(
            text("SELECT id_rol FROM chatbot.rol WHERE rol = 'super-admin' AND activo = TRUE")
        ).scalar()
        if not id_rol:
            raise RuntimeError("Rol super-admin no configurado en la base de datos")

        usuario = db.execute(
            text(
                """
                INSERT INTO chatbot.usuario (
                    id_rol, nombre_completo, username, password, email, autentificacion_doble
                )
                VALUES (:id_rol, :nombre_completo, :username, :password, :email, TRUE)
                RETURNING id_usuario, username, email
                """
            ),
            {
                "id_rol": id_rol,
                "nombre_completo": username,
                "username": username,
                "password": encriptar_texto(password),
                "email": email,
            },
        ).mappings().one()
        db.commit()

    print(
        "Admin creado: "
        f"id_usuario={usuario['id_usuario']} "
        f"username={usuario['username']} "
        f"email={usuario['email']} "
        f"rol=super-admin"
    )


def main() -> None:
    args = parse_args()
    username = pedir_valor("Username admin", args.username)
    email = pedir_valor("Email admin", args.email)
    password = pedir_valor("Password admin", args.password, secreto=True)

    if not username or not email or not password:
        raise RuntimeError("username, email y password son obligatorios")

    crear_admin(username, email, password, args.database_url)


if __name__ == "__main__":
    main()
