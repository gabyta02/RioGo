# Contratos de APIs

## Base URL

```txt
/api/v1
```

Todas las respuestas son JSON.

## Autenticacion

### Solicitar codigo de correo

```http
POST /api/v1/auth/correo/verificacion
```

Body:

```json
{
  "proposito": "login_2fa",
  "username": "admin"
}
```

Para registro de usuario:

```json
{
  "proposito": "registro_usuario",
  "email": "usuario@example.com"
}
```

Respuesta:

```json
{
  "mensaje": "Codigo de verificacion enviado",
  "token_verificacion": "jwt-temporal",
  "expira_en_minutos": 10
}
```

### Reenviar codigo

```http
POST /api/v1/auth/correo/reenviar
```

Usa el mismo body de solicitud de codigo. El codigo anterior queda invalidado.

### Login

```http
POST /api/v1/auth/login
```

Usuario normal:

```json
{
  "username": "usuario1",
  "password": "Password123"
}
```

Administrador:

```json
{
  "username": "admin",
  "password": "Password123",
  "codigo_verificacion": "123456",
  "token_verificacion": "jwt-temporal"
}
```

Respuesta:

```json
{
  "rol": "super-admin",
  "token": "jwt-sesion",
  "usuario": {
    "id_usuario": 1,
    "id_rol": 2,
    "username": "admin",
    "email": "admin@example.com",
    "rol": "super-admin",
    "activo": true,
    "autentificacion_doble": true,
    "actualizado_en": "2026-06-13T00:00:00Z"
  }
}
```

### Registro usuario

```http
POST /api/v1/auth/registro/usuario
```

Requiere verificacion de correo.

```json
{
  "username": "usuario1",
  "email": "usuario@example.com",
  "password": "Password123",
  "rol": "usuario",
  "codigo_verificacion": "123456",
  "token_verificacion": "jwt-temporal"
}
```

### Registro admin

```http
POST /api/v1/auth/registro/admin
```

No requiere codigo de correo.

```json
{
  "username": "admin",
  "email": "admin@example.com",
  "password": "Password123",
  "rol": "super-admin"
}
```

### Cerrar sesion

```http
POST /api/v1/auth/logout
Authorization: Bearer jwt-sesion
```

Respuesta:

```json
{
  "mensaje": "Sesion cerrada correctamente"
}
```

Los endpoints bajo `/api/v1/admin/*` requieren `Authorization: Bearer ...` y validan
que el JWT coincida con `chatbot.usuario.token`.

### Actualizar cuenta

```http
PATCH /api/v1/auth/cuenta
```

Cambiar solo username:

```json
{
  "username": "usuario1",
  "password": "Password123",
  "nuevo_username": "usuario2"
}
```

Cambiar email o password requiere codigo:

```json
{
  "username": "usuario1",
  "password": "Password123",
  "nuevo_email": "nuevo@example.com",
  "nuevo_password": "Password456",
  "codigo_verificacion": "123456",
  "token_verificacion": "jwt-temporal"
}
```

### Eliminar cuenta

```http
DELETE /api/v1/auth/cuenta
```

```json
{
  "username": "usuario1",
  "password": "Password123",
  "codigo_verificacion": "123456",
  "token_verificacion": "jwt-temporal"
}
```

## Dashboard Admin

Base:

```txt
/api/v1/admin/dashboard
```

### Resumen

```http
GET /api/v1/admin/dashboard/resumen
```

Query params:

```txt
periodo=all|today|week|month|year|custom
fecha_inicio=YYYY-MM-DD
fecha_fin=YYYY-MM-DD
```

Respuesta:

```json
{
  "usuarios_registrados": { "valor": 1, "variacion": 100.0 },
  "atractivos_activos": { "valor": 0, "variacion": 0.0 },
  "preguntas_chatbots": { "valor": 0, "variacion": 0.0 },
  "favoritos_guardados": { "valor": 0, "variacion": 0.0 },
  "noticias_activas": { "valor": 0, "variacion": 0.0 },
  "rutas_activas": { "valor": 0, "variacion": 0.0 }
}
```

Fuentes principales:

```txt
usuarios   -> chatbot.usuario
atractivos -> turismo.sitio
preguntas  -> chatbot.mensaje_explorador + chatbot.mensaje_detalle
favoritos  -> chatbot.favorito
noticias   -> turismo.noticia
rutas      -> gis.rutas_turistica
```

### Metrica individual

```http
GET /api/v1/admin/dashboard/metricas
```

Query params:

```txt
metric=usuarios|atractivos|preguntas|favoritos|noticias|rutas
periodo=all|today|week|month|year|custom
estado=activo|inactivo|publicado|borrador|all
tipo_chatbot=general|sitio|all
categoria=Naturaleza
subcategoria=Volcanes
id_sitio=1
```

Respuesta:

```json
{
  "metric": "rutas",
  "periodo": "all",
  "valor": 11
}
```

Para `metric=rutas`, el conteo usa:

```sql
SELECT COUNT(*) FROM gis.rutas_turistica
```

## Atractivos Turisticos Admin

Base:

```txt
/api/v1/admin/atractivos
```

### Listar atractivos

```http
GET /api/v1/admin/atractivos
```

Query params:

```txt
q=chimborazo
id_categoria=1
id_subcategoria=2
estado=activo|inactivo|all
servicio=wifi|parqueadero|mascotas|accesibilidad|all
precio=gratis|pagado|all
page=1
page_size=10
```

Respuesta:

```json
{
  "page": 1,
  "page_size": 10,
  "total": 1,
  "items": [
    {
      "id_sitio": 1,
      "nombre": "Volcan Chimborazo",
      "descripcion_corta": "El punto mas alto del Ecuador.",
      "id_categoria": 1,
      "categoria": "Naturaleza",
      "id_subcategoria": 2,
      "subcategoria": "Reservas naturales",
      "activo": true,
      "imagen_url": "https://example.com/chimborazo.jpg"
    }
  ]
}
```

### Crear atractivo

```http
POST /api/v1/admin/atractivos
```

Body minimo:

```json
{
  "id_parroquia": 1,
  "id_plataforma": 1,
  "id_categoria": 1,
  "id_subcategoria": 2,
  "tipo": "atractivo_turistico",
  "nombre": "Volcan Chimborazo",
  "descripcion_corta": "El punto mas alto del Ecuador.",
  "latitud": -1.4691,
  "longitud": -78.8175,
  "direccion_texto": "Reserva de Produccion de Fauna Chimborazo",
  "referencia_adicional": "Ingreso principal por la via Guaranda",
  "horario": {
    "abierto_24h": false,
    "dias_semana": [1, 2, 3, 4, 5, 6, 7],
    "hora_inicio": "07:00",
    "hora_fin": "17:00",
    "comentario": "Solo con reservacion previa"
  },
  "contactos": [
    { "tipo": "telefono", "contenido": "(03) 296-0300" }
  ],
  "multimedia": [
    {
      "url": "/api/v1/imagenes/volcan-chimborazo/imagen.jpg",
      "es_principal": true
    }
  ],
  "precio": {
    "es_gratuito": true,
    "precio_min": null,
    "precio_max": null,
    "etiqueta_precio": "desconocido",
    "tarifa_acceso": null,
    "condicion_tarifa": null
  },
  "tiene_wifi": true,
  "parqueadero": true,
  "permite_mascotas": false,
  "accesibilidad": true,
  "activo": true
}
```

Body completo:

```json
{
  "id_parroquia": 1,
  "id_plataforma": 1,
  "id_categoria": 1,
  "id_subcategoria": 2,
  "tipo": "atractivo_turistico",
  "nombre": "Volcan Chimborazo",
  "descripcion_corta": "El punto mas alto del Ecuador y el mas cercano al sol.",
  "latitud": -1.4691,
  "longitud": -78.8175,
  "es_gratuito": true,
  "permite_mascotas": false,
  "parqueadero": true,
  "tiene_wifi": false,
  "accesibilidad": true,
  "activo": true,
  "direccion_texto": "Reserva de Produccion de Fauna Chimborazo",
  "referencia_adicional": "Ingreso principal por la via Guaranda",
  "horario": {
    "abierto_24h": false,
    "dias_semana": [1, 2, 3, 4, 5, 6, 7],
    "hora_inicio": "07:00",
    "hora_fin": "17:00",
    "comentario": "Solo con reservacion previa"
  },
  "contactos": [
    { "tipo": "telefono", "contenido": "(03) 296-0300" },
    { "tipo": "whatsapp", "contenido": "0999999999" },
    { "tipo": "email", "contenido": "info@chimborazo.gob.ec" },
    { "tipo": "web", "contenido": "https://www.turismo.gob.ec" },
    { "tipo": "facebook", "contenido": "https://facebook.com/chimborazo" },
    { "tipo": "instagram", "contenido": "https://instagram.com/chimborazo" },
    { "tipo": "tiktok", "contenido": "https://tiktok.com/@chimborazo" },
    { "tipo": "otro", "contenido": "Centro de informacion turistico" }
  ],
  "multimedia": [
    {
      "url": "/api/v1/imagenes/volcan-chimborazo/chimborazo.jpg",
      "es_principal": true
    }
  ],
  "precio": {
    "es_gratuito": false,
    "precio_min": 2.5,
    "precio_max": 10,
    "etiqueta_precio": "economico",
    "tarifa_acceso": 5,
    "condicion_tarifa": "Adultos"
  }
}
```

Respuesta: `201 Created` con el mismo formato de un item de listado.

Notas:

- `id_categoria`, `tipo` y `nombre` son obligatorios porque asi esta definido el esquema SQL.
- `id_parroquia` e `id_plataforma` pueden enviarse como `null`; si se envia `id_plataforma`, tambien debe enviarse `id_parroquia`.
- Los tipos validos de sitio salen del enum `turismo.tipo_sitio_t`: `servicio_turistico`, `atractivo_turistico`, `operadora_turistica`, `desconocido`.
- `id_subcategoria`, `descripcion_corta`, `latitud`, `longitud`, `direccion_texto`, `referencia_adicional`, `horario`, `contactos`, `multimedia` y `precio` tambien son obligatorios para el formulario administrativo actual.
- `id_subcategoria` debe pertenecer a `id_categoria`.
- `contactos` requiere al menos un item; no es necesario enviar todos los tipos de contacto.
- `multimedia` crea registros en `turismo.multimedia`; si ninguna imagen llega marcada como principal, la primera sera principal.
- `direccion_texto` crea el registro asociado en `turismo.direccion`.
- Si `horario.abierto_24h=true`, la API guarda los dias seleccionados con rango interno `00:00` a `23:59`. En este caso `horario.detalles` se ignora.
- `horario.detalles` es opcional y permite definir uno o mas horarios por dia (1-7).
  Cada item es `{ "dia_semana": 1..7, "cerrado": false, "hora_inicio": "HH:MM", "hora_fin": "HH:MM" }`.
  Si `cerrado=true`, no se persisten horas para ese dia. `dias_semana` sigue
  siendo la fuente de verdad de "que dias abre"; los dias listados que no
  tengan detalle se interpretan como cerrados.
  - Si `detalles` esta presente y `abierto_24h=false`, se usa el detalle por
    dia. `hora_inicio`/`hora_fin` globales pueden omitirse.
  - Si `detalles` esta vacio, se replica `hora_inicio`/`hora_fin` globales
    en cada dia de `dias_semana`.
- `horario.comentario` es opcional, maximo 200 caracteres. Se guarda en `turismo.horario.comentario`.
- Los tipos validos de contacto salen del enum `turismo.tipo_contacto_t`: `telefono`, `whatsapp`, `email`, `web`, `facebook`, `instagram`, `tiktok`, `otro`.
- Las etiquetas validas de precio salen del enum `turismo.etiqueta_precio_t`: `economico`, `medio`, `alto`, `desconocido`.
- `precio.es_gratuito=true` indica sitio gratuito. En este caso no se
  aceptan `precio_min`, `precio_max`, `tarifa_acceso` ni `condicion_tarifa`.
- `precio.tarifa_acceso` y `precio.precio_min`+`precio_max` son **excluyentes**:
  envie uno u otro, no ambos. Si llegan ambos, la API responde 400.
- La API guarda `descripcion_corta` como dato descriptivo; los embeddings para chatbot se generan desde secciones de documentos Markdown.

### Detalle de atractivo

```http
GET /api/v1/admin/atractivos/{id_sitio}
```

Devuelve la informacion completa usada por el formulario de edicion:
datos generales, clasificacion, direccion, coordenadas, horario, contactos,
multimedia, servicios y precios.

`horario` incluye un array `detalles` con la lista persistida de
`horario_detalle` (un item por dia con horario activo). Los dias
listados en `dias_semana` que no aparecen en `detalles` se interpretan
como cerrados.

### Actualizar atractivo

```http
PUT /api/v1/admin/atractivos/{id_sitio}
```

Usa el mismo body de creacion. La API actualiza el sitio y reemplaza las
relaciones editables del formulario: direccion, multimedia, contactos, horario,
rango de precio y tarifa de acceso.

Si una imagen local registrada en `turismo.multimedia` deja de estar asociada
al atractivo despues de editar, el archivo se elimina desde
`fuente_datos/imagenes`.

### Eliminar atractivo

```http
DELETE /api/v1/admin/atractivos/{id_sitio}
```

Elimina fisicamente el registro de `turismo.sitio`. Las tablas dependientes
con `ON DELETE CASCADE` se eliminan por la base de datos. Antes de eliminar el
sitio, la API limpia referencias en `gis.ruta_puntos` para evitar conflictos
con el `CHECK` de esa tabla. Tambien borra los archivos locales registrados en
`turismo.multimedia` cuando pertenecen a `/api/v1/imagenes/...`. Las URLs
externas no se eliminan del filesystem.

### Cambiar estado de atractivo

```http
PATCH /api/v1/admin/atractivos/{id_sitio}/estado
```

Body:

```json
{
  "activo": false
}
```

Actualiza solo `turismo.sitio.activo`. Este endpoint se usa desde el badge
`Activo/Inactivo` del panel y no elimina archivos ni relaciones.

### Subir imagenes

```http
POST /api/v1/admin/atractivos/imagenes
Content-Type: multipart/form-data
```

Campos:

```txt
nombre_sitio=Volcan Chimborazo
archivos=<uno o varios archivos image/*>
```

La API guarda los archivos en:

```txt
fuente_datos/imagenes/{nombre-del-sitio}/
```

Respuesta:

```json
[
  {
    "nombre_archivo": "archivo.jpg",
    "url": "/api/v1/imagenes/volcan-chimborazo/archivo.jpg"
  }
]
```

### Categorias

```http
GET /api/v1/admin/atractivos/categorias
GET /api/v1/admin/atractivos/categorias/detalle
POST /api/v1/admin/atractivos/categorias
PATCH /api/v1/admin/atractivos/categorias/{id_categoria}
PATCH /api/v1/admin/atractivos/categorias/{id_categoria}/estado
DELETE /api/v1/admin/atractivos/categorias/{id_categoria}
```

Body POST:

```json
{
  "nombre": "Naturaleza",
  "activo": true
}
```

Respuesta:

```json
{
  "id_categoria": 1,
  "nombre": "Naturaleza",
  "activo": true
}
```

`DELETE` elimina fisicamente la categoria, sus subcategorias y los atractivos
asociados. Tambien limpia imagenes locales asociadas a esos atractivos.

`PATCH /estado` cambia solamente `turismo.categoria.activo`.

### Subcategorias

```http
GET /api/v1/admin/atractivos/subcategorias?id_categoria=1
POST /api/v1/admin/atractivos/subcategorias
PATCH /api/v1/admin/atractivos/subcategorias/{id_subcategoria}
PATCH /api/v1/admin/atractivos/subcategorias/{id_subcategoria}/estado
DELETE /api/v1/admin/atractivos/subcategorias/{id_subcategoria}
```

Body POST:

```json
{
  "id_categoria": 1,
  "nombre": "Reservas naturales",
  "activo": true
}
```

`DELETE` elimina fisicamente la subcategoria y los atractivos asociados.
Tambien limpia imagenes locales asociadas a esos atractivos.

`PATCH /estado` cambia solamente `turismo.subcategoria.activo`.

Respuesta:

```json
{
  "id_subcategoria": 2,
  "id_categoria": 1,
  "nombre": "Reservas naturales",
  "activo": true
}
```

### Catalogos auxiliares para formularios

```http
GET /api/v1/admin/atractivos/parroquias
GET /api/v1/admin/atractivos/plataformas?id_parroquia=1
```

Respuesta:

```json
[
  {
    "id": 1,
    "nombre": "Riobamba",
    "activo": true
  }
]
```

## Rutas Turisticas Admin

Base:

```txt
/api/v1/admin/rutas-turisticas
```

### Listar rutas

```http
GET /api/v1/admin/rutas-turisticas
```

Query params:

```txt
q=hielo
tipo_ruta=Senderismo|Ciclismo|Caminata Urbana|Montañismo|Otras
estado=activo|inactivo|all
page=1
page_size=10
```

Respuesta:

```json
{
  "page": 1,
  "page_size": 10,
  "total": 1,
  "items": [
    {
      "id_ruta": 1,
      "tipo_ruta": "Senderismo",
      "titulo": "Ruta del Hielo",
      "url_imagen": "/api/v1/imagenes/rutas/ruta-del-hielo/imagen.jpg",
      "descripcion": "Ruta interpretativa de alta montana.",
      "activo": true,
      "total_puntos": 0,
      "tiene_linea": false
    }
  ]
}
```

### Crear ruta

```http
POST /api/v1/admin/rutas-turisticas
```

Body actual del panel:

```json
{
  "tipo_ruta": "Senderismo",
  "titulo": "Ruta del Hielo",
  "url_imagen": "/api/v1/imagenes/rutas/ruta-del-hielo/imagen.jpg",
  "descripcion": "Ruta interpretativa de alta montana.",
  "activo": true
}
```

Notas:

- `tipo_ruta`, `titulo`, `url_imagen`, `descripcion` y `activo` son los campos usados por el formulario administrativo actual.
- Los tipos validos de ruta salen del enum `gis.tipo_ruta_t`: `Senderismo`, `Ciclismo`, `Caminata Urbana`, `Montañismo`, `Otras`.
- La geometria `geom_linea` y los puntos de `gis.ruta_puntos` se administran
  desde los endpoints de geometria; no son obligatorios para crear la ruta base.
- La API guarda `descripcion` como dato descriptivo; los embeddings para chatbot se generan desde secciones de documentos Markdown.

### Buscar sitios para geometria

```http
GET /api/v1/admin/rutas-turisticas/sitios
```

Query params:

```txt
q=chimborazo
limit=20
```

Respuesta:

```json
[
  {
    "id_sitio": 1,
    "nombre": "Volcan Chimborazo",
    "categoria": "Naturaleza",
    "subcategoria": "Volcanes",
    "latitud": -1.4692,
    "longitud": -78.8175
  }
]
```

Solo devuelve sitios activos con `turismo.sitio.ubicacion` registrada.

### Obtener geometria de ruta

```http
GET /api/v1/admin/rutas-turisticas/{id_ruta}/geometria
```

Respuesta:

```json
{
  "id_ruta": 1,
  "titulo": "Ruta de las Iglesias",
  "linea": [
    { "latitud": -1.673, "longitud": -78.648 },
    { "latitud": -1.675, "longitud": -78.651 }
  ],
  "puntos": [
    {
      "orden": 1,
      "tipo": "inicio",
      "id_sitio": null,
      "nombre_sitio": null,
      "latitud": -1.673,
      "longitud": -78.648
    },
    {
      "orden": 2,
      "tipo": "sitio",
      "id_sitio": 10,
      "nombre_sitio": "Catedral de Riobamba",
      "latitud": -1.674,
      "longitud": -78.65
    }
  ]
}
```

Tipos de punto usados por el panel:

```txt
inicio|fin|libre|sitio
```

En la interfaz, los puntos se crean primero como puntos normales. Luego el
usuario puede marcar cualquier punto como origen o final. Si el punto proviene
de un sitio, conserva `id_sitio`; si ademas se marca como origen o final, la API
guarda tambien `punto_inicio` o `punto_fin`.

El panel modela la edicion como un grafo local: puntos con identificador
interno, lineas independientes y vertices libres o enlazados a puntos. Al
guardar, ese grafo se aplana a un unico arreglo `linea` porque la base de datos
guarda la forma final en `gis.rutas_turistica.geom_linea`.

### Guardar geometria de ruta

```http
PUT /api/v1/admin/rutas-turisticas/{id_ruta}/geometria
```

Body:

```json
{
  "linea": [
    { "latitud": -1.673, "longitud": -78.648 },
    { "latitud": -1.675, "longitud": -78.651 }
  ],
  "puntos": [
    {
      "orden": 1,
      "tipo": "inicio",
      "latitud": -1.673,
      "longitud": -78.648
    },
    {
      "orden": 2,
      "tipo": "sitio",
      "id_sitio": 10
    },
    {
      "orden": 3,
      "tipo": "fin",
      "latitud": -1.675,
      "longitud": -78.651
    }
  ]
}
```

La API reemplaza la geometria previa:

- `gis.rutas_turistica.geom_linea` se actualiza con la linea enviada o queda
  `NULL` si no hay linea.
- `gis.ruta_puntos` se reemplaza completo para esa ruta.
- Los puntos `sitio` guardan `id_sitio`.
- Los puntos `inicio` y `libre` guardan `punto_inicio` cuando no son solo una
  referencia a sitio.
- Los puntos `fin` guardan `punto_fin`.

### Subir imagen de ruta

```http
POST /api/v1/admin/rutas-turisticas/imagen
Content-Type: multipart/form-data
```

Campos:

```txt
titulo_ruta=Ruta del Hielo
archivo=<un archivo image/*>
```

La API guarda el archivo en:

```txt
fuente_datos/imagenes/rutas/{titulo-de-la-ruta}/
```

Respuesta:

```json
{
  "nombre_archivo": "archivo.jpg",
  "url": "/api/v1/imagenes/rutas/ruta-del-hielo/archivo.jpg"
}
```

### Actualizar ruta

```http
PATCH /api/v1/admin/rutas-turisticas/{id_ruta}
```

Body parcial:

```json
{
  "titulo": "Ruta del Hielo actualizada",
  "url_imagen": "/api/v1/imagenes/rutas/ruta-del-hielo/nueva.jpg",
  "activo": false
}
```

Si `url_imagen` cambia y la URL anterior apuntaba a un archivo local bajo
`/api/v1/imagenes/rutas/...`, la API elimina el archivo anterior del
filesystem. Si la URL anterior era externa, no se elimina ningun archivo.

### Cambiar estado de ruta

```http
PATCH /api/v1/admin/rutas-turisticas/{id_ruta}/estado
```

Body:

```json
{
  "activo": false
}
```

Actualiza solo `gis.rutas_turistica.activo`. Este endpoint se usa desde el
badge `Activo/Inactivo` del panel.

### Eliminar ruta

```http
DELETE /api/v1/admin/rutas-turisticas/{id_ruta}
```

Elimina fisicamente el registro en `gis.rutas_turistica`. Las tablas
dependientes como `gis.documento_ruta` y `gis.ruta_puntos` se eliminan por
`ON DELETE CASCADE`. Tambien elimina del filesystem la imagen local asociada a
`url_imagen` cuando pertenece a `/api/v1/imagenes/rutas/...`. Las URLs externas
no se eliminan.

## Politica de imagenes locales

La API solo elimina archivos del filesystem cuando la URL pertenece al prefijo
estatico administrado por el proyecto:

```txt
/api/v1/imagenes/...
```

Para atractivos, los archivos se guardan bajo:

```txt
fuente_datos/imagenes/{nombre-del-sitio}/
```

Para rutas, los archivos se guardan bajo:

```txt
fuente_datos/imagenes/rutas/{titulo-de-la-ruta}/
```

Las URLs externas se conservan intactas porque la API no controla esos
recursos. Si una carpeta local queda vacia despues de eliminar archivos, la API
intenta remover tambien la carpeta.

### Series temporales

```http
GET /api/v1/admin/dashboard/series
```

Query params:

```txt
metric=preguntas
periodo=week
agrupar_por=hour|day|week|month|year
comparar_por=none|tipo_chatbot|categoria|subcategoria|estado
```

Respuesta:

```json
{
  "metric": "preguntas",
  "periodo": "week",
  "agrupar_por": "day",
  "comparar_por": "tipo_chatbot",
  "series": []
}
```

### Distribucion

```http
GET /api/v1/admin/dashboard/distribucion
```

Query params:

```txt
metric=preguntas|favoritos|atractivos|noticias|rutas
dimension=tipo_chatbot|categoria|subcategoria|estado|sitio
periodo=month
limit=10
```

Respuesta:

```json
{
  "metric": "preguntas",
  "dimension": "tipo_chatbot",
  "periodo": "month",
  "items": [
    { "label": "general", "key": "general", "valor": 10 }
  ]
}
```

### Ranking

```http
GET /api/v1/admin/dashboard/ranking
```

Query params:

```txt
tipo=sitios_consultados|sitios_favoritos|categorias_buscadas|subcategorias_buscadas|rutas_consultadas
periodo=month
limit=5
categoria=Naturaleza
subcategoria=Volcanes
tipo_chatbot=general|sitio|all
```

Respuesta:

```json
{
  "tipo": "sitios_favoritos",
  "periodo": "month",
  "limit": 5,
  "items": [
    {
      "posicion": 1,
      "id": 1,
      "nombre": "Volcan Chimborazo",
      "valor": 12
    }
  ]
}
```

Nota: `rutas_consultadas` lista rutas activas desde `gis.rutas_turistica`.
Cuando exista una tabla de eventos de consulta de rutas, el valor debe pasar a
representar consultas reales.

### Consultas

```http
GET /api/v1/admin/dashboard/consultas
```

Query params:

```txt
periodo=month
tipo_chatbot=general|sitio|all
categoria=Naturaleza
subcategoria=Volcanes
id_sitio=1
q=wifi
page=1
page_size=20
orden=fecha_desc|fecha_asc
```

Respuesta:

```json
{
  "page": 1,
  "page_size": 20,
  "total": 0,
  "items": []
}
```

## Chatboot

Base:

```txt
/api/v1/chatboot
```

Endpoints internos consumidos por el servicio `chatboot`. No requieren autenticacion
JWT; deben exponerse solo en la red interna del proyecto.

### Generar embedding del mensaje del usuario

```http
POST /api/v1/chatboot/embeddings/mensaje
```

Body:

```json
{
  "sesion_id": "uuid-sesion",
  "client_message_id": "abc-123",
  "mensaje": "hoteles con wifi cerca de mi"
}
```

Respuesta:

```json
{
  "sesion_id": "uuid-sesion",
  "client_message_id": "abc-123",
  "mensaje": "hoteles con wifi cerca de mi",
  "embedding_mensaje": [0.0123, -0.0456]
}
```

El vector se genera con Voyage y se reutiliza en el panel administrativo para
analitica semantica de consultas.

### Resolver catalogo

```http
POST /api/v1/chatboot/resolver-catalogo
```

Body:

```json
{
  "categorias_texto": ["hospedaje"],
  "subcategorias_texto": ["hoteles"],
  "parroquias_texto": [],
  "sitios_texto": ["parque sucre"],
  "rutas_texto": []
}
```

Respuesta:

```json
{
  "categorias": [{ "id": 1, "nombre": "Hospedaje", "score": 0.91 }],
  "subcategorias": [{ "id": 2, "nombre": "Hoteles", "score": 0.86 }],
  "parroquias": [],
  "sitios_mencionados": [
    { "id": 10, "nombre": "Parque Sucre", "score": 0.82, "lat": -1.67, "lng": -78.65 }
  ],
  "rutas_mencionadas": [],
  "no_resuelto": []
}
```

### Buscar GIS

```http
POST /api/v1/chatboot/buscar-gis
```

Body:

```json
{
  "usar_ubicacion_usuario": true,
  "ubicacion_usuario": { "lat": -1.6736, "lng": -78.6473 },
  "distancia": 2,
  "acciones_gis": { "consultar_entidades_cercanas": true }
}
```

Respuesta:

```json
{
  "ok": true,
  "items": [
    {
      "tipo": "sitio",
      "id": 15,
      "nombre": "Museo de Arte",
      "distancia_metros": 620.0,
      "score_gis": 0.69,
      "razones": ["esta a 620 metros del origen (ubicacion_usuario)"]
    }
  ]
}
```

### Buscar rutas

```http
POST /api/v1/chatboot/buscar-rutas
```

Body:

```json
{
  "tipo_ruta": "Senderismo",
  "atributos_semanticos": null,
  "limite": 10,
  "resultados_gis": []
}
```

Respuesta:

```json
{
  "ok": true,
  "items": [
    {
      "tipo": "ruta",
      "id": 3,
      "titulo": "Ruta del Hielo",
      "tipo_ruta": "Senderismo",
      "descripcion": "",
      "imagen": "",
      "score_ruta": 0.7,
      "sitios_relacionados": [],
      "razones": ["coincide con tipo de ruta Senderismo"]
    }
  ]
}
```

### Resolver sitio por nombre (pregunta directa)

```http
POST /api/v1/chatboot/resolver-sitio
```

Busca un sitio activo en `turismo.sitio` usando `pg_trgm` con umbral de confianza
del 90% (`similarity >= 0.9`) sobre el campo `nombre`.

Body:

```json
{
  "entidad": "basilica del sagrado corazon"
}
```

Respuesta cuando existe:

```json
{
  "encontrado": true,
  "entidad_consultada": "basilica del sagrado corazon",
  "id_sitio": 15,
  "nombre": "Basílica del Sagrado Corazón",
  "score": 0.93,
  "mensaje": "Sitio encontrado en la base de datos."
}
```

Respuesta cuando no existe:

```json
{
  "encontrado": false,
  "entidad_consultada": "hotel inventado",
  "id_sitio": null,
  "nombre": null,
  "score": null,
  "mensaje": "No existe el sitio en la base de datos."
}
```

## Errores comunes

Periodo custom sin fechas:

```json
{
  "detail": "fecha_inicio y fecha_fin son obligatorias para periodo=custom"
}
```

Parametro fuera del catalogo:

```json
{
  "detail": [
    {
      "type": "literal_error",
      "loc": ["query", "metric"],
      "msg": "Input should be ..."
    }
  ]
}
```

## Autorizacion del panel administrativo

Roles de panel:

| Rol | Acceso |
|-----|--------|
| `super-admin` | Todos los modulos y gestion de cuentas/cargos |
| `admin` | Solo modulos listados en `usuario_permiso` |

Matriz modulo / permiso / router:

| Modulo panel | Codigo permiso | Router |
|--------------|----------------|--------|
| Dashboard | `dashboard` | `/admin/dashboard/*` excepto consultas y semantica |
| Analisis de consultas | `analytics` | `/admin/dashboard/consultas`, `/admin/dashboard/semantica` |
| Atractivos | `attractions` | `/admin/atractivos` (sitios, imagenes, catalogos) |
| Categorias | `categories` | `/admin/atractivos/categorias*`, `/subcategorias*` |
| Rutas | `routes` | `/admin/rutas-turisticas` |
| Contenido chatbots | `chatbot_content` | `/admin/contenido-chatbots` |
| Cuentas administrativas | `admin_accounts` | Solo super-admin via `/admin/cuentas` |

## Cuentas administrativas

Base path (solo `super-admin`):

```txt
/api/v1/admin/cuentas
```

### Listar cuentas

```http
GET /api/v1/admin/cuentas?q=maria&id_cargo=2&activo=true&page=1&page_size=10
```

Respuesta:

```json
{
  "items": [
    {
      "id_usuario": 3,
      "nombre_completo": "Andrea Pilco",
      "email": "andrea.pilco@riobambatour.gob.ec",
      "username": "andrea.pilco",
      "id_cargo": 3,
      "cargo_nombre": "Analista",
      "activo": true,
      "ultimo_acceso_en": "2026-06-15T09:00:00Z",
      "iniciales": "AP"
    }
  ],
  "total": 1,
  "page": 1,
  "page_size": 10
}
```

### Crear cuenta

```http
POST /api/v1/admin/cuentas
```

```json
{
  "nombre_completo": "Andrea Pilco",
  "email": "andrea.pilco@riobambatour.gob.ec",
  "id_cargo": 3,
  "activo": true,
  "permisos": ["dashboard", "attractions", "categories", "routes", "chatbot_content"]
}
```

La contrasena inicial es generada automaticamente y se envia por correo
al email de la cuenta creada.

### Actualizar cuenta

```http
PATCH /api/v1/admin/cuentas/{id_usuario}
```

### Cambiar estado

```http
PATCH /api/v1/admin/cuentas/{id_usuario}/estado
```

```json
{
  "activo": false
}
```

### Eliminar cuenta

```http
DELETE /api/v1/admin/cuentas/{id_usuario}
```

## Cargos y permisos

```http
GET /api/v1/admin/cargos
GET /api/v1/admin/cargos/{id_cargo}
POST /api/v1/admin/cargos
PATCH /api/v1/admin/cargos/{id_cargo}
DELETE /api/v1/admin/cargos/{id_cargo}
GET /api/v1/admin/permisos
```

Ejemplo de cargo:

```json
{
  "nombre": "Analista",
  "activo": true,
  "permisos": ["dashboard", "analytics", "attractions"]
}
```
