import argparse
import json
import os
import sys
import time
from pathlib import Path

import requests
from dotenv import load_dotenv

ROOT_DIR = Path(__file__).resolve().parents[1]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

load_dotenv(ROOT_DIR / ".env")

COMANDOS_SALIDA = {"salir", "exit", "quit", "q"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Prueba manual de la herramienta H4 contactos."
    )
    parser.add_argument(
        "--base-url",
        default=os.getenv("APIS_BASE_URL", "http://127.0.0.1:8000"),
        help="URL base de la API",
    )
    return parser.parse_args()


def resolver_base_url(base_url: str) -> str:
    url = base_url.rstrip("/")
    if "://apis:" in url or url.endswith("://apis:8000"):
        return "http://127.0.0.1"
    return url


def _parsear_excluir(texto: str) -> list[str]:
    if not texto.strip():
        return []
    return [parte.strip() for parte in texto.split(",") if parte.strip()]


def _parsear_ids(texto: str) -> list[int]:
    if not texto.strip():
        return []
    return [int(parte.strip()) for parte in texto.split(",") if parte.strip().isdigit()]


def ejecutar_consulta(base_url: str, payload: dict) -> None:
    endpoint = f"{base_url}/api/v1/chatboot/contactos"

    print(f"\n{'=' * 60}")
    print(f"POST {endpoint}")
    print(f"Payload: {json.dumps(payload, ensure_ascii=False)}")

    inicio = time.perf_counter()
    try:
        response = requests.post(endpoint, json=payload, timeout=30)
        http_ms = round((time.perf_counter() - inicio) * 1000, 2)
        response.raise_for_status()
        data = response.json()
    except requests.RequestException as exc:
        http_ms = round((time.perf_counter() - inicio) * 1000, 2)
        print(f"Error HTTP ({http_ms} ms): {exc}")
        return

    print(f"HTTP {response.status_code} en {http_ms} ms")
    print(f"tiempo_ms API: {data.get('tiempo_ms')}")
    print(f"ok: {data.get('ok')}")
    print(f"contacto_sugerido: {data.get('contacto_sugerido')}")
    print(f"contacto_sugerido_resuelto: {data.get('contacto_sugerido_resuelto')}")
    print(f"ids_sitios: {data.get('ids_sitios')}")
    print(f"alcance_aplicado: {data.get('alcance_aplicado')}")
    print(f"categoria_resuelta: {data.get('categoria_resuelta')}")
    print(f"subcategoria_resuelta: {data.get('subcategoria_resuelta')}")
    print(f"tipos_contacto_excluidos: {data.get('tipos_contacto_excluidos')}")
    print(f"mensaje: {data.get('mensaje')}")

    sitios = data.get("sitios") or []
    if sitios:
        print(f"sitios ({len(sitios)}):")
        for sitio in sitios[:20]:
            print(
                f"  - {sitio['nombre']} (id={sitio['id_sitio']}) "
                f"tiene_sugerido={sitio.get('tiene_contacto_sugerido')}"
            )
            for contacto in sitio.get("contactos", []):
                print(f"      {contacto['tipo']}: {contacto['contenido']}")
        if len(sitios) > 20:
            print(f"  ... y {len(sitios) - 20} mas")

    print("Respuesta completa:")
    print(json.dumps(data, ensure_ascii=False, indent=2))


def modo_interactivo(base_url: str) -> None:
    print(f"Base URL: {base_url}")
    print("Modo interactivo — herramienta H4 contactos")
    print("Ejemplos contacto_sugerido: whatsapp, email, telefono, web, instagram")
    print("Comandos de salida: salir, exit, quit, q")
    print("-" * 60)

    while True:
        try:
            contacto = input("\ncontacto_sugerido> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nFin de la sesion.")
            break

        if not contacto:
            print("Indica un tipo de contacto o un comando de salida.")
            continue
        if contacto.lower() in COMANDOS_SALIDA:
            print("Fin de la sesion.")
            break

        try:
            excluir_texto = input("excluir_contactos (coma, Enter=vacio)> ").strip()
            categoria = input("categoria (Enter=omitir)> ").strip() or None
            subcategoria = input("subcategoria (Enter=omitir)> ").strip() or None
            ids_texto = input("ids_sitios_candidatos (coma, Enter=omitir)> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nFin de la sesion.")
            break

        payload: dict = {
            "contacto_sugerido": contacto,
            "excluir_contactos": _parsear_excluir(excluir_texto),
        }
        if categoria:
            payload["categoria"] = categoria
        if subcategoria:
            payload["subcategoria"] = subcategoria
        ids = _parsear_ids(ids_texto)
        if ids:
            payload["ids_sitios_candidatos"] = ids

        ejecutar_consulta(base_url, payload)


def main() -> None:
    args = parse_args()
    modo_interactivo(resolver_base_url(args.base_url))


if __name__ == "__main__":
    main()
