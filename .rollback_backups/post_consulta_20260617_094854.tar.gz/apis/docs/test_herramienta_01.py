import argparse
import json
import os
import sys
import time
from pathlib import Path

import requests
from dotenv import load_dotenv

ROOT_DIR = Path(__file__).resolve().parents[1]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

load_dotenv(ROOT_DIR / ".env")

CASOS_DEFECTO = [
    {
        "nombre": "Parroquia corta",
        "direccion_referencia": "parroquia lizarzaburu",
        "excluir": [],
    },
    {
        "nombre": "Direccion larga",
        "direccion_referencia": "avenida daniel leon borja frente al parque",
        "excluir": [],
    },
    {
        "nombre": "Parroquia con exclusion",
        "direccion_referencia": "parroquia lizarzaburu",
        "excluir": ["colta"],
    },
]

COMANDOS_SALIDA = {"salir", "exit", "quit", "q"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Prueba manual de la herramienta H1 busqueda_aproximada."
    )
    parser.add_argument(
        "--base-url",
        default=os.getenv("APIS_BASE_URL", "http://127.0.0.1:8000"),
        help="URL base de la API (default: APIS_BASE_URL o http://127.0.0.1:8000)",
    )
    parser.add_argument(
        "--direccion",
        default=None,
        help="Una sola consulta y termina (sin modo interactivo)",
    )
    parser.add_argument(
        "--excluir",
        action="append",
        default=[],
        help="Termino a excluir (repetible, solo con --direccion)",
    )
    parser.add_argument(
        "--casos",
        action="store_true",
        help="Ejecutar los 3 casos predefinidos y terminar",
    )
    return parser.parse_args()


def resolver_base_url(base_url: str) -> str:
    url = base_url.rstrip("/")
    if "://apis:" in url or url.endswith("://apis:8000"):
        return "http://127.0.0.1"
    return url


def _imprimir_top_sitios_direccion(data: dict) -> None:
    candidatos = data.get("top_sitios_direccion") or []
    if not candidatos:
        print("top_sitios_direccion: (sin candidatos)")
        return

    print(f"top_sitios_direccion ({len(candidatos)} mejores por similitud):")
    for i, sitio in enumerate(candidatos, start=1):
        excluido = " [EXCLUIDO]" if sitio.get("descartado_por_exclusion") else ""
        print(
            f"  {i}. {sitio['nombre']} — {sitio['similitud_porcentaje']:.2f}%"
            f"{excluido}"
        )
        print(
            f"     id={sitio['id_sitio']} | {sitio['direccion_texto']} "
            f"| campo={sitio['campo_match']}"
        )
        print(
            f"     score_final={sitio['score']} | trgm={sitio.get('score_trgm')} "
            f"| rapidfuzz={sitio.get('score_rapidfuzz')}"
        )


def _parsear_ids(texto: str) -> list[int]:
    if not texto.strip():
        return []
    ids: list[int] = []
    for parte in texto.split(","):
        parte = parte.strip()
        if parte.isdigit():
            ids.append(int(parte))
    return ids


def ejecutar_caso(
    base_url: str,
    nombre: str,
    direccion: str,
    excluir: list[str],
    categoria: str | None = None,
    subcategoria: str | None = None,
    ids_sitios_candidatos: list[int] | None = None,
) -> None:
    endpoint = f"{base_url}/api/v1/chatboot/busqueda-aproximada"
    payload: dict = {
        "direccion_referencia": direccion,
        "excluir": excluir,
    }
    if categoria:
        payload["categoria"] = categoria
    if subcategoria:
        payload["subcategoria"] = subcategoria
    if ids_sitios_candidatos:
        payload["ids_sitios_candidatos"] = ids_sitios_candidatos

    print(f"\n{'=' * 60}")
    print(f"Caso: {nombre}")
    print(f"POST {endpoint}")
    print(f"Payload: {json.dumps(payload, ensure_ascii=False)}")

    inicio = time.perf_counter()
    try:
        response = requests.post(endpoint, json=payload, timeout=30)
        http_ms = round((time.perf_counter() - inicio) * 1000, 2)
        response.raise_for_status()
        data = response.json()
    except requests.RequestException as exc:
        http_ms = round((time.perf_counter() - inicio) * 1000, 2)
        print(f"Error HTTP ({http_ms} ms): {exc}")
        return

    print(f"HTTP {response.status_code} en {http_ms} ms")
    print(f"tiempo_ms API: {data.get('tiempo_ms')}")
    print(f"ok: {data.get('ok')}")
    print(f"tipo_resultado: {data.get('tipo_resultado')}")
    print(f"fuente: {data.get('fuente')}")
    print(f"texto_sin_prefijos_via: {data.get('texto_sin_prefijos_via', '')}")
    print(f"alcance_aplicado: {data.get('alcance_aplicado')}")
    print(f"categoria_resuelta: {data.get('categoria_resuelta')}")
    print(f"subcategoria_resuelta: {data.get('subcategoria_resuelta')}")
    print(f"ids_sitios_candidatos_aplicados: {data.get('ids_sitios_candidatos_aplicados')}")
    print(f"mensaje: {data.get('mensaje')}")

    if data.get("ids_sitios"):
        print(f"ids_sitios: {data['ids_sitios']}")
    if data.get("nombre"):
        print(f"nombre: {data['nombre']}")

    _imprimir_top_sitios_direccion(data)

    print("Respuesta completa:")
    print(json.dumps(data, ensure_ascii=False, indent=2))


def _parsear_excluir(texto: str) -> list[str]:
    if not texto.strip():
        return []
    return [parte.strip() for parte in texto.split(",") if parte.strip()]


def modo_interactivo(base_url: str) -> None:
    print(f"Base URL: {base_url}")
    print("Modo interactivo — escribe consultas para probar busqueda_aproximada.")
    print("Comandos: 'salir', 'exit', 'quit' o 'q' para terminar.")
    print("Excluir: deja vacio o escribe terminos separados por coma (ej. colta, centro)")
    print("-" * 60)

    while True:
        try:
            direccion = input("\ndireccion_referencia> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nFin de la sesion.")
            break

        if not direccion:
            print("Escribe un texto o un comando de salida.")
            continue

        if direccion.lower() in COMANDOS_SALIDA:
            print("Fin de la sesion.")
            break

        try:
            excluir_texto = input("excluir (coma separada, Enter=vacio)> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nFin de la sesion.")
            break

        excluir = _parsear_excluir(excluir_texto)

        try:
            categoria = input("categoria (Enter=omitir)> ").strip() or None
            subcategoria = input("subcategoria (Enter=omitir)> ").strip() or None
            ids_texto = input("ids_sitios_candidatos (coma, Enter=omitir)> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nFin de la sesion.")
            break

        ejecutar_caso(
            base_url,
            "Consulta interactiva",
            direccion,
            excluir,
            categoria=categoria,
            subcategoria=subcategoria,
            ids_sitios_candidatos=_parsear_ids(ids_texto),
        )


def main() -> None:
    args = parse_args()
    base_url = resolver_base_url(args.base_url)

    if args.direccion:
        ejecutar_caso(
            base_url,
            "Consulta manual",
            args.direccion,
            args.excluir,
        )
        return

    if args.casos:
        print(f"Base URL: {base_url}")
        for caso in CASOS_DEFECTO:
            ejecutar_caso(
                base_url,
                caso["nombre"],
                caso["direccion_referencia"],
                caso["excluir"],
            )
        return

    modo_interactivo(base_url)


if __name__ == "__main__":
    main()
