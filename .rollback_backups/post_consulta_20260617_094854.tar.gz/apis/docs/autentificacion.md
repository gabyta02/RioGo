# API de Autentificacion

Base path:

```txt
/api/v1/auth
```

## Reglas generales

- Las contrasenas se guardan con bcrypt.
- El login devuelve `rol`, `token` JWT, `permisos` del panel y datos publicos del usuario.
- Los roles de panel son `super-admin` (acceso total) y `admin` (permisos por modulo).
- Las cuentas eliminadas quedan con `activo = false`.
- El registro de usuarios normales requiere verificacion por correo.
- El registro de super-administradores no requiere codigo de correo.
- El login exige verificacion por correo solo si la cuenta tiene `autentificacion_doble = true`.
- Cambiar solo `username` no requiere verificacion por correo.
- Cambiar `email`, cambiar `password` o eliminar cuenta si requiere verificacion por correo.

## Solicitar codigo de correo

```http
POST /api/v1/auth/correo/verificacion
```

Para reenviar codigo:

```http
POST /api/v1/auth/correo/reenviar
```

El reenvio genera un codigo nuevo e invalida el codigo anterior para el mismo
correo y proposito.

Para registro de usuario:

```json
{
  "proposito": "registro_usuario",
  "email": "usuario@example.com"
}
```

Para operaciones de una cuenta existente:

```json
{
  "proposito": "login_2fa",
  "username": "admin"
}
```

Propositos validos:

```txt
registro_usuario
eliminar_cuenta
actualizar_credenciales
login_2fa
```

Respuesta:

```json
{
  "mensaje": "Codigo de verificacion enviado",
  "token_verificacion": "jwt-temporal",
  "expira_en_minutos": 10
}
```

## Registrar usuario

```http
POST /api/v1/auth/registro/usuario
```

```json
{
  "username": "usuario1",
  "email": "usuario@example.com",
  "password": "Password123",
  "rol": "usuario",
  "codigo_verificacion": "123456",
  "token_verificacion": "jwt-temporal"
}
```

## Registrar administrador

```http
POST /api/v1/auth/registro/admin
```

```json
{
  "username": "admin",
  "email": "admin@example.com",
  "password": "Password123",
  "rol": "super-admin"
}
```

## Login

```http
POST /api/v1/auth/login
```

Usuario normal:

```json
{
  "username": "usuario1",
  "password": "Password123"
}
```

Cuenta con autenticacion doble:

```json
{
  "username": "admin",
  "password": "Password123",
  "codigo_verificacion": "123456",
  "token_verificacion": "jwt-temporal"
}
```

Respuesta:

```json
{
  "rol": "super-admin",
  "token": "jwt-de-sesion",
  "permisos": ["dashboard", "analytics", "attractions", "categories", "routes", "chatbot_content", "noticias", "admin_accounts"],
  "usuario": {
    "id_usuario": 1,
    "id_rol": 2,
    "id_cargo": null,
    "nombre_completo": "Maria Yanez",
    "cargo_nombre": null,
    "username": "admin",
    "email": "admin@example.com",
    "rol": "super-admin",
    "activo": true,
    "autentificacion_doble": true,
    "actualizado_en": "2026-06-13T00:00:00Z",
    "ultimo_acceso_en": "2026-06-15T10:00:00Z"
  }
}
```

Las cuentas con rol `admin` reciben solo los modulos asignados en `chatbot.usuario_permiso`.
El JWT incluye `permisos`, `id_cargo` y `nombre_completo` para el panel administrativo.

## Cerrar sesion

```http
POST /api/v1/auth/logout
Authorization: Bearer jwt-de-sesion
```

Respuesta:

```json
{
  "mensaje": "Sesion cerrada correctamente"
}
```

La API invalida la sesion poniendo `chatbot.usuario.token` en `NULL`. Los endpoints
`/api/v1/admin/*` exigen un JWT vigente que coincida con el token guardado en base y,
segun el modulo, el permiso correspondiente (`dashboard`, `attractions`, etc.).
Solo `super-admin` puede gestionar cuentas y cargos (`/admin/cuentas`, `/admin/cargos`).

## Actualizar cuenta

```http
PATCH /api/v1/auth/cuenta
```

Cambiar solo username:

```json
{
  "username": "usuario1",
  "password": "Password123",
  "nuevo_username": "usuario2"
}
```

Cambiar email o password:

```json
{
  "username": "usuario1",
  "password": "Password123",
  "nuevo_email": "nuevo@example.com",
  "nuevo_password": "Password456",
  "codigo_verificacion": "123456",
  "token_verificacion": "jwt-temporal"
}
```

## Eliminar cuenta

```http
DELETE /api/v1/auth/cuenta
```

```json
{
  "username": "usuario1",
  "password": "Password123",
  "codigo_verificacion": "123456",
  "token_verificacion": "jwt-temporal"
}
```

Respuesta:

```json
{
  "mensaje": "Cuenta eliminada correctamente"
}
```

## Crear primer admin por script

Desde la carpeta `apis`:

```bash
.venv/bin/python docs/crear_primer_admin.py --username admin --email admin@example.com
```

Tambien puedes usar variables de entorno:

```bash
ADMIN_USERNAME=admin ADMIN_EMAIL=admin@example.com ADMIN_PASSWORD=Password123 \
.venv/bin/python docs/crear_primer_admin.py
```

Si lo ejecutas desde el host, el script cambia automaticamente el host
`postgres-apis` por `127.0.0.1`, porque Docker Compose publica PostgreSQL en
`127.0.0.1:5432`.

Tambien puedes ejecutarlo dentro del contenedor de la API:

```bash
docker exec -it riobambago-apis python docs/crear_primer_admin.py
```

## Modelo de permisos del panel

Tablas principales:

- `chatbot.cargo`: nombre del rol visible (Editor, Analista, etc.).
- `chatbot.permiso`: catalogo de modulos (`dashboard`, `attractions`, ...).
- `chatbot.cargo_permiso`: plantilla de modulos por cargo.
- `chatbot.usuario_permiso`: permisos efectivos por cuenta administrativa.

Las cuentas nuevas creadas por super-admin reciben una contrasena temporal
generada automaticamente, enviada al correo de la cuenta mediante SMTP.
