import argparse
import json
import os
import sys
import time
from pathlib import Path

import requests
from dotenv import load_dotenv

ROOT_DIR = Path(__file__).resolve().parents[1]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

load_dotenv(ROOT_DIR / ".env")

COMANDOS_SALIDA = {"salir", "exit", "quit", "q"}

CAMPOS = [
    ("tiene_wifi", "wifi"),
    ("permite_mascotas", "mascotas"),
    ("accesibilidad", "accesibilidad"),
    ("parqueadero", "parqueadero"),
    ("es_gratuito", "gratuito"),
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Prueba manual de la herramienta H3 campos_parametrizados."
    )
    parser.add_argument(
        "--base-url",
        default=os.getenv("APIS_BASE_URL", "http://127.0.0.1:8000"),
        help="URL base de la API",
    )
    return parser.parse_args()


def resolver_base_url(base_url: str) -> str:
    url = base_url.rstrip("/")
    if "://apis:" in url or url.endswith("://apis:8000"):
        return "http://127.0.0.1"
    return url


def _parsear_bool(texto: str) -> bool | None:
    valor = texto.strip().lower()
    if not valor:
        return None
    if valor in {"si", "sí", "s", "true", "1", "yes", "y"}:
        return True
    if valor in {"no", "n", "false", "0"}:
        return False
    raise ValueError(f"Valor invalido '{texto}'. Usa si, no o Enter para omitir.")


def _pedir_bool(nombre: str) -> bool | None:
    while True:
        try:
            respuesta = input(f"{nombre} (si/no/Enter=omitir)> ").strip()
            return _parsear_bool(respuesta)
        except ValueError as exc:
            print(exc)


def _parsear_excluir(texto: str) -> list[str]:
    if not texto.strip():
        return []
    return [parte.strip() for parte in texto.split(",") if parte.strip()]


def ejecutar_consulta(base_url: str, payload: dict) -> None:
    endpoint = f"{base_url}/api/v1/chatboot/campos-parametrizados"

    print(f"\n{'=' * 60}")
    print(f"POST {endpoint}")
    print(f"Payload: {json.dumps(payload, ensure_ascii=False)}")

    inicio = time.perf_counter()
    try:
        response = requests.post(endpoint, json=payload, timeout=30)
        http_ms = round((time.perf_counter() - inicio) * 1000, 2)
        response.raise_for_status()
        data = response.json()
    except requests.RequestException as exc:
        http_ms = round((time.perf_counter() - inicio) * 1000, 2)
        print(f"Error HTTP ({http_ms} ms): {exc}")
        return

    print(f"HTTP {response.status_code} en {http_ms} ms")
    print(f"tiempo_ms API: {data.get('tiempo_ms')}")
    print(f"ok: {data.get('ok')}")
    print(f"total: {data.get('total')}")
    print(f"filtros_aplicados: {data.get('filtros_aplicados')}")
    print(f"excluir_aplicado: {data.get('excluir_aplicado')}")
    print(f"alcance_aplicado: {data.get('alcance_aplicado')}")
    print(f"categoria_resuelta: {data.get('categoria_resuelta')}")
    print(f"subcategoria_resuelta: {data.get('subcategoria_resuelta')}")
    print(f"ids_sitios_candidatos_aplicados: {data.get('ids_sitios_candidatos_aplicados')}")
    print(f"mensaje: {data.get('mensaje')}")

    if data.get("ids_sitios"):
        print(f"ids_sitios: {data['ids_sitios']}")

    sitios = data.get("sitios") or []
    if sitios:
        print(f"sitios ({len(sitios)}):")
        for sitio in sitios[:20]:
            print(
                f"  - {sitio['nombre']} (id={sitio['id_sitio']}) "
                f"wifi={sitio.get('tiene_wifi')} "
                f"mascotas={sitio.get('permite_mascotas')} "
                f"accesibilidad={sitio.get('accesibilidad')} "
                f"parqueadero={sitio.get('parqueadero')} "
                f"gratuito={sitio.get('es_gratuito')}"
            )
        if len(sitios) > 20:
            print(f"  ... y {len(sitios) - 20} mas")

    print("Respuesta completa:")
    print(json.dumps(data, ensure_ascii=False, indent=2))


def modo_interactivo(base_url: str) -> None:
    print(f"Base URL: {base_url}")
    print("Modo interactivo — herramienta H3 campos_parametrizados")
    print("Para cada campo: si | no | Enter (null)")
    print("Excluir: terminos separados por coma (ej. wifi, parqueadero)")
    print("Comandos de salida: salir, exit, quit, q")
    print("-" * 60)

    while True:
        try:
            primer_campo = input("\nConsultar campos? (Enter=si, q=salir)> ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print("\nFin de la sesion.")
            break

        if primer_campo in COMANDOS_SALIDA:
            print("Fin de la sesion.")
            break

        payload: dict[str, bool | None | list[str]] = {}
        for campo, etiqueta in CAMPOS:
            payload[campo] = _pedir_bool(etiqueta)

        try:
            excluir_texto = input("excluir (coma separada, Enter=vacio)> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nFin de la sesion.")
            break

        payload["excluir"] = _parsear_excluir(excluir_texto)

        try:
            categoria = input("categoria (Enter=omitir)> ").strip() or None
            subcategoria = input("subcategoria (Enter=omitir)> ").strip() or None
            ids_texto = input("ids_sitios_candidatos (coma, Enter=omitir)> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nFin de la sesion.")
            break

        if categoria:
            payload["categoria"] = categoria
        if subcategoria:
            payload["subcategoria"] = subcategoria
        ids = [int(x.strip()) for x in ids_texto.split(",") if x.strip().isdigit()]
        if ids:
            payload["ids_sitios_candidatos"] = ids

        ejecutar_consulta(base_url, payload)


def main() -> None:
    args = parse_args()
    modo_interactivo(resolver_base_url(args.base_url))


if __name__ == "__main__":
    main()
