#!/usr/bin/env python3
"""Ejecuta un caso representativo por herramienta H2-H9 (no interactivo)."""
import json
import sys
import time
from pathlib import Path

import requests

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

BASE = "http://127.0.0.1:8000"

CASOS = [
    (
        "H3 campos_parametrizados",
        "/api/v1/chatboot/campos-parametrizados",
        {
            "tiene_wifi": True,
            "permite_mascotas": None,
            "accesibilidad": None,
            "parqueadero": None,
            "es_gratuito": None,
            "excluir": [],
            "categoria": "Alimentos y Bebidas",
            "subcategoria": "Restaurante",
            "ids_sitios_candidatos": [],
        },
    ),
    (
        "H4 contactos",
        "/api/v1/chatboot/contactos",
        {
            "contacto_sugerido": "whatsapp",
            "excluir_contactos": [],
            "categoria": "Alojamiento",
            "subcategoria": "Hotel",
            "ids_sitios_candidatos": [],
        },
    ),
    (
        "H5 horario",
        "/api/v1/chatboot/horario",
        {
            "tipo": "atiende_dia",
            "dia_semana": "7",
            "hora": None,
            "rango_hora": {"inicio": None, "fin": None},
            "comparador": None,
            "meridiano": None,
            "excluir_dias": [],
            "categoria": "Alimentos y Bebidas",
            "subcategoria": "Restaurante",
            "ids_sitios_candidatos": [],
        },
    ),
    (
        "H6 precio",
        "/api/v1/chatboot/precio",
        {
            "precio_numero": None,
            "operador": "min",
            "etiqueta": "economico",
            "excluir_etiquetas": [],
            "categoria": "Alimentos y Bebidas",
            "subcategoria": "Restaurante",
            "ids_sitios_candidatos": [],
        },
    ),
    (
        "H7 tarifa_acceso",
        "/api/v1/chatboot/tarifa-acceso",
        {
            "precio_numero": None,
            "operador": "min",
            "etiqueta": "economico",
            "condicion": None,
            "excluir_condiciones": [],
            "categoria": "Manifestaciones Culturales",
            "subcategoria": "Museo",
            "ids_sitios_candidatos": [],
        },
    ),
    (
        "H8 ruta",
        "/api/v1/chatboot/ruta",
        {
            "tipo_ruta": "ciclismo",
            "excluir_tipos": [],
            "ids_rutas_candidatos": [],
        },
    ),
    (
        "H9 gis",
        "/api/v1/chatboot/gis",
        {
            "usar_ubicacion_usuario": False,
            "distancia": 500,
            "unidad": "m",
            "punto_referencia": "Parque Maldonado",
            "excluir_zonas": [],
            "categoria": "Alimentos y Bebidas",
            "subcategoria": "Restaurante",
            "ids_sitios_candidatos": [],
        },
    ),
]

CASOS_EJECUTAR_PLAN = [
    (
        "EP1 museo tarifa vacia passthrough",
        {
            "tipo_ejecucion": "secuencial",
            "herramientas": [
                {
                    "herramienta": "categoria_subcategoria",
                    "orden": 1,
                    "parametros": {
                        "categoria": "Manifestaciones Culturales",
                        "subcategoria": "Museo",
                    },
                },
                {
                    "herramienta": "busqueda_semantica",
                    "orden": 2,
                    "parametros": {
                        "texto_embeddings": (
                            "museo con exhibiciones históricas y arte religioso"
                        ),
                        "posibles_match": [
                            "arte religioso",
                            "patrimonio histórico",
                            "historia local",
                        ],
                        "excluir_terminos": [],
                    },
                },
                {
                    "herramienta": "tarifa_acceso",
                    "orden": 3,
                    "parametros": {
                        "precio_numero": None,
                        "operador": None,
                        "etiqueta": None,
                        "condicion": None,
                        "excluir_condiciones": [],
                    },
                },
            ],
        },
        True,
    ),
    (
        "EP2 museo sin tarifa",
        {
            "tipo_ejecucion": "secuencial",
            "herramientas": [
                {
                    "herramienta": "categoria_subcategoria",
                    "orden": 1,
                    "parametros": {
                        "categoria": "Manifestaciones Culturales",
                        "subcategoria": "Museo",
                    },
                },
                {
                    "herramienta": "busqueda_semantica",
                    "orden": 2,
                    "parametros": {
                        "texto_embeddings": (
                            "museo con exhibiciones históricas y arte religioso"
                        ),
                        "posibles_match": [
                            "arte religioso",
                            "patrimonio histórico",
                            "historia local",
                        ],
                        "excluir_terminos": [],
                    },
                },
            ],
        },
        True,
    ),
    (
        "EP3 plan mirador sin categoria",
        {
            "tipo_ejecucion": "paralelo",
            "herramientas": [
                {
                    "herramienta": "categoria_subcategoria",
                    "grupo": "laguna",
                    "orden": 1,
                    "parametros": {
                        "categoria": "Atractivos Naturales",
                        "subcategoria": "Laguna",
                    },
                },
                {
                    "herramienta": "busqueda_semantica",
                    "grupo": "laguna",
                    "orden": 2,
                    "parametros": {
                        "texto_embeddings": "laguna con fácil acceso en vehículo",
                        "posibles_match": ["acceso en carro", "llegar en vehículo"],
                        "excluir_terminos": [],
                    },
                },
                {
                    "herramienta": "gis",
                    "grupo": "laguna",
                    "orden": 3,
                    "parametros": {
                        "usar_ubicacion_usuario": False,
                        "distancia": None,
                        "unidad": None,
                        "punto_referencia": "Riobamba",
                        "excluir_zonas": [],
                    },
                },
                {
                    "herramienta": "busqueda_semantica",
                    "grupo": "mirador",
                    "orden": 1,
                    "parametros": {
                        "texto_embeddings": "mirador con vista panorámica",
                        "posibles_match": ["mirador panorámico", "vista al paisaje"],
                        "excluir_terminos": [],
                    },
                },
                {
                    "herramienta": "gis",
                    "grupo": "mirador",
                    "orden": 2,
                    "parametros": {
                        "usar_ubicacion_usuario": False,
                        "distancia": 30,
                        "unidad": "km",
                        "punto_referencia": "Riobamba",
                        "excluir_zonas": [],
                    },
                },
            ],
        },
        True,
    ),
    (
        "EP4 laguna mirador corregido",
        {
            "tipo_ejecucion": "paralelo",
            "herramientas": [
                {
                    "herramienta": "categoria_subcategoria",
                    "grupo": "laguna",
                    "orden": 1,
                    "parametros": {
                        "categoria": "Atractivos Naturales",
                        "subcategoria": "Laguna",
                    },
                },
                {
                    "herramienta": "busqueda_semantica",
                    "grupo": "laguna",
                    "orden": 2,
                    "parametros": {
                        "texto_embeddings": "laguna de fácil acceso en vehículo",
                        "posibles_match": ["acceso en carro", "llegar en vehículo"],
                        "excluir_terminos": [],
                    },
                },
                {
                    "herramienta": "gis",
                    "grupo": "laguna",
                    "orden": 3,
                    "parametros": {
                        "usar_ubicacion_usuario": False,
                        "distancia": None,
                        "unidad": None,
                        "punto_referencia": "Riobamba",
                        "excluir_zonas": [],
                    },
                },
                {
                    "herramienta": "categoria_subcategoria",
                    "grupo": "mirador",
                    "orden": 1,
                    "parametros": {
                        "categoria": "Atractivos Naturales",
                        "subcategoria": "Montaña",
                    },
                },
                {
                    "herramienta": "busqueda_semantica",
                    "grupo": "mirador",
                    "orden": 2,
                    "parametros": {
                        "texto_embeddings": "mirador con vista panorámica y acceso en vehículo",
                        "posibles_match": ["mirador panorámico", "vista al paisaje"],
                        "excluir_terminos": [],
                    },
                },
                {
                    "herramienta": "gis",
                    "grupo": "mirador",
                    "orden": 3,
                    "parametros": {
                        "usar_ubicacion_usuario": False,
                        "distancia": None,
                        "unidad": None,
                        "punto_referencia": "Riobamba",
                        "excluir_zonas": [],
                    },
                },
            ],
        },
        True,
    ),
    (
        "EP5 retroalimentacion sem+gis",
        {
            "tipo_ejecucion": "secuencial",
            "herramientas": [
                {
                    "herramienta": "categoria_subcategoria",
                    "orden": 1,
                    "parametros": {
                        "categoria": "Atractivos Naturales",
                        "subcategoria": "Laguna",
                        "excluir_categorias": [],
                    },
                },
                {
                    "herramienta": "busqueda_semantica",
                    "orden": 2,
                    "parametros": {
                        "texto_embeddings": (
                            "laguna con fácil acceso en vehículo, se puede llegar en carro"
                        ),
                        "posibles_match": [
                            "acceso en carro",
                            "llegar en vehículo",
                            "entrada para autos",
                        ],
                        "excluir_terminos": [],
                    },
                },
                {
                    "herramienta": "gis",
                    "orden": 3,
                    "parametros": {
                        "usar_ubicacion_usuario": False,
                        "distancia": None,
                        "unidad": None,
                        "punto_referencia": "Riobamba",
                        "excluir_zonas": [],
                    },
                },
            ],
        },
        True,
    ),
    (
        "EP6 hostal economico fallback",
        {
            "tipo_ejecucion": "secuencial",
            "herramientas": [
                {
                    "herramienta": "categoria_subcategoria",
                    "orden": 1,
                    "parametros": {
                        "categoria": "Alojamiento",
                        "subcategoria": "Hotel",
                        "excluir_categorias": [],
                    },
                },
                {
                    "herramienta": "precio",
                    "orden": 2,
                    "parametros": {
                        "precio_numero": None,
                        "operador": "min",
                        "etiqueta": "economico",
                        "excluir_etiquetas": [],
                    },
                },
            ],
        },
        True,
    ),
]


def main() -> int:
    errores = 0
    print(f"Base URL: {BASE}\n")
    print(f"{'Herramienta':<28} {'HTTP':>4} {'tiempo_ms':>10} {'ok':>5} {'total':>6}  mensaje")
    print("-" * 95)

    for nombre, path, payload in CASOS:
        url = f"{BASE}{path}"
        t0 = time.perf_counter()
        try:
            resp = requests.post(url, json=payload, timeout=120)
            http_ms = round((time.perf_counter() - t0) * 1000, 1)
            data = resp.json()
            ok = data.get("ok")
            tiempo = data.get("tiempo_ms", "?")
            total = data.get("total", len(data.get("ids_sitios", data.get("ids_rutas", []))))
            msg = (data.get("mensaje") or "")[:50]
            status = resp.status_code
            if resp.status_code != 200:
                errores += 1
                ok = False
            print(
                f"{nombre:<28} {status:>4} {str(tiempo):>10} {str(ok):>5} {str(total):>6}  {msg}"
            )
            if not ok:
                errores += 1
        except Exception as exc:
            http_ms = round((time.perf_counter() - t0) * 1000, 1)
            print(f"{nombre:<28} ERR {http_ms:>8.1f}     -      -  {exc}")
            errores += 1

    for nombre, payload, espera_ok in CASOS_EJECUTAR_PLAN:
        url = f"{BASE}/api/v1/chatboot/ejecutar-plan"
        t0 = time.perf_counter()
        try:
            resp = requests.post(url, json=payload, timeout=120)
            http_ms = round((time.perf_counter() - t0) * 1000, 1)
            data = resp.json()
            ok = data.get("ok")
            tiempo = data.get("tiempo_ms", "?")
            total = len(data.get("tarjetas", []))
            passthrough = data.get("filtro_passthrough_aplicado", False)
            gis_passthrough = data.get("gis_alcance_passthrough_aplicado", False)
            retro = data.get("retroalimentacion_semantica_gis")
            recom = data.get("recomendacion_turistica")
            msg = (recom or retro or data.get("mensaje") or "")[:40]
            status = resp.status_code
            if resp.status_code != 200:
                errores += 1
                ok = False
            elif ok != espera_ok:
                errores += 1
                ok = False
            print(
                f"{nombre:<28} {status:>4} {str(tiempo):>10} {str(ok):>5} {str(total):>6}  {msg} "
                f"recom={data.get('recomendacion_fallback_aplicado', False)} "
                f"passthrough={passthrough} gis_alcance={gis_passthrough}"
            )
        except Exception as exc:
            http_ms = round((time.perf_counter() - t0) * 1000, 1)
            print(f"{nombre:<28} ERR {http_ms:>8.1f}     -      -  {exc}")
            errores += 1

    print("-" * 95)
    return errores


if __name__ == "__main__":
    raise SystemExit(main())
