# Arquitectura de APIs

## Stack

- FastAPI para rutas HTTP.
- SQLAlchemy con sesiones desde un pool de conexiones.
- PostgreSQL/PostGIS con `pgvector`.
- Pydantic para contratos de entrada y salida.
- `python-dotenv` para configuracion por `.env`.
- Redis para tokens de verificacion de correo.
- Voyage `voyage-4-lite` para embeddings.
- SMTP (Gmail) para correos transaccionales.

## Estructura

```txt
apis/
  main.py

  core/
    conexion.py
    dependencias.py
    embeddings.py
    encriptacion.py
    enviar_correo.py
    trazabilidad.py
    verificar_correo.py

  esquemas/
    autentificar.py
    atractivos.py
    contenido_chatbots.py
    cuentas_admin.py
    dashboard.py
    rutas_turisticas.py

  rutas/
    autentificar.py
    atractivos.py
    contenido_chatbots.py
    cuentas_admin.py
    dashboard.py
    rutas_turisticas.py

  servicios/
    autentificar.py
    atractivos.py
    contenido_chatbots.py
    cuentas_admin.py
    dashboard.py
    rutas_turisticas.py

  docs/
    autentificacion.md
    contratos_apis.md
    arquitectura.md
    crear_primer_admin.py
```

## Responsabilidades

`main.py` crea la aplicacion FastAPI, monta archivos estaticos de imagenes en
`/api/v1/imagenes` e incluye los routers bajo `/api/v1`.

`core/conexion.py` configura `DATABASE_URL`, el engine de SQLAlchemy y el pool
de conexiones. Cada request obtiene una sesion con `obtener_sesion`.

`core/dependencias.py` centraliza la autorizacion del panel:

| Dependencia | Uso |
|-------------|-----|
| `requerir_usuario_autenticado` | JWT valido y token vigente en BD |
| `requerir_usuario_panel` | Rol `super-admin` o `admin` |
| `requerir_super_admin` | Solo super-admin |
| `requerir_permiso(codigo)` | Permiso de modulo por usuario |
| `obtener_actor` | Username del usuario del panel para trazabilidad |

`core/embeddings.py` abstrae la generacion de vectores con Voyage.

`core/encriptacion.py` centraliza bcrypt y JWT.

`core/enviar_correo.py` envia correos de texto plano por SMTP. Lo usan
verificacion de correo y el alta de cuentas administrativas.

`core/verificar_correo.py` gestiona codigos de verificacion con Redis o memoria
local y delega el envio SMTP a `enviar_correo.py`.

`core/trazabilidad.py` registra eventos semanticos en `turismo.trazabilidad`.

`esquemas/` define los modelos Pydantic, literales permitidos por enums SQL y
respuestas de API.

`rutas/` contiene solo endpoints, dependencias de sesion y mapeo HTTP.

`servicios/` contiene la logica de negocio y consultas SQL.

## Modelo de autorizacion del panel

Roles en `chatbot.rol`:

- `usuario`: app movil/web de turistas.
- `admin`: personal del panel con permisos por modulo.
- `super-admin`: acceso total y gestion de cuentas/cargos.

Permisos en `chatbot.permiso` (catalogo de modulos):

`dashboard`, `analytics`, `attractions`, `categories`, `routes`,
`chatbot_content`, `noticias`, `admin_accounts`.

Los permisos efectivos de cada cuenta `admin` viven en `chatbot.usuario_permiso`.
Los cargos en `chatbot.cargo` y sus plantillas en `chatbot.cargo_permiso` sirven
como referencia al crear cuentas.

## Modulos actuales

### Autenticacion (`/api/v1/auth`)

Registro, login, logout, verificacion por correo, reenvio de codigo,
actualizacion de cuenta y eliminacion de cuenta.

El login del panel devuelve `permisos[]` y actualiza `ultimo_acceso_en`.

### Dashboard (`/api/v1/admin/dashboard`)

Resumen, metricas, series, distribuciones, rankings y analisis semantico.

Endpoints de resumen/metricas exigen permiso `dashboard`.
Consultas y semantica exigen permiso `analytics`.

### Atractivos (`/api/v1/admin/atractivos`)

Listado, detalle, creacion, edicion, eliminacion, subida de imagenes,
catalogos de categorias/subcategorias, cambios de estado y catalogos auxiliares.

Los endpoints de sitios exigen permiso `attractions`.
Los endpoints de categorias/subcategorias exigen permiso `categories`.

`turismo.horario` guarda `abierto_24h`, `activo` y `comentario` opcional
(maximo 200 caracteres) para notas como "Solo con reservacion previa".

### Rutas turisticas (`/api/v1/admin/rutas-turisticas`)

Listado, creacion, edicion, eliminacion fisica, cambio de estado, subida de
imagen de referencia y administracion de geometria/puntos.

Exige permiso `routes`.

### Contenido chatbots (`/api/v1/admin/contenido-chatbots`)

Repositorios y documentos Markdown con secciones embebibles para chatbots.

Exige permiso `chatbot_content`.

### Cuentas administrativas (`/api/v1/admin/cuentas`)

CRUD de cuentas `admin`, cambio de estado y eliminacion fisica.

Solo `super-admin`.

Al crear una cuenta:

1. Se genera una contrasena temporal aleatoria.
2. Se guarda hasheada en `chatbot.usuario`.
3. Se envia por correo al email de la cuenta.
4. Si el correo falla, se hace rollback de la transaccion.

### Cargos y permisos (`/api/v1/admin/cargos`, `/api/v1/admin/permisos`)

CRUD de cargos con plantillas de modulos y catalogo de permisos del panel.

Solo `super-admin`.

## Imagenes

Las imagenes se guardan en:

```txt
fuente_datos/imagenes/
```

Se sirven desde:

```txt
/api/v1/imagenes
```

La API solo elimina archivos locales si la URL pertenece al prefijo
`/api/v1/imagenes/...`. Las URLs externas no se tocan.

## Trazabilidad

Los servicios administrativos registran eventos en `turismo.trazabilidad` con
acciones semanticas (`login`, `creacion_cuenta_admin`, `INSERT`, `UPDATE`, etc.).

## Convenciones

- Mantener los endpoints delgados en `rutas/`.
- Mantener validaciones de negocio y SQL en `servicios/`.
- Mantener contratos de entrada/salida en `esquemas/`.
- Usar literales Pydantic cuando el valor proviene de un enum SQL.
- No duplicar logica de embeddings, correo ni autorizacion fuera de `core/`.
- Actualizar `docs/contratos_apis.md` y `docs/autentificacion.md` cuando cambie
  un endpoint o regla de seguridad.
