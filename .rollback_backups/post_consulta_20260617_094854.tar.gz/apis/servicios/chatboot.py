import re
import time
import unicodedata
import requests
import random
from collections import defaultdict
from datetime import datetime
from datetime import time as dt_time
from typing import Any, Literal
from zoneinfo import ZoneInfo

from rapidfuzz import fuzz
from sqlalchemy import text
from sqlalchemy.orm import Session

from core.embeddings import generar_embedding
from esquemas.chatboot import (
    AlcanceAplicado,
    BusquedaAproximadaRequest,
    BusquedaAproximadaResponse,
    CategoriaSubcategoriaRequest,
    CategoriaSubcategoriaResponse,
    CamposParametrizadosRequest,
    CamposParametrizadosResponse,
    ContactosRequest,
    ContactosResponse,
    CandidatoSitioDebugItem,
    ContactoItem,
    SitioCategoriaItem,
    SitioCampoParamItem,
    SitioContactoItem,
    EjecutarPlanRequest,
    EjecutarPlanResponse,
    TarjetaSitio,
    HorarioRequest,
    HorarioResponse,
    HorarioDetalleItem,
    SitioHorarioItem,
    PrecioRequest,
    PrecioResponse,
    SitioPrecioItem,
    TarifaAccesoRequest,
    TarifaAccesoResponse,
    SitioTarifaAccesoItem,
    RutaRequest,
    RutaResponse,
    RutaItem,
    GisRequest,
    GisResponse,
    SitioGisItem,
    BusquedaSemanticaRequest,
    BusquedaSemanticaResponse,
    CandidatoSemanticoDebugItem,
    SitioSemanticoItem,
    TarjetaRuta,
)
from .exploracion_fallback import (
    MENSAJE_FALLBACK_FRIO,
    construir_mensaje_recomendacion,
    debe_aplicar_recomendacion_calida,
    generar_fallback_frio,
    marcar_recomendacion_en_campos,
)

UMBRAL_SITIO = 0.70
UMBRAL_CANDIDATO = 0.25
UMBRAL_EXCLUSION = 0.55
MAX_SITIOS = 5
TOP_SITIOS_TRGM = 5
DELTA_PRIORIDAD = 0.05

PALABRAS_VIA = frozenset({
    "calle",
    "calles",
    "avenida",
    "avenidas",
    "av",
    "ave",
    "pasaje",
    "pasajes",
    "pj",
    "via",
    "ruta",
    "rutas",
    "blvd",
    "boulevard",
    "boulevar",
})

TOKENS_CONECTOR = frozenset({
    "y",
    "de",
    "del",
    "la",
    "el",
    "las",
    "los",
    "en",
    "e",
})

PESO_RATIO = 0.20
PESO_TOKEN_SORT = 0.20
PESO_COBERTURA_PROM = 0.40
PESO_COBERTURA_MIN = 0.20
UMBRAL_TOKEN_MINIMO = 0.55
UMBRAL_COBERTURA_PROM = 0.70
UMBRAL_CATALOGO = 0.40
RADIO_BUSQUEDA_DEFECTO_M = 500.0
RADIOS_GIS_PROGRESIVOS_M = (500.0, 1000.0, 1500.0)
RADIO_GIS_MAX_M = 1500.0
TZ_RIOBAMBA = ZoneInfo("America/Guayaquil")

_TRANSLATE_ACENTOS_SQL = (
    "translate(lower({campo}), "
    "'áéíóúüñàèìòùâêîôûãõç', "
    "'aeiouunaeiouaeiouaoc')"
)

TipoCandidato = Literal["direccion", "parroquia", "plataforma"]
FuenteGanadora = Literal["direccion", "parroquia", "plataforma", "ninguna"]


def _normalizar_texto(texto: str) -> str:
    return re.sub(r"\s+", " ", texto.strip().lower())


def _sin_acentos(texto: str) -> str:
    normalizado = unicodedata.normalize("NFKD", texto)
    return "".join(caracter for caracter in normalizado if not unicodedata.combining(caracter))


def _es_palabra_via(palabra: str) -> bool:
    return _sin_acentos(palabra.lower().rstrip(".")) in PALABRAS_VIA


def _quitar_prefijos_via(texto: str) -> str:
    palabras = [
        palabra
        for palabra in _normalizar_texto(texto).split()
        if not _es_palabra_via(palabra)
    ]
    return " ".join(palabras)


def _params_texto_busqueda(texto: str, texto_limpio: str) -> dict[str, str]:
    texto_ascii = _sin_acentos(texto)
    limpio_ascii = _sin_acentos(texto_limpio) or texto_ascii
    return {
        "texto_ascii": texto_ascii,
        "limpio_ascii": limpio_ascii,
    }


def _sql_ascii(campo: str) -> str:
    return _TRANSLATE_ACENTOS_SQL.format(campo=campo)


def _sql_score_trgm(campo: str) -> str:
    ascii_campo = _sql_ascii(campo)
    return f"""GREATEST(
        similarity({ascii_campo}, :texto_ascii),
        similarity({ascii_campo}, :limpio_ascii),
        word_similarity({ascii_campo}, :texto_ascii),
        word_similarity({ascii_campo}, :limpio_ascii)
    )"""


def _tokens_significativos(texto: str) -> list[str]:
    tokens = re.findall(r"[a-z0-9]+", _sin_acentos(_normalizar_texto(texto)))
    return [
        token
        for token in tokens
        if token not in TOKENS_CONECTOR and (len(token) > 1 or token.isdigit())
    ]


def _mejor_match_token(token: str, destino_tokens: list[str]) -> float:
    if not destino_tokens:
        return 0.0
    return max(fuzz.ratio(token, destino_token) for destino_token in destino_tokens) / 100.0


def _cobertura_tokens(
    consulta_tokens: list[str],
    destino_tokens: list[str],
) -> tuple[float, float]:
    if not consulta_tokens:
        return 1.0, 1.0

    scores = [_mejor_match_token(token, destino_tokens) for token in consulta_tokens]
    return sum(scores) / len(scores), min(scores)


def _score_rapidfuzz(consulta: str, destino: str) -> float:
    consulta_norm = _sin_acentos(_normalizar_texto(consulta))
    destino_norm = _sin_acentos(_normalizar_texto(destino))
    if not consulta_norm or not destino_norm:
        return 0.0

    consulta_tokens = _tokens_significativos(consulta_norm)
    destino_tokens = _tokens_significativos(destino_norm)

    ratio = fuzz.ratio(consulta_norm, destino_norm) / 100.0
    token_sort = fuzz.token_sort_ratio(consulta_norm, destino_norm) / 100.0

    if len(consulta_tokens) <= 1:
        return round(max(ratio, token_sort), 4)

    cobertura_prom, cobertura_min = _cobertura_tokens(consulta_tokens, destino_tokens)
    score = (
        ratio * PESO_RATIO
        + token_sort * PESO_TOKEN_SORT
        + cobertura_prom * PESO_COBERTURA_PROM
        + cobertura_min * PESO_COBERTURA_MIN
    )

    if cobertura_min < UMBRAL_TOKEN_MINIMO:
        score = min(score, cobertura_min + 0.05)
    if cobertura_prom < UMBRAL_COBERTURA_PROM:
        score = min(score, cobertura_prom * 0.85)

    return round(min(score, 1.0), 4)


def _score_final(score_trgm: float, score_rapidfuzz: float) -> float:
    return round(max(score_trgm, score_rapidfuzz), 4)


def _contar_palabras(texto: str) -> int:
    return len(texto.split()) if texto else 0


def _normalizar_excluir(excluir: list[str]) -> list[str]:
    return [_normalizar_texto(item) for item in excluir if item and item.strip()]


def _resolver_id_categoria(
    db: Session,
    nombre: str,
) -> tuple[int | None, str | None]:
    texto_ascii = _sin_acentos(_normalizar_texto(nombre))
    row = db.execute(
        text(
            f"""
            SELECT
                id_categoria,
                nombre,
                {_sql_score_trgm("nombre")} AS score
            FROM turismo.categoria
            WHERE activo = TRUE
              AND {_sql_score_trgm("nombre")} > :umbral_catalogo
            ORDER BY score DESC
            LIMIT 1
            """
        ),
        {
            "texto_ascii": texto_ascii,
            "limpio_ascii": texto_ascii,
            "umbral_catalogo": UMBRAL_CATALOGO,
        },
    ).mappings().first()
    if not row:
        return None, None
    return int(row["id_categoria"]), row["nombre"]


def _resolver_id_subcategoria(
    db: Session,
    nombre: str,
    id_categoria: int | None = None,
) -> tuple[int | None, str | None]:
    texto_ascii = _sin_acentos(_normalizar_texto(nombre))
    filtro_categoria = ""
    params: dict[str, Any] = {
        "texto_ascii": texto_ascii,
        "limpio_ascii": texto_ascii,
        "umbral_catalogo": UMBRAL_CATALOGO,
    }
    if id_categoria is not None:
        filtro_categoria = "AND id_categoria = :id_categoria"
        params["id_categoria"] = id_categoria

    row = db.execute(
        text(
            f"""
            SELECT
                id_subcategoria,
                nombre,
                {_sql_score_trgm("nombre")} AS score
            FROM turismo.subcategoria
            WHERE activo = TRUE
              AND {_sql_score_trgm("nombre")} > :umbral_catalogo
              {filtro_categoria}
            ORDER BY score DESC
            LIMIT 1
            """
        ),
        params,
    ).mappings().first()
    if not row:
        return None, None
    return int(row["id_subcategoria"]), row["nombre"]


def _construir_alcance_sitios(
    db: Session,
    categoria: str | None,
    subcategoria: str | None,
    ids_sitios_candidatos: list[int],
) -> tuple[list[str], dict[str, Any], AlcanceAplicado, dict[str, Any]]:
    filtros: list[str] = []
    params: dict[str, Any] = {}
    meta: dict[str, Any] = {
        "categoria_resuelta": None,
        "subcategoria_resuelta": None,
        "ids_sitios_candidatos_aplicados": [],
    }

    ids_validos = sorted({int(item) for item in ids_sitios_candidatos if item > 0})
    if ids_validos:
        filtros.append("s.id_sitio = ANY(:ids_sitios)")
        params["ids_sitios"] = ids_validos
        meta["ids_sitios_candidatos_aplicados"] = ids_validos
        return filtros, params, "ids_candidatos", meta

    id_categoria: int | None = None
    if categoria and categoria.strip():
        id_categoria, nombre_categoria = _resolver_id_categoria(db, categoria)
        if id_categoria is None:
            raise ValueError(f"No se pudo resolver la categoria '{categoria}'.")
        filtros.append("s.id_categoria = :id_categoria")
        params["id_categoria"] = id_categoria
        meta["categoria_resuelta"] = nombre_categoria

    if subcategoria and subcategoria.strip():
        id_subcategoria, nombre_subcategoria = _resolver_id_subcategoria(
            db,
            subcategoria,
            id_categoria,
        )
        if id_subcategoria is None:
            raise ValueError(f"No se pudo resolver la subcategoria '{subcategoria}'.")
        filtros.append("s.id_subcategoria = :id_subcategoria")
        params["id_subcategoria"] = id_subcategoria
        meta["subcategoria_resuelta"] = nombre_subcategoria
        return filtros, params, "subcategoria", meta

    if id_categoria is not None:
        return filtros, params, "categoria", meta

    return filtros, params, "todos", meta


def _buscar_por_direccion(
    db: Session,
    texto: str,
    texto_limpio: str,
    filtros_alcance: list[str] | None = None,
    params_alcance: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    score_direccion = _sql_score_trgm("d.direccion_texto")
    score_referencia = _sql_score_trgm("COALESCE(d.referencia_adicional, '')")
    alcance_sql = ""
    if filtros_alcance:
        alcance_sql = " AND " + " AND ".join(filtros_alcance)

    params = {
        **_params_texto_busqueda(texto, texto_limpio),
        "umbral_candidato": UMBRAL_CANDIDATO,
        "limite_trgm": TOP_SITIOS_TRGM,
        **(params_alcance or {}),
    }
    rows = db.execute(
        text(
            f"""
            SELECT
                s.id_sitio,
                s.nombre,
                d.direccion_texto,
                d.referencia_adicional,
                COALESCE(p.nombre, '') AS parroquia_nombre,
                COALESCE(pl.nombre, '') AS plataforma_nombre,
                GREATEST(
                    {score_direccion},
                    {score_referencia}
                ) AS score_trgm,
                CASE
                    WHEN {score_direccion} >= {score_referencia}
                    THEN 'direccion_texto'
                    ELSE 'referencia_adicional'
                END AS campo_match
            FROM turismo.direccion d
            JOIN turismo.sitio s ON s.id_sitio = d.id_sitio
            LEFT JOIN turismo.parroquia p ON p.id_parroquia = s.id_parroquia
            LEFT JOIN turismo.plataforma pl ON pl.id_plataforma = s.id_plataforma
            WHERE s.activo = TRUE
              {alcance_sql}
              AND (
                {score_direccion} > :umbral_candidato
                OR {score_referencia} > :umbral_candidato
              )
            ORDER BY score_trgm DESC
            LIMIT :limite_trgm
            """
        ),
        params,
    ).mappings().all()
    return [dict(row) for row in rows]


def _buscar_por_parroquia(
    db: Session,
    texto: str,
    texto_limpio: str,
) -> list[dict[str, Any]]:
    score_nombre = _sql_score_trgm("nombre")
    rows = db.execute(
        text(
            f"""
            SELECT
                id_parroquia,
                nombre,
                {score_nombre} AS score_trgm
            FROM turismo.parroquia
            WHERE activo = TRUE
              AND {score_nombre} > :umbral_candidato
            ORDER BY score_trgm DESC
            LIMIT :limite_trgm
            """
        ),
        {
            **_params_texto_busqueda(texto, texto_limpio),
            "umbral_candidato": UMBRAL_CANDIDATO,
            "limite_trgm": TOP_SITIOS_TRGM,
        },
    ).mappings().all()
    return [dict(row) for row in rows]


def _buscar_por_plataforma(
    db: Session,
    texto: str,
    texto_limpio: str,
) -> list[dict[str, Any]]:
    score_nombre = _sql_score_trgm("pl.nombre")
    rows = db.execute(
        text(
            f"""
            SELECT
                pl.id_plataforma,
                pl.id_parroquia,
                pl.nombre,
                p.nombre AS parroquia_nombre,
                {score_nombre} AS score_trgm
            FROM turismo.plataforma pl
            JOIN turismo.parroquia p ON p.id_parroquia = pl.id_parroquia
            WHERE pl.activo = TRUE
              AND p.activo = TRUE
              AND {score_nombre} > :umbral_candidato
            ORDER BY score_trgm DESC
            LIMIT :limite_trgm
            """
        ),
        {
            **_params_texto_busqueda(texto, texto_limpio),
            "umbral_candidato": UMBRAL_CANDIDATO,
            "limite_trgm": TOP_SITIOS_TRGM,
        },
    ).mappings().all()
    return [dict(row) for row in rows]


def _rescore_candidatos_direccion(
    candidatos: list[dict[str, Any]],
    texto_limpio: str,
) -> list[dict[str, Any]]:
    rescored: list[dict[str, Any]] = []
    for candidato in candidatos:
        score_trgm = round(float(candidato["score_trgm"]), 4)
        direccion = candidato.get("direccion_texto") or ""
        referencia = candidato.get("referencia_adicional") or ""
        score_rf_direccion = _score_rapidfuzz(texto_limpio, direccion)
        score_rf_referencia = _score_rapidfuzz(texto_limpio, referencia)
        if score_rf_referencia > score_rf_direccion and referencia.strip():
            score_rapidfuzz = score_rf_referencia
            campo_match = "referencia_adicional"
        else:
            score_rapidfuzz = score_rf_direccion
            campo_match = "direccion_texto"

        item = dict(candidato)
        item["campo_match"] = campo_match
        item["score_trgm"] = score_trgm
        item["score_rapidfuzz"] = score_rapidfuzz
        item["score"] = _score_final(score_trgm, score_rapidfuzz)
        rescored.append(item)

    rescored.sort(key=lambda candidato: candidato["score"], reverse=True)
    return rescored


def _rescore_candidatos_nombre(
    candidatos: list[dict[str, Any]],
    texto_limpio: str,
) -> list[dict[str, Any]]:
    rescored: list[dict[str, Any]] = []
    for candidato in candidatos:
        score_trgm = round(float(candidato["score_trgm"]), 4)
        nombre = candidato.get("nombre") or ""
        score_rapidfuzz = _score_rapidfuzz(texto_limpio, nombre)
        item = dict(candidato)
        item["score_trgm"] = score_trgm
        item["score_rapidfuzz"] = score_rapidfuzz
        item["score"] = _score_final(score_trgm, score_rapidfuzz)
        rescored.append(item)

    rescored.sort(key=lambda candidato: candidato["score"], reverse=True)
    return rescored


def _contexto_candidato(candidato: dict[str, Any], tipo: TipoCandidato) -> str:
    if tipo == "direccion":
        partes = [
            candidato.get("direccion_texto") or "",
            candidato.get("referencia_adicional") or "",
            candidato.get("parroquia_nombre") or "",
            candidato.get("plataforma_nombre") or "",
        ]
    elif tipo == "parroquia":
        partes = [candidato.get("nombre") or ""]
    else:
        partes = [
            candidato.get("nombre") or "",
            candidato.get("parroquia_nombre") or "",
        ]
    return _sin_acentos(_normalizar_texto(" ".join(partes)))


def _esta_excluido(db: Session, contexto: str, excluir: list[str]) -> bool:
    if not excluir or not contexto:
        return False

    contexto_ascii = _sin_acentos(contexto)
    for termino in excluir:
        termino_ascii = _sin_acentos(termino)
        score = db.execute(
            text(
                """
                SELECT GREATEST(
                    similarity(:contexto, :termino),
                    word_similarity(:contexto, :termino)
                ) AS score
                """
            ),
            {"contexto": contexto_ascii, "termino": termino_ascii},
        ).scalar()
        if score is not None and float(score) >= UMBRAL_EXCLUSION:
            return True
    return False


def _aplicar_exclusiones(
    db: Session,
    candidatos: list[dict[str, Any]],
    excluir: list[str],
    tipo: TipoCandidato,
) -> list[dict[str, Any]]:
    if not excluir:
        return candidatos

    filtrados: list[dict[str, Any]] = []
    for candidato in candidatos:
        contexto = _contexto_candidato(candidato, tipo)
        if not _esta_excluido(db, contexto, excluir):
            filtrados.append(candidato)
    return filtrados


def _max_score(candidatos: list[dict[str, Any]]) -> float:
    if not candidatos:
        return 0.0
    return max(float(c["score"]) for c in candidatos)


def _resolver_fuente_ganadora(
    score_direccion: float,
    score_parroquia: float,
    score_plataforma: float,
    palabras: int,
) -> FuenteGanadora:
    scores = {
        "direccion": score_direccion,
        "parroquia": score_parroquia,
        "plataforma": score_plataforma,
    }
    max_score = max(scores.values())
    if max_score <= 0:
        return "ninguna"

    ganadores = [fuente for fuente, score in scores.items() if score == max_score]
    if len(ganadores) == 1:
        return ganadores[0]

    if palabras > 3:
        if "direccion" in ganadores:
            return "direccion"
        return "plataforma" if score_plataforma >= score_parroquia else "parroquia"

    if "parroquia" in ganadores and "plataforma" in ganadores:
        return "plataforma" if score_plataforma >= score_parroquia else "parroquia"
    if "parroquia" in ganadores:
        return "parroquia"
    if "plataforma" in ganadores:
        return "plataforma"
    return "direccion"


def _construir_top_sitios_debug(
    candidatos: list[dict[str, Any]],
    db: Session,
    excluir: list[str],
    limit: int = TOP_SITIOS_TRGM,
) -> list[CandidatoSitioDebugItem]:
    items: list[CandidatoSitioDebugItem] = []
    for candidato in candidatos[:limit]:
        contexto = _contexto_candidato(candidato, "direccion")
        descartado = _esta_excluido(db, contexto, excluir) if excluir else False
        score = float(candidato["score"])
        items.append(
            CandidatoSitioDebugItem(
                id_sitio=int(candidato["id_sitio"]),
                nombre=candidato["nombre"],
                direccion_texto=candidato["direccion_texto"],
                score=round(score, 4),
                score_trgm=round(float(candidato["score_trgm"]), 4),
                score_rapidfuzz=round(float(candidato["score_rapidfuzz"]), 4),
                similitud_porcentaje=round(score * 100, 2),
                campo_match=candidato["campo_match"],
                descartado_por_exclusion=descartado,
            )
        )
    return items


def _aplicar_prioridad_empate(
    fuente: FuenteGanadora,
    score_direccion: float,
    score_parroquia: float,
    score_plataforma: float,
    palabras: int,
) -> FuenteGanadora:
    if fuente == "ninguna":
        return fuente

    scores = {
        "direccion": score_direccion,
        "parroquia": score_parroquia,
        "plataforma": score_plataforma,
    }
    mejor_score = scores[fuente]
    empates = [
        nombre
        for nombre, score in scores.items()
        if abs(score - mejor_score) < DELTA_PRIORIDAD and score > 0
    ]
    if len(empates) <= 1:
        return fuente

    if palabras > 3:
        if "direccion" in empates:
            return "direccion"
    else:
        if "plataforma" in empates or "parroquia" in empates:
            return "plataforma" if score_plataforma >= score_parroquia else "parroquia"

    return fuente


def categoria_subcategoria(
    db: Session,
    payload: CategoriaSubcategoriaRequest,
) -> CategoriaSubcategoriaResponse:
    inicio = time.perf_counter()

    try:
        filtros_alcance, params_alcance, alcance_aplicado, meta_alcance = (
            _construir_alcance_sitios(
                db,
                payload.categoria,
                payload.subcategoria,
                payload.ids_sitios_candidatos,
            )
        )
    except ValueError as exc:
        tiempo_ms = round((time.perf_counter() - inicio) * 1000, 2)
        return CategoriaSubcategoriaResponse(
            ok=False,
            total=0,
            tiempo_ms=tiempo_ms,
            mensaje=str(exc),
        )

    categorias_excluidas = _normalizar_excluir(payload.excluir_categorias)
    
    filtros_sql = [
        "s.activo = TRUE",
        *filtros_alcance,
    ]
    params: dict[str, Any] = {**params_alcance}

    if categorias_excluidas:
        # Excluir tanto por categoría como por subcategoría usando ILIKE
        condiciones_exclusion = []
        for i, termino in enumerate(categorias_excluidas):
            key = f"excluir_cat_{i}"
            condiciones_exclusion.append(f"c.nombre ILIKE :{key} OR sub.nombre ILIKE :{key}")
            params[key] = f"%{termino}%"
        
        filtros_sql.append(f"NOT ({' OR '.join(condiciones_exclusion)})")

    query = f"""
        SELECT 
            s.id_sitio,
            s.nombre
        FROM turismo.sitio s
        LEFT JOIN turismo.categoria c ON c.id_categoria = s.id_categoria
        LEFT JOIN turismo.subcategoria sub ON sub.id_subcategoria = s.id_subcategoria
        WHERE {' AND '.join(filtros_sql)}
        ORDER BY s.id_sitio
    """

    rows = db.execute(text(query), params).mappings().all()

    sitios_coincidentes = [
        SitioCategoriaItem(
            id_sitio=int(row["id_sitio"]),
            nombre=row["nombre"],
        )
        for row in rows
    ]

    tiempo_ms = round((time.perf_counter() - inicio) * 1000, 2)
    total = len(sitios_coincidentes)
    
    respuesta_alcance = {
        "alcance_aplicado": alcance_aplicado,
        "categoria_resuelta": meta_alcance.get("categoria_resuelta"),
        "subcategoria_resuelta": meta_alcance.get("subcategoria_resuelta"),
        "ids_sitios_candidatos_aplicados": meta_alcance.get(
            "ids_sitios_candidatos_aplicados", []
        ),
        "excluir_categorias_aplicadas": categorias_excluidas,
    }

    if total == 0:
        return CategoriaSubcategoriaResponse(
            ok=False,
            total=0,
            tiempo_ms=tiempo_ms,
            mensaje="No se encontraron sitios para la categoria/subcategoria especificada.",
            **respuesta_alcance,
        )

    return CategoriaSubcategoriaResponse(
        ok=True,
        total=total,
        ids_sitios=[sitio.id_sitio for sitio in sitios_coincidentes],
        sitios=sitios_coincidentes,
        tiempo_ms=tiempo_ms,
        mensaje=f"Se encontraron {total} sitio(s) para la categoria/subcategoria.",
        **respuesta_alcance,
    )


def busqueda_aproximada(
    db: Session,
    payload: BusquedaAproximadaRequest,
) -> BusquedaAproximadaResponse:
    inicio = time.perf_counter()

    texto = _normalizar_texto(payload.direccion_referencia)
    if not texto:
        tiempo_ms = (time.perf_counter() - inicio) * 1000
        return BusquedaAproximadaResponse(
            ok=False,
            direccion_referencia_consultada=payload.direccion_referencia.strip(),
            tipo_resultado="ninguno",
            fuente="ninguna",
            excluir_aplicado=[],
            top_sitios_direccion=[],
            tiempo_ms=round(tiempo_ms, 2),
            mensaje="La direccion o referencia consultada no puede estar vacia.",
        )

    try:
        filtros_alcance, params_alcance, alcance_aplicado, meta_alcance = (
            _construir_alcance_sitios(
                db,
                payload.categoria,
                payload.subcategoria,
                payload.ids_sitios_candidatos,
            )
        )
    except ValueError as exc:
        tiempo_ms = round((time.perf_counter() - inicio) * 1000, 2)
        return BusquedaAproximadaResponse(
            ok=False,
            direccion_referencia_consultada=texto,
            tipo_resultado="ninguno",
            fuente="ninguna",
            tiempo_ms=tiempo_ms,
            mensaje=str(exc),
        )

    texto_limpio = _quitar_prefijos_via(texto) or texto
    excluir = _normalizar_excluir(payload.excluir)
    palabras = _contar_palabras(texto_limpio)

    candidatos_direccion = _rescore_candidatos_direccion(
        _buscar_por_direccion(
            db,
            texto,
            texto_limpio,
            filtros_alcance,
            params_alcance,
        ),
        texto_limpio,
    )
    candidatos_parroquia = _rescore_candidatos_nombre(
        _buscar_por_parroquia(db, texto, texto_limpio),
        texto_limpio,
    )
    candidatos_plataforma = _rescore_candidatos_nombre(
        _buscar_por_plataforma(db, texto, texto_limpio),
        texto_limpio,
    )

    candidatos_direccion = _aplicar_exclusiones(
        db, candidatos_direccion, excluir, "direccion"
    )
    candidatos_parroquia = _aplicar_exclusiones(
        db, candidatos_parroquia, excluir, "parroquia"
    )
    candidatos_plataforma = _aplicar_exclusiones(
        db, candidatos_plataforma, excluir, "plataforma"
    )

    top_sitios_direccion = _construir_top_sitios_debug(
        candidatos_direccion, db, excluir
    )

    score_direccion = _max_score(candidatos_direccion)
    score_parroquia = _max_score(candidatos_parroquia)
    score_plataforma = _max_score(candidatos_plataforma)

    fuente = _resolver_fuente_ganadora(
        score_direccion, score_parroquia, score_plataforma, palabras
    )
    fuente = _aplicar_prioridad_empate(
        fuente, score_direccion, score_parroquia, score_plataforma, palabras
    )

    tiempo_ms = round((time.perf_counter() - inicio) * 1000, 2)
    respuesta_base = {
        "direccion_referencia_consultada": texto,
        "texto_sin_prefijos_via": texto_limpio,
        "alcance_aplicado": alcance_aplicado,
        "categoria_resuelta": meta_alcance.get("categoria_resuelta"),
        "subcategoria_resuelta": meta_alcance.get("subcategoria_resuelta"),
        "ids_sitios_candidatos_aplicados": meta_alcance.get(
            "ids_sitios_candidatos_aplicados", []
        ),
        "excluir_aplicado": excluir,
        "top_sitios_direccion": top_sitios_direccion,
        "tiempo_ms": tiempo_ms,
    }

    if fuente == "direccion":
        sitios_validos = [
            c for c in candidatos_direccion if float(c["score"]) >= UMBRAL_SITIO
        ][:MAX_SITIOS]
        if sitios_validos:
            from esquemas.chatboot import SitioBusquedaAproximadaItem
            return BusquedaAproximadaResponse(
                ok=True,
                tipo_resultado="sitio",
                fuente="direccion",
                ids_sitios=[int(s["id_sitio"]) for s in sitios_validos],
                sitios=[
                    SitioBusquedaAproximadaItem(
                        id_sitio=int(s["id_sitio"]),
                        nombre=s["nombre"],
                        direccion_texto=s.get("direccion_texto") or "",
                        referencia_adicional=s.get("referencia_adicional"),
                    )
                    for s in sitios_validos
                ],
                mensaje=(
                    f"Se encontraron {len(sitios_validos)} sitio(s) por similitud "
                    f"en direccion con score >= {UMBRAL_SITIO:.0%}."
                ),
                **respuesta_base,
            )
        return BusquedaAproximadaResponse(
            ok=False,
            tipo_resultado="ninguno",
            fuente="direccion",
            mensaje=(
                f"La mejor coincidencia fue en direccion pero ningun sitio alcanzo "
                f"el umbral de {UMBRAL_SITIO:.0%}."
            ),
            **respuesta_base,
        )

    if fuente == "parroquia" and candidatos_parroquia:
        mejor = candidatos_parroquia[0]
        return BusquedaAproximadaResponse(
            ok=True,
            tipo_resultado="parroquia",
            fuente="parroquia",
            nombre=mejor["nombre"],
            mensaje=f"Parroquia identificada: {mejor['nombre']}.",
            **respuesta_base,
        )

    if fuente == "plataforma" and candidatos_plataforma:
        mejor = candidatos_plataforma[0]
        return BusquedaAproximadaResponse(
            ok=True,
            tipo_resultado="plataforma",
            fuente="plataforma",
            nombre=mejor["nombre"],
            mensaje=f"Plataforma identificada: {mejor['nombre']}.",
            **respuesta_base,
        )

    return BusquedaAproximadaResponse(
        ok=False,
        tipo_resultado="ninguno",
        fuente="ninguna",
        mensaje="No se encontraron coincidencias aproximadas para la consulta.",
        **respuesta_base,
    )


CAMPOS_BOOLEANOS: dict[str, tuple[str, ...]] = {
    "tiene_wifi": ("tiene_wifi", "wifi", "wi-fi", "wi fi"),
    "permite_mascotas": ("permite_mascotas", "mascotas", "mascota"),
    "accesibilidad": ("accesibilidad", "accesible"),
    "parqueadero": ("parqueadero", "estacionamiento", "parking"),
    "es_gratuito": ("es_gratuito", "gratuito", "gratis", "gratuita"),
}


def _normalizar_termino_exclusion(termino: str) -> str:
    return _sin_acentos(_normalizar_texto(termino))


def _resolver_campo_por_termino(termino: str) -> str | None:
    termino_norm = _normalizar_termino_exclusion(termino)
    for campo, alias in CAMPOS_BOOLEANOS.items():
        if termino_norm in {_normalizar_termino_exclusion(item) for item in alias}:
            return campo
    return None


def _campos_excluidos(excluir: list[str]) -> set[str]:
    campos: set[str] = set()
    for termino in excluir:
        campo = _resolver_campo_por_termino(termino)
        if campo:
            campos.add(campo)
    return campos


def _tiene_filtros_activos(payload: CamposParametrizadosRequest) -> bool:
    valores = (
        payload.tiene_wifi,
        payload.permite_mascotas,
        payload.accesibilidad,
        payload.parqueadero,
        payload.es_gratuito,
    )
    return any(valor is not None for valor in valores) or bool(payload.excluir)


def campos_parametrizados(
    db: Session,
    payload: CamposParametrizadosRequest,
) -> CamposParametrizadosResponse:
    inicio = time.perf_counter()

    if not _tiene_filtros_activos(payload):
        tiempo_ms = round((time.perf_counter() - inicio) * 1000, 2)
        return CamposParametrizadosResponse(
            ok=False,
            total=0,
            filtros_aplicados={},
            excluir_aplicado=[],
            tiempo_ms=tiempo_ms,
            mensaje="Debe indicar al menos un campo booleano o una exclusion.",
        )

    try:
        filtros_alcance, params_alcance, alcance_aplicado, meta_alcance = (
            _construir_alcance_sitios(
                db,
                payload.categoria,
                payload.subcategoria,
                payload.ids_sitios_candidatos,
            )
        )
    except ValueError as exc:
        tiempo_ms = round((time.perf_counter() - inicio) * 1000, 2)
        return CamposParametrizadosResponse(
            ok=False,
            total=0,
            tiempo_ms=tiempo_ms,
            mensaje=str(exc),
        )

    excluir = [
        _normalizar_termino_exclusion(item)
        for item in payload.excluir
        if item and item.strip()
    ]
    campos_excluidos = _campos_excluidos(excluir)

    filtros_sql = ["s.activo = TRUE", *filtros_alcance]
    filtros_aplicados: dict[str, bool] = {}
    params: dict[str, Any] = dict(params_alcance)

    for campo in CAMPOS_BOOLEANOS:
        valor = getattr(payload, campo)
        if valor is not None:
            filtros_sql.append(f"s.{campo} = :{campo}")
            params[campo] = valor
            filtros_aplicados[campo] = valor
        elif campo in campos_excluidos:
            filtros_sql.append(f"(s.{campo} IS NULL OR s.{campo} = FALSE)")

    rows = db.execute(
        text(
            f"""
            SELECT
                s.id_sitio,
                s.nombre,
                s.tiene_wifi,
                s.permite_mascotas,
                s.accesibilidad,
                s.parqueadero,
                s.es_gratuito
            FROM turismo.sitio s
            WHERE {' AND '.join(filtros_sql)}
            ORDER BY s.nombre ASC
            """
        ),
        params,
    ).mappings().all()

    sitios = [
        SitioCampoParamItem(
            id_sitio=int(row["id_sitio"]),
            nombre=row["nombre"],
            tiene_wifi=row["tiene_wifi"],
            permite_mascotas=row["permite_mascotas"],
            accesibilidad=row["accesibilidad"],
            parqueadero=row["parqueadero"],
            es_gratuito=row["es_gratuito"],
        )
        for row in rows
    ]

    tiempo_ms = round((time.perf_counter() - inicio) * 1000, 2)
    total = len(sitios)
    respuesta_alcance = {
        "alcance_aplicado": alcance_aplicado,
        "categoria_resuelta": meta_alcance.get("categoria_resuelta"),
        "subcategoria_resuelta": meta_alcance.get("subcategoria_resuelta"),
        "ids_sitios_candidatos_aplicados": meta_alcance.get(
            "ids_sitios_candidatos_aplicados", []
        ),
    }

    if total == 0:
        return CamposParametrizadosResponse(
            ok=False,
            total=0,
            filtros_aplicados=filtros_aplicados,
            excluir_aplicado=excluir,
            tiempo_ms=tiempo_ms,
            mensaje="No se encontraron sitios que cumplan los filtros indicados.",
            **respuesta_alcance,
        )

    return CamposParametrizadosResponse(
        ok=True,
        total=total,
        ids_sitios=[sitio.id_sitio for sitio in sitios],
        sitios=sitios,
        filtros_aplicados=filtros_aplicados,
        excluir_aplicado=excluir,
        tiempo_ms=tiempo_ms,
        mensaje=f"Se encontraron {total} sitio(s) que cumplen los filtros.",
        **respuesta_alcance,
    )


TIPOS_CONTACTO: dict[str, tuple[str, ...]] = {
    "telefono": ("telefono", "teléfono", "celular", "movil", "móvil", "llamar", "fono"),
    "whatsapp": ("whatsapp", "whats app", "wsp", "wa", "whattsapp"),
    "email": ("email", "correo", "e-mail", "mail"),
    "web": ("web", "pagina_web", "pagina web", "sitio web", "website", "url", "pagina"),
    "facebook": ("facebook", "fb"),
    "instagram": ("instagram", "ig", "insta"),
    "tiktok": ("tiktok",),
    "otro": ("otro",),
}


def _resolver_tipo_contacto(texto: str) -> str | None:
    termino = _normalizar_termino_exclusion(texto)
    for tipo, alias in TIPOS_CONTACTO.items():
        if termino in {_normalizar_termino_exclusion(item) for item in alias}:
            return tipo
    return None


def _resolver_tipos_excluidos(excluir: list[str]) -> list[str]:
    tipos: list[str] = []
    for termino in excluir:
        tipo = _resolver_tipo_contacto(termino)
        if tipo and tipo not in tipos:
            tipos.append(tipo)
    return tipos


def _obtener_sitios_en_alcance(
    db: Session,
    filtros_alcance: list[str],
    params_alcance: dict[str, Any],
) -> list[dict[str, Any]]:
    alcance_sql = ""
    if filtros_alcance:
        alcance_sql = " AND " + " AND ".join(filtros_alcance)

    rows = db.execute(
        text(
            f"""
            SELECT s.id_sitio, s.nombre
            FROM turismo.sitio s
            WHERE s.activo = TRUE
              {alcance_sql}
            ORDER BY s.nombre ASC
            """
        ),
        params_alcance,
    ).mappings().all()
    return [dict(row) for row in rows]


def _obtener_contactos_por_sitios(
    db: Session,
    ids_sitios: list[int],
) -> dict[int, list[ContactoItem]]:
    if not ids_sitios:
        return {}

    rows = db.execute(
        text(
            """
            SELECT id_sitio, tipo::text AS tipo, contenido
            FROM turismo.contacto
            WHERE activo = TRUE
              AND id_sitio = ANY(:ids_sitios)
            ORDER BY id_sitio ASC, tipo ASC
            """
        ),
        {"ids_sitios": ids_sitios},
    ).mappings().all()

    contactos_por_sitio: dict[int, list[ContactoItem]] = {}
    for row in rows:
        id_sitio = int(row["id_sitio"])
        contactos_por_sitio.setdefault(id_sitio, []).append(
            ContactoItem(tipo=row["tipo"], contenido=row["contenido"])
        )
    return contactos_por_sitio


def _sitio_tiene_tipo_excluido(
    contactos: list[ContactoItem],
    tipos_excluidos: list[str],
) -> bool:
    if not tipos_excluidos:
        return False
    tipos_sitio = {contacto.tipo for contacto in contactos}
    return any(tipo in tipos_sitio for tipo in tipos_excluidos)


def contactos(
    db: Session,
    payload: ContactosRequest,
) -> ContactosResponse:
    inicio = time.perf_counter()

    contacto_sugerido = _normalizar_texto(payload.contacto_sugerido)
    tipo_sugerido = _resolver_tipo_contacto(contacto_sugerido)
    if not tipo_sugerido:
        tiempo_ms = round((time.perf_counter() - inicio) * 1000, 2)
        return ContactosResponse(
            ok=False,
            contacto_sugerido=contacto_sugerido,
            tiempo_ms=tiempo_ms,
            mensaje=(
                f"No se pudo resolver el tipo de contacto '{contacto_sugerido}'. "
                "Valores validos: telefono, whatsapp, email, web, facebook, instagram, tiktok."
            ),
        )

    try:
        filtros_alcance, params_alcance, alcance_aplicado, meta_alcance = (
            _construir_alcance_sitios(
                db,
                payload.categoria,
                payload.subcategoria,
                payload.ids_sitios_candidatos,
            )
        )
    except ValueError as exc:
        tiempo_ms = round((time.perf_counter() - inicio) * 1000, 2)
        return ContactosResponse(
            ok=False,
            contacto_sugerido=contacto_sugerido,
            contacto_sugerido_resuelto=tipo_sugerido,
            tiempo_ms=tiempo_ms,
            mensaje=str(exc),
        )

    excluir_normalizados = [
        _normalizar_termino_exclusion(item)
        for item in payload.excluir_contactos
        if item and item.strip()
    ]
    tipos_excluidos = _resolver_tipos_excluidos(excluir_normalizados)

    sitios_alcance = _obtener_sitios_en_alcance(db, filtros_alcance, params_alcance)
    ids_alcance = [int(s["id_sitio"]) for s in sitios_alcance]
    contactos_map = _obtener_contactos_por_sitios(db, ids_alcance)

    sitios_con_contacto: list[SitioContactoItem] = []
    ids_coincidentes: list[int] = []

    for sitio in sitios_alcance:
        id_sitio = int(sitio["id_sitio"])
        contactos_sitio = contactos_map.get(id_sitio, [])
        if _sitio_tiene_tipo_excluido(contactos_sitio, tipos_excluidos):
            continue

        tiene_sugerido = any(c.tipo == tipo_sugerido for c in contactos_sitio)
        item = SitioContactoItem(
            id_sitio=id_sitio,
            nombre=sitio["nombre"],
            tiene_contacto_sugerido=tiene_sugerido,
            contactos=contactos_sitio,
        )
        if tiene_sugerido:
            ids_coincidentes.append(id_sitio)
            sitios_con_contacto.append(item)

    tiempo_ms = round((time.perf_counter() - inicio) * 1000, 2)
    respuesta_alcance = {
        "alcance_aplicado": alcance_aplicado,
        "categoria_resuelta": meta_alcance.get("categoria_resuelta"),
        "subcategoria_resuelta": meta_alcance.get("subcategoria_resuelta"),
        "ids_sitios_candidatos_aplicados": meta_alcance.get(
            "ids_sitios_candidatos_aplicados", []
        ),
        "excluir_contactos_aplicados": excluir_normalizados,
        "tipos_contacto_excluidos": tipos_excluidos,
    }

    if ids_coincidentes:
        return ContactosResponse(
            ok=True,
            contacto_sugerido=contacto_sugerido,
            contacto_sugerido_resuelto=tipo_sugerido,
            ids_sitios=ids_coincidentes,
            sitios=sitios_con_contacto,
            tiempo_ms=tiempo_ms,
            mensaje=(
                f"Se encontraron {len(ids_coincidentes)} sitio(s) con contacto "
                f"tipo '{tipo_sugerido}'."
            ),
            **respuesta_alcance,
        )

    sitios_con_todos_contactos = [
        SitioContactoItem(
            id_sitio=int(sitio["id_sitio"]),
            nombre=sitio["nombre"],
            tiene_contacto_sugerido=False,
            contactos=contactos_map.get(int(sitio["id_sitio"]), []),
        )
        for sitio in sitios_alcance
        if not _sitio_tiene_tipo_excluido(
            contactos_map.get(int(sitio["id_sitio"]), []),
            tipos_excluidos,
        )
    ]

    if not sitios_con_todos_contactos:
        return ContactosResponse(
            ok=False,
            contacto_sugerido=contacto_sugerido,
            contacto_sugerido_resuelto=tipo_sugerido,
            tiempo_ms=tiempo_ms,
            mensaje=(
                f"Ningun sitio en el alcance tiene contacto tipo '{tipo_sugerido}' "
                "ni contactos registrados."
            ),
            **respuesta_alcance,
        )

    return ContactosResponse(
        ok=False,
        contacto_sugerido=contacto_sugerido,
        contacto_sugerido_resuelto=tipo_sugerido,
        sitios=sitios_con_todos_contactos,
        tiempo_ms=tiempo_ms,
        mensaje=(
            f"Ningun sitio tiene contacto tipo '{tipo_sugerido}'. "
            "Se listan los contactos disponibles por sitio."
        ),
        **respuesta_alcance,
    )


DIAS_SEMANA_NOMBRE = {
    1: "lunes",
    2: "martes",
    3: "miercoles",
    4: "jueves",
    5: "viernes",
    6: "sabado",
    7: "domingo",
}


def _ahora_local() -> datetime:
    return datetime.now(TZ_RIOBAMBA)


def _resolver_dia_semana(valor: str | int | None) -> int | None:
    if valor is None:
        return None
    if isinstance(valor, int):
        return valor if 1 <= valor <= 7 else None
    texto = _normalizar_termino_exclusion(str(valor))
    if texto == "actual":
        return _ahora_local().isoweekday()
    if texto.isdigit():
        dia = int(texto)
        return dia if 1 <= dia <= 7 else None
    return None


def _parsear_hora_texto(hora_texto: str) -> dt_time | None:
    texto = hora_texto.strip()
    formatos = ("%H:%M", "%H:%M:%S", "%H")
    for formato in formatos:
        try:
            return datetime.strptime(texto, formato).time()
        except ValueError:
            continue
    return None


def _aplicar_meridiano(hora: dt_time, meridiano: str | None) -> dt_time:
    if meridiano is None:
        return hora
    meridiano_norm = meridiano.upper()
    hora_24 = hora.hour
    if meridiano_norm == "AM":
        if hora_24 == 12:
            hora_24 = 0
    elif meridiano_norm == "PM":
        if 1 <= hora_24 < 12:
            hora_24 += 12
    return dt_time(hora_24, hora.minute, hora.second)


def _resolver_hora(
    valor: str | None,
    meridiano: str | None = None,
) -> dt_time | None:
    if valor is None:
        return None
    if _normalizar_termino_exclusion(valor) == "actual":
        ahora = _ahora_local().time()
        return _aplicar_meridiano(ahora, meridiano)
    hora = _parsear_hora_texto(valor)
    if hora is None:
        return None
    return _aplicar_meridiano(hora, meridiano)


def _time_a_str(valor: dt_time) -> str:
    return valor.strftime("%H:%M")


def _resolver_dias_excluidos(excluir_dias: list[str | int]) -> list[int]:
    dias: list[int] = []
    for item in excluir_dias:
        dia = _resolver_dia_semana(item)
        if dia and dia not in dias:
            dias.append(dia)
    return dias


def _obtener_horarios_sitios(
    db: Session,
    filtros_alcance: list[str],
    params_alcance: dict[str, Any],
) -> dict[int, dict[str, Any]]:
    alcance_sql = ""
    if filtros_alcance:
        alcance_sql = " AND " + " AND ".join(filtros_alcance)

    rows = db.execute(
        text(
            f"""
            SELECT
                s.id_sitio,
                s.nombre,
                COALESCE(h.abierto_24h, FALSE) AS abierto_24h,
                hd.dia_semana,
                hd.hora_inicio,
                hd.hora_fin
            FROM turismo.sitio s
            LEFT JOIN turismo.horario h
                ON h.id_sitio = s.id_sitio AND h.activo = TRUE
            LEFT JOIN turismo.horario_detalle hd
                ON hd.id_horario = h.id_horario AND hd.activo = TRUE
            WHERE s.activo = TRUE
              {alcance_sql}
            ORDER BY s.nombre ASC, hd.dia_semana ASC, hd.hora_inicio ASC
            """
        ),
        params_alcance,
    ).mappings().all()

    sitios: dict[int, dict[str, Any]] = {}
    for row in rows:
        id_sitio = int(row["id_sitio"])
        if id_sitio not in sitios:
            sitios[id_sitio] = {
                "id_sitio": id_sitio,
                "nombre": row["nombre"],
                "abierto_24h": bool(row["abierto_24h"]),
                "detalles": [],
            }
        if row["dia_semana"] is not None:
            sitios[id_sitio]["detalles"].append(
                {
                    "dia_semana": int(row["dia_semana"]),
                    "hora_inicio": row["hora_inicio"],
                    "hora_fin": row["hora_fin"],
                }
            )
    return sitios


def _sitio_atiende_dia(sitio: dict[str, Any], dia: int) -> bool:
    if sitio["abierto_24h"]:
        return True
    return any(detalle["dia_semana"] == dia for detalle in sitio["detalles"])


def _detalles_dia(sitio: dict[str, Any], dia: int) -> list[dict[str, Any]]:
    return [detalle for detalle in sitio["detalles"] if detalle["dia_semana"] == dia]


def _hora_en_rango(hora: dt_time, inicio: dt_time, fin: dt_time) -> bool:
    return inicio <= hora <= fin


def _rangos_se_solapan(inicio_a: dt_time, fin_a: dt_time, inicio_b: dt_time, fin_b: dt_time) -> bool:
    return inicio_a < fin_b and fin_a > inicio_b


def _sitio_cumple_filtro_horario(
    sitio: dict[str, Any],
    tipo: str,
    dia_semana: int | None,
    hora: dt_time | None,
    rango_inicio: dt_time | None,
    rango_fin: dt_time | None,
    comparador: str | None,
) -> bool:
    if tipo == "ninguno":
        return True

    if tipo == "abierto_24h":
        return sitio["abierto_24h"]

    if tipo == "abierto_ahora":
        if sitio["abierto_24h"]:
            return True
        dia = dia_semana or _ahora_local().isoweekday()
        hora_actual = hora or _ahora_local().time()
        for detalle in _detalles_dia(sitio, dia):
            if _hora_en_rango(hora_actual, detalle["hora_inicio"], detalle["hora_fin"]):
                return True
        return False

    if tipo == "atiende_dia":
        if dia_semana is None:
            return False
        return _sitio_atiende_dia(sitio, dia_semana)

    if tipo == "abierto_en_hora":
        if dia_semana is None or hora is None:
            return False
        if sitio["abierto_24h"]:
            return True
        for detalle in _detalles_dia(sitio, dia_semana):
            inicio = detalle["hora_inicio"]
            fin = detalle["hora_fin"]
            if comparador == "antes_de":
                if inicio <= hora:
                    return True
            elif comparador == "despues_de":
                if fin >= hora:
                    return True
            else:
                if _hora_en_rango(hora, inicio, fin):
                    return True
        return False

    if tipo == "abierto_en_rango":
        if dia_semana is None or rango_inicio is None or rango_fin is None:
            return False
        if sitio["abierto_24h"]:
            return True
        for detalle in _detalles_dia(sitio, dia_semana):
            if _rangos_se_solapan(
                detalle["hora_inicio"],
                detalle["hora_fin"],
                rango_inicio,
                rango_fin,
            ):
                return True
        return False

    return False


def _sitio_excluido_por_dias(sitio: dict[str, Any], dias_excluidos: list[int]) -> bool:
    if not dias_excluidos:
        return False
    return any(_sitio_atiende_dia(sitio, dia) for dia in dias_excluidos)


def _construir_filtros_aplicados_horario(
    tipo: str,
    dia_semana: int | None,
    hora: dt_time | None,
    rango_inicio: dt_time | None,
    rango_fin: dt_time | None,
    comparador: str | None,
    meridiano: str | None,
) -> dict[str, Any]:
    filtros: dict[str, Any] = {"tipo": tipo}
    if dia_semana is not None:
        filtros["dia_semana"] = dia_semana
        filtros["dia_semana_nombre"] = DIAS_SEMANA_NOMBRE.get(dia_semana)
    if hora is not None:
        filtros["hora"] = _time_a_str(hora)
    if rango_inicio is not None and rango_fin is not None:
        filtros["rango_hora"] = {
            "inicio": _time_a_str(rango_inicio),
            "fin": _time_a_str(rango_fin),
        }
    if comparador and tipo == "abierto_en_hora":
        filtros["comparador"] = comparador
    if meridiano:
        filtros["meridiano"] = meridiano
    if tipo == "abierto_24h":
        filtros["abierto_24h"] = True
    if tipo == "abierto_ahora":
        filtros["abierto_ahora"] = True
    return filtros


def horario(
    db: Session,
    payload: HorarioRequest,
) -> HorarioResponse:
    inicio = time.perf_counter()
    tipo = payload.tipo

    if tipo == "ninguno":
        tiempo_ms = round((time.perf_counter() - inicio) * 1000, 2)
        return HorarioResponse(
            ok=False,
            total=0,
            tipo_aplicado=tipo,
            tiempo_ms=tiempo_ms,
            mensaje="Debe indicar un tipo de filtro de horario distinto de 'ninguno'.",
        )

    try:
        filtros_alcance, params_alcance, alcance_aplicado, meta_alcance = (
            _construir_alcance_sitios(
                db,
                payload.categoria,
                payload.subcategoria,
                payload.ids_sitios_candidatos,
            )
        )
    except ValueError as exc:
        tiempo_ms = round((time.perf_counter() - inicio) * 1000, 2)
        return HorarioResponse(
            ok=False,
            total=0,
            tipo_aplicado=tipo,
            tiempo_ms=tiempo_ms,
            mensaje=str(exc),
        )

    dia_semana = _resolver_dia_semana(payload.dia_semana)
    if tipo in {"abierto_ahora", "abierto_en_hora", "abierto_en_rango"} and dia_semana is None:
        dia_semana = _ahora_local().isoweekday()

    hora = _resolver_hora(payload.hora, payload.meridiano)
    rango_inicio = _resolver_hora(payload.rango_hora.inicio, payload.meridiano)
    rango_fin = _resolver_hora(payload.rango_hora.fin, payload.meridiano)
    dias_excluidos = _resolver_dias_excluidos(payload.excluir_dias)

    if tipo == "atiende_dia" and dia_semana is None:
        tiempo_ms = round((time.perf_counter() - inicio) * 1000, 2)
        return HorarioResponse(
            ok=False,
            total=0,
            tipo_aplicado=tipo,
            tiempo_ms=tiempo_ms,
            mensaje="El filtro 'atiende_dia' requiere un dia_semana valido (1-7 o actual).",
        )

    if tipo == "abierto_en_hora" and hora is None:
        tiempo_ms = round((time.perf_counter() - inicio) * 1000, 2)
        return HorarioResponse(
            ok=False,
            total=0,
            tipo_aplicado=tipo,
            tiempo_ms=tiempo_ms,
            mensaje="El filtro 'abierto_en_hora' requiere una hora valida (HH:MM o actual).",
        )

    if tipo == "abierto_en_rango" and (rango_inicio is None or rango_fin is None):
        tiempo_ms = round((time.perf_counter() - inicio) * 1000, 2)
        return HorarioResponse(
            ok=False,
            total=0,
            tipo_aplicado=tipo,
            tiempo_ms=tiempo_ms,
            mensaje="El filtro 'abierto_en_rango' requiere rango_hora.inicio y rango_hora.fin.",
        )

    sitios_map = _obtener_horarios_sitios(db, filtros_alcance, params_alcance)
    comparador = payload.comparador or "exacto"
    filtros_aplicados = _construir_filtros_aplicados_horario(
        tipo,
        dia_semana,
        hora,
        rango_inicio,
        rango_fin,
        comparador,
        payload.meridiano,
    )

    sitios_coincidentes: list[SitioHorarioItem] = []
    for sitio in sitios_map.values():
        if _sitio_excluido_por_dias(sitio, dias_excluidos):
            continue
        if not _sitio_cumple_filtro_horario(
            sitio,
            tipo,
            dia_semana,
            hora,
            rango_inicio,
            rango_fin,
            comparador,
        ):
            continue

        detalles = [
            HorarioDetalleItem(
                dia_semana=detalle["dia_semana"],
                hora_inicio=_time_a_str(detalle["hora_inicio"]),
                hora_fin=_time_a_str(detalle["hora_fin"]),
            )
            for detalle in sitio["detalles"]
        ]
        sitios_coincidentes.append(
            SitioHorarioItem(
                id_sitio=sitio["id_sitio"],
                nombre=sitio["nombre"],
                abierto_24h=sitio["abierto_24h"],
                detalles=detalles,
            )
        )

    tiempo_ms = round((time.perf_counter() - inicio) * 1000, 2)
    total = len(sitios_coincidentes)
    respuesta_alcance = {
        "alcance_aplicado": alcance_aplicado,
        "categoria_resuelta": meta_alcance.get("categoria_resuelta"),
        "subcategoria_resuelta": meta_alcance.get("subcategoria_resuelta"),
        "ids_sitios_candidatos_aplicados": meta_alcance.get(
            "ids_sitios_candidatos_aplicados", []
        ),
        "excluir_dias_aplicados": dias_excluidos,
        "dia_semana_resuelto": dia_semana,
        "hora_resuelta": _time_a_str(hora) if hora else None,
        "rango_hora_aplicado": {
            "inicio": _time_a_str(rango_inicio) if rango_inicio else None,
            "fin": _time_a_str(rango_fin) if rango_fin else None,
        },
        "filtros_aplicados": filtros_aplicados,
    }

    if total == 0:
        return HorarioResponse(
            ok=False,
            total=0,
            tipo_aplicado=tipo,
            tiempo_ms=tiempo_ms,
            mensaje="No se encontraron sitios que cumplan el filtro de horario.",
            **respuesta_alcance,
        )

    return HorarioResponse(
        ok=True,
        total=total,
        ids_sitios=[sitio.id_sitio for sitio in sitios_coincidentes],
        sitios=sitios_coincidentes,
        tipo_aplicado=tipo,
        tiempo_ms=tiempo_ms,
        mensaje=f"Se encontraron {total} sitio(s) que cumplen el filtro de horario.",
        **respuesta_alcance,
    )


ETIQUETAS_PRECIO: dict[str, tuple[str, ...]] = {
    "economico": ("economico", "económico", "barato", "barata", "bajo", "accesible"),
    "medio": ("medio", "mediana", "mediano", "moderado", "moderada", "intermedio"),
    "alto": ("alto", "alta", "caro", "cara", "premium", "lujo"),
}


def _resolver_etiqueta_precio(texto: str) -> str | None:
    termino = _normalizar_termino_exclusion(texto)
    for etiqueta, alias in ETIQUETAS_PRECIO.items():
        if termino in {_normalizar_termino_exclusion(item) for item in alias}:
            return etiqueta
    return None


def _resolver_etiquetas_excluidas(excluir: list[str]) -> list[str]:
    etiquetas: list[str] = []
    for termino in excluir:
        etiqueta = _resolver_etiqueta_precio(termino)
        if etiqueta and etiqueta not in etiquetas:
            etiquetas.append(etiqueta)
    return etiquetas


def _clasificar_etiqueta_por_monto(precio: float) -> str:
    if precio <= 1:
        return "economico"
    if precio <= 5:
        return "medio"
    return "alto"


def _monto_cumple_etiqueta(precio: float, etiqueta: str) -> bool:
    return _clasificar_etiqueta_por_monto(precio) == etiqueta


def _monto_cumple_filtro(
    precio: float,
    etiqueta: str | None,
    precio_numero: float | None,
    operador: str | None,
    usar_etiqueta_calculada: bool = False,
    etiqueta_db: str | None = None,
) -> bool:
    if usar_etiqueta_calculada and etiqueta:
        if not _monto_cumple_etiqueta(precio, etiqueta):
            return False
    elif etiqueta and etiqueta_db and etiqueta_db != etiqueta:
        return False
    elif etiqueta and usar_etiqueta_calculada is False and etiqueta_db is None:
        return False

    if precio_numero is None:
        return etiqueta is not None

    operador_efectivo = operador or "exacto"
    if operador_efectivo == "exacto":
        return abs(precio - precio_numero) < 0.01 or precio == precio_numero
    if operador_efectivo == "min":
        return precio <= precio_numero
    if operador_efectivo == "max":
        return precio >= precio_numero
    return False


def _rango_cumple_filtro_precio(
    precio_min: float,
    precio_max: float,
    etiqueta: str | None,
    precio_numero: float | None,
    operador: str | None,
    etiqueta_db: str | None,
) -> bool:
    if etiqueta and etiqueta_db and etiqueta_db != etiqueta:
        return False

    if precio_numero is None:
        return etiqueta is not None and (
            etiqueta_db is None or etiqueta_db == etiqueta
        )

    operador_efectivo = operador or "exacto"
    if operador_efectivo == "exacto":
        return precio_min <= precio_numero <= precio_max
    if operador_efectivo == "min":
        return precio_max <= precio_numero
    if operador_efectivo == "max":
        return precio_min >= precio_numero
    return False


def _condicion_coincide(db: Session, condicion: str, texto_busqueda: str) -> bool:
    if not condicion or not texto_busqueda:
        return False
    condicion_ascii = _sin_acentos(_normalizar_texto(condicion))
    busqueda_ascii = _sin_acentos(_normalizar_texto(texto_busqueda))
    if busqueda_ascii in condicion_ascii:
        return True
    score = db.execute(
        text(
            """
            SELECT GREATEST(
                similarity(:condicion, :busqueda),
                word_similarity(:condicion, :busqueda)
            ) AS score
            """
        ),
        {"condicion": condicion_ascii, "busqueda": busqueda_ascii},
    ).scalar()
    return score is not None and float(score) >= UMBRAL_CATALOGO


def _sitio_excluido_por_condiciones(
    db: Session,
    tarifas: list[dict[str, Any]],
    condiciones_excluidas: list[str],
) -> bool:
    if not condiciones_excluidas or not tarifas:
        return False
    for tarifa in tarifas:
        condicion = tarifa.get("condicion") or ""
        for termino in condiciones_excluidas:
            if _condicion_coincide(db, condicion, termino):
                return True
    return False


def _obtener_sitios_precio_unificado(
    db: Session,
    filtros_alcance: list[str],
    params_alcance: dict[str, Any],
) -> dict[int, dict[str, Any]]:
    alcance_sql = ""
    if filtros_alcance:
        alcance_sql = " AND " + " AND ".join(filtros_alcance)

    sitios_rows = db.execute(
        text(
            f"""
            SELECT s.id_sitio, s.nombre
            FROM turismo.sitio s
            WHERE s.activo = TRUE
              {alcance_sql}
            ORDER BY s.nombre ASC
            """
        ),
        params_alcance,
    ).mappings().all()

    if not sitios_rows:
        return {}

    ids_sitios = [int(row["id_sitio"]) for row in sitios_rows]
    tarifas_rows = db.execute(
        text(
            """
            SELECT id_sitio, precio, condicion
            FROM turismo.tarifa_acceso
            WHERE activo = TRUE
              AND id_sitio = ANY(:ids_sitios)
            ORDER BY id_sitio ASC, precio ASC
            """
        ),
        {"ids_sitios": ids_sitios},
    ).mappings().all()

    rangos_rows = db.execute(
        text(
            """
            SELECT id_sitio, precio_min, precio_max, etiqueta_precio::text AS etiqueta_precio
            FROM turismo.rango_precio
            WHERE activo = TRUE
              AND id_sitio = ANY(:ids_sitios)
            ORDER BY id_sitio ASC, precio_min ASC
            """
        ),
        {"ids_sitios": ids_sitios},
    ).mappings().all()

    sitios: dict[int, dict[str, Any]] = {}
    for row in sitios_rows:
        id_sitio = int(row["id_sitio"])
        sitios[id_sitio] = {
            "id_sitio": id_sitio,
            "nombre": row["nombre"],
            "tarifas": [],
            "rangos": [],
        }

    for row in tarifas_rows:
        id_sitio = int(row["id_sitio"])
        sitios[id_sitio]["tarifas"].append(
            {
                "precio": float(row["precio"]),
                "condicion": row["condicion"],
            }
        )

    for row in rangos_rows:
        id_sitio = int(row["id_sitio"])
        sitios[id_sitio]["rangos"].append(
            {
                "precio_min": float(row["precio_min"]),
                "precio_max": float(row["precio_max"]),
                "etiqueta_precio": row["etiqueta_precio"],
            }
        )

    return sitios


def _seleccionar_mejor_tarifa(
    tarifas: list[dict[str, Any]],
    operador: str | None,
) -> dict[str, Any]:
    if operador == "max":
        return max(tarifas, key=lambda item: item["precio"])
    return min(tarifas, key=lambda item: item["precio"])


def _seleccionar_mejor_rango(
    rangos: list[dict[str, Any]],
    operador: str | None,
) -> dict[str, Any]:
    if operador == "max":
        return max(rangos, key=lambda item: item["precio_max"])
    return min(rangos, key=lambda item: item["precio_min"])


def _filtrar_sitio_precio_general(
    sitio: dict[str, Any],
    etiqueta: str | None,
    precio_numero: float | None,
    operador: str | None,
    etiquetas_excluidas: list[str],
) -> SitioPrecioItem | None:
    if sitio["tarifas"]:
        tarifas_validas = [
            tarifa
            for tarifa in sitio["tarifas"]
            if _monto_cumple_filtro(
                tarifa["precio"],
                etiqueta,
                precio_numero,
                operador,
                usar_etiqueta_calculada=True,
            )
        ]
        if not tarifas_validas:
            return None
        mejor = _seleccionar_mejor_tarifa(tarifas_validas, operador)
        etiqueta_resultado = _clasificar_etiqueta_por_monto(mejor["precio"])
        if etiqueta_resultado in etiquetas_excluidas:
            return None
        return SitioPrecioItem(
            id_sitio=sitio["id_sitio"],
            nombre=sitio["nombre"],
            fuente_precio="tarifa_acceso",
            precio_min=mejor["precio"],
            precio_max=mejor["precio"],
            etiqueta_precio=etiqueta_resultado,
        )

    if sitio["rangos"]:
        rangos_validos = [
            rango
            for rango in sitio["rangos"]
            if _rango_cumple_filtro_precio(
                rango["precio_min"],
                rango["precio_max"],
                etiqueta,
                precio_numero,
                operador,
                rango["etiqueta_precio"],
            )
        ]
        if not rangos_validos:
            return None
        mejor = _seleccionar_mejor_rango(rangos_validos, operador)
        if mejor["etiqueta_precio"] in etiquetas_excluidas:
            return None
        return SitioPrecioItem(
            id_sitio=sitio["id_sitio"],
            nombre=sitio["nombre"],
            fuente_precio="rango_precio",
            precio_min=mejor["precio_min"],
            precio_max=mejor["precio_max"],
            etiqueta_precio=mejor["etiqueta_precio"],
        )

    return None


def _filtrar_sitio_tarifa_acceso(
    db: Session,
    sitio: dict[str, Any],
    etiqueta: str | None,
    precio_numero: float | None,
    operador: str | None,
    condicion: str | None,
    condiciones_excluidas: list[str],
) -> SitioTarifaAccesoItem | None:
    if sitio["tarifas"]:
        if _sitio_excluido_por_condiciones(db, sitio["tarifas"], condiciones_excluidas):
            return None

        tarifas_validas = sitio["tarifas"]
        if condicion and condicion.strip():
            tarifas_validas = [
                tarifa
                for tarifa in tarifas_validas
                if _condicion_coincide(db, tarifa.get("condicion") or "", condicion)
            ]
            if not tarifas_validas:
                return None

        tarifas_validas = [
            tarifa
            for tarifa in tarifas_validas
            if _monto_cumple_filtro(
                tarifa["precio"],
                etiqueta,
                precio_numero,
                operador,
                usar_etiqueta_calculada=True,
            )
        ]
        if not tarifas_validas:
            return None

        mejor = _seleccionar_mejor_tarifa(tarifas_validas, operador)
        return SitioTarifaAccesoItem(
            id_sitio=sitio["id_sitio"],
            nombre=sitio["nombre"],
            fuente_precio="tarifa_acceso",
            precio=mejor["precio"],
            condicion=mejor.get("condicion"),
            etiqueta_precio=_clasificar_etiqueta_por_monto(mejor["precio"]),
        )

    if sitio["rangos"]:
        rangos_validos = []
        for rango in sitio["rangos"]:
            precio_referencia = rango["precio_min"]
            if not _monto_cumple_filtro(
                precio_referencia,
                etiqueta,
                precio_numero,
                operador,
                usar_etiqueta_calculada=True,
            ):
                continue
            rangos_validos.append(rango)

        if not rangos_validos:
            return None

        mejor = _seleccionar_mejor_rango(rangos_validos, operador)
        precio_referencia = mejor["precio_min"]
        return SitioTarifaAccesoItem(
            id_sitio=sitio["id_sitio"],
            nombre=sitio["nombre"],
            fuente_precio="rango_precio",
            precio=precio_referencia,
            precio_min=mejor["precio_min"],
            precio_max=mejor["precio_max"],
            etiqueta_precio=_clasificar_etiqueta_por_monto(precio_referencia),
        )

    return None


def _construir_filtros_aplicados_precio(
    etiqueta: str | None,
    operador: str | None,
    precio_numero: float | None,
    condicion: str | None = None,
) -> dict[str, Any]:
    filtros: dict[str, Any] = {}
    if etiqueta:
        filtros["etiqueta"] = etiqueta
    if operador:
        filtros["operador"] = operador
    if precio_numero is not None:
        filtros["precio_numero"] = precio_numero
    if condicion:
        filtros["condicion"] = condicion
    return filtros


def precio(
    db: Session,
    payload: PrecioRequest,
) -> PrecioResponse:
    inicio = time.perf_counter()

    etiqueta_resuelta = (
        _resolver_etiqueta_precio(payload.etiqueta)
        if payload.etiqueta and payload.etiqueta.strip()
        else None
    )
    if payload.etiqueta and payload.etiqueta.strip() and etiqueta_resuelta is None:
        tiempo_ms = round((time.perf_counter() - inicio) * 1000, 2)
        return PrecioResponse(
            ok=False,
            total=0,
            tiempo_ms=tiempo_ms,
            mensaje=(
                f"No se pudo resolver la etiqueta de precio '{payload.etiqueta}'. "
                "Valores validos: economico, medio, alto."
            ),
        )

    if etiqueta_resuelta is None and payload.precio_numero is None:
        tiempo_ms = round((time.perf_counter() - inicio) * 1000, 2)
        return PrecioResponse(
            ok=False,
            total=0,
            tiempo_ms=tiempo_ms,
            mensaje="Debe indicar una etiqueta de precio o un precio_numero.",
        )

    try:
        filtros_alcance, params_alcance, alcance_aplicado, meta_alcance = (
            _construir_alcance_sitios(
                db,
                payload.categoria,
                payload.subcategoria,
                payload.ids_sitios_candidatos,
            )
        )
    except ValueError as exc:
        tiempo_ms = round((time.perf_counter() - inicio) * 1000, 2)
        return PrecioResponse(
            ok=False,
            total=0,
            tiempo_ms=tiempo_ms,
            mensaje=str(exc),
        )

    etiquetas_excluidas = _resolver_etiquetas_excluidas(payload.excluir_etiquetas)
    sitios_map = _obtener_sitios_precio_unificado(db, filtros_alcance, params_alcance)

    sitios_coincidentes: list[SitioPrecioItem] = []
    for sitio in sitios_map.values():
        item = _filtrar_sitio_precio_general(
            sitio,
            etiqueta_resuelta,
            payload.precio_numero,
            payload.operador,
            etiquetas_excluidas,
        )
        if item:
            sitios_coincidentes.append(item)

    filtros_aplicados = _construir_filtros_aplicados_precio(
        etiqueta_resuelta,
        payload.operador,
        payload.precio_numero,
    )
    tiempo_ms = round((time.perf_counter() - inicio) * 1000, 2)
    total = len(sitios_coincidentes)
    respuesta_alcance = {
        "alcance_aplicado": alcance_aplicado,
        "categoria_resuelta": meta_alcance.get("categoria_resuelta"),
        "subcategoria_resuelta": meta_alcance.get("subcategoria_resuelta"),
        "ids_sitios_candidatos_aplicados": meta_alcance.get(
            "ids_sitios_candidatos_aplicados", []
        ),
        "excluir_etiquetas_aplicadas": etiquetas_excluidas,
        "etiqueta_resuelta": etiqueta_resuelta,
        "operador_aplicado": payload.operador,
        "precio_numero_aplicado": payload.precio_numero,
        "filtros_aplicados": filtros_aplicados,
    }

    if total == 0:
        return PrecioResponse(
            ok=False,
            total=0,
            tiempo_ms=tiempo_ms,
            mensaje="No se encontraron sitios que cumplan el filtro de precio.",
            **respuesta_alcance,
        )

    return PrecioResponse(
        ok=True,
        total=total,
        ids_sitios=[sitio.id_sitio for sitio in sitios_coincidentes],
        sitios=sitios_coincidentes,
        tiempo_ms=tiempo_ms,
        mensaje=f"Se encontraron {total} sitio(s) que cumplen el filtro de precio.",
        **respuesta_alcance,
    )


def tarifa_acceso(
    db: Session,
    payload: TarifaAccesoRequest,
) -> TarifaAccesoResponse:
    inicio = time.perf_counter()

    etiqueta_resuelta = (
        _resolver_etiqueta_precio(payload.etiqueta)
        if payload.etiqueta and payload.etiqueta.strip()
        else None
    )
    if payload.etiqueta and payload.etiqueta.strip() and etiqueta_resuelta is None:
        tiempo_ms = round((time.perf_counter() - inicio) * 1000, 2)
        return TarifaAccesoResponse(
            ok=False,
            total=0,
            tiempo_ms=tiempo_ms,
            mensaje=(
                f"No se pudo resolver la etiqueta '{payload.etiqueta}'. "
                "Valores validos: economico, medio, alto."
            ),
        )

    if etiqueta_resuelta is None and payload.precio_numero is None:
        tiempo_ms = round((time.perf_counter() - inicio) * 1000, 2)
        return TarifaAccesoResponse(
            ok=False,
            total=0,
            tiempo_ms=tiempo_ms,
            mensaje="Debe indicar una etiqueta o un precio_numero.",
        )

    try:
        filtros_alcance, params_alcance, alcance_aplicado, meta_alcance = (
            _construir_alcance_sitios(
                db,
                payload.categoria,
                payload.subcategoria,
                payload.ids_sitios_candidatos,
            )
        )
    except ValueError as exc:
        tiempo_ms = round((time.perf_counter() - inicio) * 1000, 2)
        return TarifaAccesoResponse(
            ok=False,
            total=0,
            tiempo_ms=tiempo_ms,
            mensaje=str(exc),
        )

    condicion = payload.condicion.strip() if payload.condicion else None
    condiciones_excluidas = [
        item.strip()
        for item in payload.excluir_condiciones
        if item and item.strip()
    ]
    sitios_map = _obtener_sitios_precio_unificado(db, filtros_alcance, params_alcance)

    sitios_coincidentes: list[SitioTarifaAccesoItem] = []
    for sitio in sitios_map.values():
        item = _filtrar_sitio_tarifa_acceso(
            db,
            sitio,
            etiqueta_resuelta,
            payload.precio_numero,
            payload.operador,
            condicion,
            condiciones_excluidas,
        )
        if item:
            sitios_coincidentes.append(item)

    filtros_aplicados = _construir_filtros_aplicados_precio(
        etiqueta_resuelta,
        payload.operador,
        payload.precio_numero,
        condicion,
    )
    tiempo_ms = round((time.perf_counter() - inicio) * 1000, 2)
    total = len(sitios_coincidentes)
    respuesta_alcance = {
        "alcance_aplicado": alcance_aplicado,
        "categoria_resuelta": meta_alcance.get("categoria_resuelta"),
        "subcategoria_resuelta": meta_alcance.get("subcategoria_resuelta"),
        "ids_sitios_candidatos_aplicados": meta_alcance.get(
            "ids_sitios_candidatos_aplicados", []
        ),
        "excluir_condiciones_aplicadas": condiciones_excluidas,
        "etiqueta_resuelta": etiqueta_resuelta,
        "operador_aplicado": payload.operador,
        "precio_numero_aplicado": payload.precio_numero,
        "condicion_resuelta": condicion,
        "filtros_aplicados": filtros_aplicados,
    }

    if total == 0:
        return TarifaAccesoResponse(
            ok=False,
            total=0,
            tiempo_ms=tiempo_ms,
            mensaje="No se encontraron sitios que cumplan el filtro de tarifa de acceso.",
            **respuesta_alcance,
        )

    return TarifaAccesoResponse(
        ok=True,
        total=total,
        ids_sitios=[sitio.id_sitio for sitio in sitios_coincidentes],
        sitios=sitios_coincidentes,
        tiempo_ms=tiempo_ms,
        mensaje=f"Se encontraron {total} sitio(s) que cumplen el filtro de tarifa de acceso.",
        **respuesta_alcance,
    )


TIPOS_RUTA_ALIAS: dict[str, tuple[str, ...]] = {
    "senderismo": ("senderismo", "sendero", "trekking", "hiking", "caminata"),
    "ciclismo": ("ciclismo", "bicicleta", "bike", "cycling", "bici"),
    "caminata_urbana": (
        "caminata_urbana",
        "caminata urbana",
        "caminata-urbana",
        "urbano",
        "urbana",
    ),
    "montanismo": ("montanismo", "montana", "montaña", "alpinismo", "escalada"),
    "otro": ("otro", "otros", "otras", "otra"),
}

TIPOS_RUTA_BD: dict[str, str] = {
    "senderismo": "Senderismo",
    "ciclismo": "Ciclismo",
    "caminata_urbana": "Caminata Urbana",
    "montanismo": "Montañismo",
    "otro": "Otras",
}


def _resolver_tipo_ruta(texto: str) -> str | None:
    termino = _normalizar_termino_exclusion(texto)
    for clave, alias in TIPOS_RUTA_ALIAS.items():
        if termino in {_normalizar_termino_exclusion(item) for item in alias}:
            return clave
    return None


def _resolver_tipos_ruta_excluidos(excluir: list[str]) -> list[str]:
    tipos_bd: list[str] = []
    for termino in excluir:
        clave = _resolver_tipo_ruta(termino)
        if clave:
            tipo_bd = TIPOS_RUTA_BD[clave]
            if tipo_bd not in tipos_bd:
                tipos_bd.append(tipo_bd)
    return tipos_bd


def ruta(
    db: Session,
    payload: RutaRequest,
) -> RutaResponse:
    inicio = time.perf_counter()
    tipo_consultado = _normalizar_texto(payload.tipo_ruta)
    tipo_clave = _resolver_tipo_ruta(tipo_consultado)
    if not tipo_clave:
        tiempo_ms = round((time.perf_counter() - inicio) * 1000, 2)
        return RutaResponse(
            ok=False,
            total=0,
            tipo_ruta_consultado=tipo_consultado,
            tiempo_ms=tiempo_ms,
            mensaje=(
                f"No se pudo resolver el tipo de ruta '{tipo_consultado}'. "
                "Valores validos: senderismo, ciclismo, caminata_urbana, montanismo, otro."
            ),
        )

    tipo_bd = TIPOS_RUTA_BD[tipo_clave]
    tipos_excluidos = _resolver_tipos_ruta_excluidos(payload.excluir_tipos)
    if tipo_bd in tipos_excluidos:
        tiempo_ms = round((time.perf_counter() - inicio) * 1000, 2)
        return RutaResponse(
            ok=False,
            total=0,
            tipo_ruta_consultado=tipo_consultado,
            tipo_ruta_resuelto=tipo_bd,
            excluir_tipos_aplicados=payload.excluir_tipos,
            tipos_ruta_excluidos=tipos_excluidos,
            tiempo_ms=tiempo_ms,
            mensaje=f"El tipo de ruta '{tipo_bd}' fue excluido por el filtro.",
        )

    ids_candidatos = sorted({int(item) for item in payload.ids_rutas_candidatos if item > 0})
    filtros_sql = ["activo = TRUE", "tipo_ruta::text = :tipo_ruta"]
    params: dict[str, Any] = {"tipo_ruta": tipo_bd}

    if ids_candidatos:
        filtros_sql.append("id_ruta = ANY(:ids_rutas)")
        params["ids_rutas"] = ids_candidatos

    if tipos_excluidos:
        filtros_sql.append("tipo_ruta::text <> ALL(:tipos_excluidos)")
        params["tipos_excluidos"] = tipos_excluidos

    rows = db.execute(
        text(
            f"""
            SELECT id_ruta, titulo, tipo_ruta::text AS tipo_ruta
            FROM gis.rutas_turistica
            WHERE {' AND '.join(filtros_sql)}
            ORDER BY titulo ASC
            """
        ),
        params,
    ).mappings().all()

    rutas = [
        RutaItem(
            id_ruta=int(row["id_ruta"]),
            titulo=row["titulo"],
            tipo_ruta=row["tipo_ruta"],
        )
        for row in rows
    ]

    filtros_aplicados = {"tipo_ruta": tipo_clave, "tipo_ruta_bd": tipo_bd}
    tiempo_ms = round((time.perf_counter() - inicio) * 1000, 2)
    total = len(rutas)

    if total == 0:
        return RutaResponse(
            ok=False,
            total=0,
            tipo_ruta_consultado=tipo_consultado,
            tipo_ruta_resuelto=tipo_bd,
            filtros_aplicados=filtros_aplicados,
            excluir_tipos_aplicados=payload.excluir_tipos,
            tipos_ruta_excluidos=tipos_excluidos,
            ids_rutas_candidatos_aplicados=ids_candidatos,
            tiempo_ms=tiempo_ms,
            mensaje=f"No se encontraron rutas de tipo '{tipo_bd}'.",
        )

    return RutaResponse(
        ok=True,
        total=total,
        ids_rutas=[item.id_ruta for item in rutas],
        rutas=rutas,
        tipo_ruta_consultado=tipo_consultado,
        tipo_ruta_resuelto=tipo_bd,
        filtros_aplicados=filtros_aplicados,
        excluir_tipos_aplicados=payload.excluir_tipos,
        tipos_ruta_excluidos=tipos_excluidos,
        ids_rutas_candidatos_aplicados=ids_candidatos,
        tiempo_ms=tiempo_ms,
        mensaje=f"Se encontraron {total} ruta(s) de tipo '{tipo_bd}'.",
    )


def _obtener_coordenadas_nominatim(
    punto_referencia: str,
) -> tuple[float, float, str] | tuple[None, None, None]:
    try:
        url = "https://nominatim.openstreetmap.org/search"
        params = {
            "q": f"{punto_referencia}, Riobamba, Ecuador",
            "format": "json",
            "limit": 1,
        }
        headers = {"User-Agent": "RiobambaGo-Chatbot/1.0"}
        response = requests.get(url, params=params, headers=headers, timeout=5)
        if response.status_code == 200:
            data = response.json()
            if data and len(data) > 0:
                lat = float(data[0]["lat"])
                lon = float(data[0]["lon"])
                nombre = data[0].get("display_name", punto_referencia)
                return lat, lon, nombre
    except Exception:
        pass
    return None, None, None


def _resolver_punto_origen(
    db: Session,
    usar_ubicacion_usuario: bool,
    ubicacion_usuario: dict[str, float] | None,
    punto_referencia: str | None,
) -> tuple[float | None, float | None, str, str | None]:
    if usar_ubicacion_usuario and ubicacion_usuario:
        lat = ubicacion_usuario.get("lat")
        lon = ubicacion_usuario.get("lon") or ubicacion_usuario.get("lng")
        if lat is not None and lon is not None:
            return float(lat), float(lon), "usuario", "Ubicación del usuario"

    if not punto_referencia or not punto_referencia.strip():
        return None, None, "ninguno", None

    texto_referencia = _normalizar_texto(punto_referencia)
    texto_ascii = _sin_acentos(texto_referencia)
    
    row = db.execute(
        text(
            f"""
            SELECT
                ST_Y(ubicacion::geometry) AS lat,
                ST_X(ubicacion::geometry) AS lon,
                nombre,
                {_sql_score_trgm("nombre")} AS score
            FROM turismo.sitio
            WHERE activo = TRUE
              AND ubicacion IS NOT NULL
              AND {_sql_score_trgm("nombre")} > :umbral_candidato
            ORDER BY score DESC
            LIMIT 1
            """
        ),
        {
            "texto_ascii": texto_ascii,
            "limpio_ascii": texto_ascii,
            "umbral_candidato": UMBRAL_CANDIDATO,
        },
    ).mappings().first()

    if row:
        return float(row["lat"]), float(row["lon"]), "bd", row["nombre"]

    lat, lon, nombre_nom = _obtener_coordenadas_nominatim(punto_referencia)
    if lat is not None and lon is not None:
        return lat, lon, "nominatim", nombre_nom

    return None, None, "ninguno", None


def _resolver_distancia_metros(
    distancia: float | None,
    unidad: str | None,
) -> float:
    if distancia is None or distancia <= 0:
        return RADIO_BUSQUEDA_DEFECTO_M
    if unidad == "km":
        return distancia * 1000.0
    return distancia


def _usa_radio_progresivo(payload: GisRequest) -> bool:
    """Expande 500 m -> 1 km -> 1.5 km solo cuando el radio no fue fijado explícitamente."""
    return payload.distancia is None


def _radios_gis_a_intentar(payload: GisRequest) -> list[float]:
    if _usa_radio_progresivo(payload):
        return list(RADIOS_GIS_PROGRESIVOS_M)
    radio = _resolver_distancia_metros(payload.distancia, payload.unidad)
    return [min(radio, RADIO_GIS_MAX_M)]


def _buscar_sitios_dentro_radio(
    db: Session,
    *,
    lat_origen: float,
    lon_origen: float,
    radio_metros: float,
    filtros_alcance: list[str],
    params_alcance: dict[str, Any],
    zonas_excluidas: list[str],
) -> list[SitioGisItem]:
    filtros_sql = [
        "s.activo = TRUE",
        "s.ubicacion IS NOT NULL",
        "ST_DWithin(s.ubicacion, ST_SetSRID(ST_MakePoint(:lon, :lat), 4326), :radio)",
        *filtros_alcance,
    ]
    params: dict[str, Any] = {
        "lat": lat_origen,
        "lon": lon_origen,
        "radio": radio_metros,
        **params_alcance,
    }

    rows = db.execute(
        text(
            f"""
            SELECT
                s.id_sitio,
                s.nombre,
                ST_Distance(s.ubicacion, ST_SetSRID(ST_MakePoint(:lon, :lat), 4326)) AS distancia,
                ST_Y(s.ubicacion::geometry) AS lat_sitio,
                ST_X(s.ubicacion::geometry) AS lon_sitio
            FROM turismo.sitio s
            WHERE {' AND '.join(filtros_sql)}
            ORDER BY distancia ASC
            """
        ),
        params,
    ).mappings().all()

    sitios_coincidentes: list[SitioGisItem] = []
    for candidato in rows:
        if _esta_excluido(db, candidato["nombre"], zonas_excluidas):
            continue
        sitios_coincidentes.append(
            SitioGisItem(
                id_sitio=int(candidato["id_sitio"]),
                nombre=candidato["nombre"],
                distancia_metros=float(candidato["distancia"]),
                latitud=float(candidato["lat_sitio"]),
                longitud=float(candidato["lon_sitio"]),
            )
        )
    return sitios_coincidentes


def _obtener_sitios_para_mapa(
    db: Session,
    ids_sitios: list[int],
) -> list[SitioGisItem]:
    if not ids_sitios:
        return []

    rows = db.execute(
        text(
            """
            SELECT
                s.id_sitio,
                s.nombre,
                ST_Y(s.ubicacion::geometry) AS lat_sitio,
                ST_X(s.ubicacion::geometry) AS lon_sitio
            FROM turismo.sitio s
            WHERE s.activo = TRUE
              AND s.id_sitio = ANY(:ids_sitios)
              AND s.ubicacion IS NOT NULL
            ORDER BY s.nombre ASC
            """
        ),
        {"ids_sitios": ids_sitios},
    ).mappings().all()

    return [
        SitioGisItem(
            id_sitio=int(row["id_sitio"]),
            nombre=row["nombre"],
            distancia_metros=0.0,
            latitud=float(row["lat_sitio"]),
            longitud=float(row["lon_sitio"]),
        )
        for row in rows
    ]


def _gis_tiene_alcance(alcance_aplicado: AlcanceAplicado) -> bool:
    return alcance_aplicado != "todos"


def _filtrar_ids_por_parroquia(
    db: Session,
    ids_candidatos: list[int],
    nombre_parroquia: str,
) -> list[int]:
    if not ids_candidatos or not str(nombre_parroquia or "").strip():
        return []

    rows = db.execute(
        text(
            """
            SELECT s.id_sitio
            FROM turismo.sitio s
            JOIN turismo.parroquia p ON p.id_parroquia = s.id_parroquia
            WHERE s.id_sitio = ANY(:ids_candidatos)
              AND UPPER(TRIM(p.nombre)) = UPPER(TRIM(:nombre_parroquia))
            ORDER BY s.id_sitio
            """
        ),
        {
            "ids_candidatos": ids_candidatos,
            "nombre_parroquia": nombre_parroquia,
        },
    ).scalars().all()
    return [int(id_sitio) for id_sitio in rows]


def _gis_params_tienen_alcance_previo(
    params: dict[str, Any],
    ids_antes_del_paso: list[int],
) -> bool:
    if ids_antes_del_paso:
        return True
    categoria = params.get("categoria")
    subcategoria = params.get("subcategoria")
    return bool(categoria and str(categoria).strip()) or bool(
        subcategoria and str(subcategoria).strip()
    )


def gis(
    db: Session,
    payload: GisRequest,
    ubicacion_usuario: dict[str, float] | None = None,
) -> GisResponse:
    inicio = time.perf_counter()

    lat_origen, lon_origen, fuente_origen, nombre_origen = _resolver_punto_origen(
        db,
        payload.usar_ubicacion_usuario,
        ubicacion_usuario,
        payload.punto_referencia,
    )

    if lat_origen is None or lon_origen is None:
        tiempo_ms = round((time.perf_counter() - inicio) * 1000, 2)
        return GisResponse(
            ok=False,
            total=0,
            radio_busqueda_metros=_resolver_distancia_metros(payload.distancia, payload.unidad),
            tiempo_ms=tiempo_ms,
            mensaje=(
                "No se pudo determinar el punto de origen. "
                "Asegúrese de proveer coordenadas válidas o un punto de referencia reconocible."
            ),
        )

    try:
        filtros_alcance, params_alcance, alcance_aplicado, meta_alcance = (
            _construir_alcance_sitios(
                db,
                payload.categoria,
                payload.subcategoria,
                payload.ids_sitios_candidatos,
            )
        )
    except ValueError as exc:
        tiempo_ms = round((time.perf_counter() - inicio) * 1000, 2)
        return GisResponse(
            ok=False,
            total=0,
            radio_busqueda_metros=_resolver_distancia_metros(payload.distancia, payload.unidad),
            tiempo_ms=tiempo_ms,
            mensaje=str(exc),
        )

    if not _gis_tiene_alcance(alcance_aplicado):
        tiempo_ms = round((time.perf_counter() - inicio) * 1000, 2)
        return GisResponse(
            ok=False,
            total=0,
            radio_busqueda_metros=_resolver_distancia_metros(
                payload.distancia, payload.unidad
            ),
            tiempo_ms=tiempo_ms,
            mensaje=(
                "GIS requiere alcance previo: ids_sitios_candidatos o "
                "categoria/subcategoria."
            ),
        )

    zonas_excluidas = _normalizar_excluir(payload.excluir_zonas)
    radios_intentados = _radios_gis_a_intentar(payload)
    sitios_coincidentes: list[SitioGisItem] = []
    radio_efectivo = radios_intentados[0]

    for radio_metros in radios_intentados:
        radio_efectivo = radio_metros
        sitios_coincidentes = _buscar_sitios_dentro_radio(
            db,
            lat_origen=lat_origen,
            lon_origen=lon_origen,
            radio_metros=radio_metros,
            filtros_alcance=filtros_alcance,
            params_alcance=params_alcance,
            zonas_excluidas=zonas_excluidas,
        )
        if sitios_coincidentes:
            break

    filtros_aplicados = {
        "usar_ubicacion_usuario": payload.usar_ubicacion_usuario,
        "distancia": payload.distancia,
        "unidad": payload.unidad,
        "punto_referencia": payload.punto_referencia,
    }
    tiempo_ms = round((time.perf_counter() - inicio) * 1000, 2)
    total = len(sitios_coincidentes)
    radio_expandido = (
        _usa_radio_progresivo(payload)
        and radio_efectivo > RADIO_BUSQUEDA_DEFECTO_M
    )
    respuesta_alcance = {
        "alcance_aplicado": alcance_aplicado,
        "categoria_resuelta": meta_alcance.get("categoria_resuelta"),
        "subcategoria_resuelta": meta_alcance.get("subcategoria_resuelta"),
        "ids_sitios_candidatos_aplicados": meta_alcance.get(
            "ids_sitios_candidatos_aplicados", []
        ),
        "excluir_zonas_aplicadas": zonas_excluidas,
        "punto_origen_lat": lat_origen,
        "punto_origen_lon": lon_origen,
        "punto_origen_fuente": fuente_origen,
        "punto_origen_nombre": nombre_origen,
        "radio_busqueda_metros": radio_efectivo,
        "radio_expandido": radio_expandido,
        "radios_intentados_metros": radios_intentados,
        "filtros_aplicados": filtros_aplicados,
    }

    if total == 0:
        ids_fallback = meta_alcance.get("ids_sitios_candidatos_aplicados", [])
        if ids_fallback:
            sitios_mapa = _obtener_sitios_para_mapa(db, ids_fallback)
            if sitios_mapa:
                max_radio = int(RADIO_GIS_MAX_M)
                return GisResponse(
                    ok=False,
                    total=len(sitios_mapa),
                    ids_sitios=[sitio.id_sitio for sitio in sitios_mapa],
                    sitios=sitios_mapa,
                    tiempo_ms=tiempo_ms,
                    gis_fallback_mapa=True,
                    mensaje=(
                        f"No encontré sitios cerca de ti en un radio de hasta {max_radio} m. "
                        "Pero puedes observar estos sitios en el mapa."
                    ),
                    **respuesta_alcance,
                )

        return GisResponse(
            ok=False,
            total=0,
            tiempo_ms=tiempo_ms,
            gis_fallback_mapa=False,
            mensaje=(
                f"No se encontraron sitios en un radio de hasta {int(radio_efectivo)} m."
            ),
            **respuesta_alcance,
        )

    if radio_expandido:
        mensaje = (
            f"Se encontraron {total} sitio(s) en un radio de {int(radio_efectivo)} m "
            f"(se amplió la búsqueda desde {int(RADIO_BUSQUEDA_DEFECTO_M)} m)."
        )
    else:
        mensaje = f"Se encontraron {total} sitio(s) en un radio de {int(radio_efectivo)} m."

    return GisResponse(
        ok=True,
        total=total,
        ids_sitios=[sitio.id_sitio for sitio in sitios_coincidentes],
        sitios=sitios_coincidentes,
        tiempo_ms=tiempo_ms,
        gis_fallback_mapa=False,
        mensaje=mensaje,
        **respuesta_alcance,
    )


def busqueda_semantica(
    db: Session,
    payload: BusquedaSemanticaRequest,
) -> BusquedaSemanticaResponse:
    inicio = time.perf_counter()

    texto_busqueda = payload.texto_embeddings.strip()
    if not texto_busqueda:
        tiempo_ms = round((time.perf_counter() - inicio) * 1000, 2)
        return BusquedaSemanticaResponse(
            ok=False,
            total=0,
            tiempo_ms=tiempo_ms,
            mensaje="El texto de busqueda semantica no puede estar vacio.",
        )

    try:
        filtros_alcance, params_alcance, alcance_aplicado, meta_alcance = (
            _construir_alcance_sitios(
                db,
                payload.categoria,
                payload.subcategoria,
                payload.ids_sitios_candidatos,
            )
        )
    except ValueError as exc:
        tiempo_ms = round((time.perf_counter() - inicio) * 1000, 2)
        return BusquedaSemanticaResponse(
            ok=False,
            total=0,
            tiempo_ms=tiempo_ms,
            mensaje=str(exc),
        )

    embedding_str = generar_embedding(texto_busqueda)
    if not embedding_str:
        tiempo_ms = round((time.perf_counter() - inicio) * 1000, 2)
        return BusquedaSemanticaResponse(
            ok=False,
            total=0,
            tiempo_ms=tiempo_ms,
            mensaje="No se pudo generar el embedding para la busqueda semantica.",
        )

    terminos_excluidos = _normalizar_excluir(payload.excluir_terminos)
    posibles_match = _normalizar_excluir(payload.posibles_match)
    umbral_minimo = 0.70

    filtros_sql = [
        "s.activo = TRUE",
        "sd.activo = TRUE",
        *filtros_alcance,
    ]
    params: dict[str, Any] = {
        "embedding": embedding_str,
        **params_alcance,
    }

    if terminos_excluidos:
        condiciones_exclusion = []
        for i, termino in enumerate(terminos_excluidos):
            key = f"excluir_{i}"
            condiciones_exclusion.append(f"sdc.contenido ILIKE :{key}")
            params[key] = f"%{termino}%"
        
        filtros_sql.append(f"NOT ({' OR '.join(condiciones_exclusion)})")

    keyword_score_sql = "0.0"
    keyword_matches_sql = "ARRAY[]::text[]"
    if posibles_match:
        keyword_scores = []
        keyword_matches = []
        for i, palabra in enumerate(posibles_match):
            key = f"keyword_{i}"
            like_key = f"keyword_like_{i}"
            params[key] = palabra
            params[like_key] = f"%{palabra}%"
            texto_chunk = "concat_ws(' ', sdc.titulo, sdc.contenido)"
            keyword_scores.append(
                f"""
                CASE
                    WHEN {texto_chunk} ILIKE :{like_key} THEN 1.0
                    ELSE GREATEST(
                        similarity(lower({texto_chunk}), lower(:{key})),
                        similarity(lower(sdc.titulo), lower(:{key}))
                    )
                END
                """
            )
            keyword_matches.append(
                f"CASE WHEN {texto_chunk} ILIKE :{like_key} THEN :{key} ELSE NULL END"
            )
        keyword_score_sql = f"GREATEST({', '.join(keyword_scores)})"
        keyword_matches_sql = (
            "array_remove(ARRAY[" + ", ".join(keyword_matches) + "], NULL)"
        )

    query = f"""
        WITH scored_chunks AS (
            SELECT
                s.id_sitio,
                s.nombre,
                sdc.titulo AS titulo_chunk,
                sdc.contenido AS contenido_chunk,
                1 - (sdc.embedding <=> :embedding) AS score_embedding,
                {keyword_score_sql} AS score_palabras_clave,
                {keyword_matches_sql} AS palabras_clave_match
            FROM turismo.sitio s
            JOIN turismo.sitio_documento sd ON sd.id_vinculo = s.id_sitio
            JOIN turismo.sitio_documento_chunk sdc ON sdc.id_documento = sd.id_documento
            WHERE {' AND '.join(filtros_sql)}
        ),
        ranked_chunks AS (
            SELECT
                id_sitio,
                nombre,
                titulo_chunk,
                contenido_chunk,
                score_embedding,
                score_palabras_clave,
                palabras_clave_match,
                ((score_embedding * 0.75) + (score_palabras_clave * 0.25)) AS score_similitud,
                ROW_NUMBER() OVER(
                    PARTITION BY id_sitio
                    ORDER BY ((score_embedding * 0.75) + (score_palabras_clave * 0.25)) DESC
                ) AS rn
            FROM scored_chunks
        )
        SELECT
            id_sitio,
            nombre,
            titulo_chunk,
            contenido_chunk,
            score_embedding,
            score_palabras_clave,
            palabras_clave_match,
            score_similitud
        FROM ranked_chunks
        WHERE rn = 1
        ORDER BY score_similitud DESC
        LIMIT 25
    """
    params["umbral_minimo"] = umbral_minimo

    try:
        rows = db.execute(text(query), params).mappings().all()
    except Exception as e:
        tiempo_ms = round((time.perf_counter() - inicio) * 1000, 2)
        return BusquedaSemanticaResponse(
            ok=False,
            total=0,
            tiempo_ms=tiempo_ms,
            mensaje=f"Error en la consulta: {str(e)}",
        )

    top_sitios_semantica = [
        CandidatoSemanticoDebugItem(
            id_sitio=int(row["id_sitio"]),
            nombre=row["nombre"],
            score_similitud=float(row["score_similitud"]),
            score_embedding=float(row["score_embedding"]),
            score_palabras_clave=float(row["score_palabras_clave"]),
            titulo_chunk=row["titulo_chunk"],
            contenido_chunk=row["contenido_chunk"],
            palabras_clave_match=list(row["palabras_clave_match"] or []),
            supera_umbral=float(row["score_similitud"]) >= umbral_minimo,
            similitud_porcentaje=round(float(row["score_similitud"]) * 100, 2),
            motivo=(
                "supera_umbral"
                if float(row["score_similitud"]) >= umbral_minimo
                else "descartado_por_umbral"
            ),
        )
        for row in rows
    ]

    sitios_coincidentes = [
        SitioSemanticoItem(
            id_sitio=candidato.id_sitio,
            nombre=candidato.nombre,
            score_similitud=candidato.score_similitud,
            score_embedding=candidato.score_embedding,
            score_palabras_clave=candidato.score_palabras_clave,
            titulo_chunk=candidato.titulo_chunk,
            contenido_chunk=candidato.contenido_chunk,
            palabras_clave_match=candidato.palabras_clave_match,
        )
        for candidato in top_sitios_semantica
        if candidato.supera_umbral
    ]

    filtros_aplicados = {
        "texto_embeddings": texto_busqueda,
        "posibles_match": posibles_match,
        "peso_embedding": 0.75,
        "peso_palabras_clave": 0.25,
        "umbral_minimo": umbral_minimo,
    }
    tiempo_ms = round((time.perf_counter() - inicio) * 1000, 2)
    total = len(sitios_coincidentes)
    respuesta_alcance = {
        "alcance_aplicado": alcance_aplicado,
        "categoria_resuelta": meta_alcance.get("categoria_resuelta"),
        "subcategoria_resuelta": meta_alcance.get("subcategoria_resuelta"),
        "ids_sitios_candidatos_aplicados": meta_alcance.get(
            "ids_sitios_candidatos_aplicados", []
        ),
        "excluir_terminos_aplicados": terminos_excluidos,
        "posibles_match_aplicados": posibles_match,
        "umbral_minimo": umbral_minimo,
        "filtros_aplicados": filtros_aplicados,
    }

    if total == 0:
        return BusquedaSemanticaResponse(
            ok=False,
            total=0,
            tiempo_ms=tiempo_ms,
            mensaje=(
                "No se encontraron sitios con una probabilidad minima del "
                f"{int(umbral_minimo * 100)}% para la busqueda semantica."
            ),
            top_sitios_semantica=top_sitios_semantica,
            **respuesta_alcance,
        )

    return BusquedaSemanticaResponse(
        ok=True,
        total=total,
        ids_sitios=[sitio.id_sitio for sitio in sitios_coincidentes],
        sitios=sitios_coincidentes,
        top_sitios_semantica=top_sitios_semantica,
        tiempo_ms=tiempo_ms,
        mensaje=f"Se encontraron {total} sitio(s) relevantes por busqueda semantica.",
        **respuesta_alcance,
    )


def _extraer_criterio_semantico(params: dict[str, Any]) -> str:
    posibles_match = params.get("posibles_match") or []
    if isinstance(posibles_match, list):
        for frase in posibles_match:
            texto = str(frase).strip()
            if texto:
                return texto
    texto_embeddings = str(params.get("texto_embeddings") or "").strip()
    if texto_embeddings:
        return texto_embeddings[:80]
    return "lo que buscas"


def _referencia_tipo_sitio(subcategoria: str | None) -> str:
    if not subcategoria or not str(subcategoria).strip():
        return "el sitio más cercano registrado en la zona"
    nombre = str(subcategoria).strip().lower()
    femeninos = {
        "laguna",
        "montaña",
        "montana",
        "cascada",
        "quebrada",
        "iglesia",
        "hostería",
        "hosteria",
        "cafeteria",
        "discoteca",
        "gastronomía",
        "gastronomia",
    }
    if nombre in femeninos or nombre.endswith("a"):
        return f"la {nombre} más cercana registrada en la zona"
    return f"el {nombre} más cercano registrado en la zona"


def _construir_mensaje_retroalimentacion_semantica_gis(
    criterio: str | None,
    subcategoria: str | None,
) -> str:
    criterio_texto = (criterio or "lo que buscas").strip()
    referencia = _referencia_tipo_sitio(subcategoria)
    return (
        f"No encontré opciones que cumplan exactamente con '{criterio_texto}', "
        f"pero te muestro {referencia} por si te interesa conocerla."
    )


def _aplicar_retroalimentacion_semantica_gis_rama(
    ids_candidatos_rama: list[int],
    campos_rama: dict[int, dict[str, Any]],
    criterio_semantico: str | None,
    tipo_sitio: str | None,
) -> str | None:
    mensaje = _construir_mensaje_retroalimentacion_semantica_gis(
        criterio_semantico,
        tipo_sitio,
    )
    aplicado = False
    for id_sitio in ids_candidatos_rama:
        campos = campos_rama[id_sitio]
        if campos.get("semantica_sin_coincidencias") and (
            campos.get("gis_fallback_mapa") or campos.get("gis_sin_cercania")
        ):
            campos["retroalimentacion_turistica"] = mensaje
            aplicado = True
    return mensaje if aplicado else None


FILTROS_SECUNDARIOS = frozenset({
    "precio",
    "tarifa_acceso",
    "horario",
    "contactos",
    "campos_parametrizados",
})


def _tiene_criterio_filtro(nombre_herr: str, params: dict[str, Any]) -> bool:
    if nombre_herr in ("precio", "tarifa_acceso"):
        etiqueta = params.get("etiqueta")
        if etiqueta and str(etiqueta).strip():
            return True
        return params.get("precio_numero") is not None

    if nombre_herr == "horario":
        tipo = params.get("tipo", "ninguno")
        if tipo in (None, "ninguno"):
            return False
        if tipo in {"abierto_ahora", "abierto_24h"}:
            return True
        if tipo == "atiende_dia":
            return _resolver_dia_semana(params.get("dia_semana")) is not None
        if tipo == "abierto_en_hora":
            return (
                _resolver_hora(params.get("hora"), params.get("meridiano"))
                is not None
            )
        if tipo == "abierto_en_rango":
            rango = params.get("rango_hora") or {}
            if not isinstance(rango, dict):
                inicio = getattr(rango, "inicio", None)
                fin = getattr(rango, "fin", None)
            else:
                inicio = rango.get("inicio")
                fin = rango.get("fin")
            meridiano = params.get("meridiano")
            return (
                _resolver_hora(inicio, meridiano) is not None
                and _resolver_hora(fin, meridiano) is not None
            )
        return False

    if nombre_herr == "contactos":
        contacto = params.get("contacto_sugerido")
        if not contacto or not str(contacto).strip():
            return False
        return _resolver_tipo_contacto(str(contacto)) is not None

    if nombre_herr == "campos_parametrizados":
        req = CamposParametrizadosRequest(**params)
        return _tiene_filtros_activos(req)

    return True


def ejecutar_plan(
    db: Session,
    payload: EjecutarPlanRequest,
) -> EjecutarPlanResponse:
    inicio = time.perf_counter()

    def _ejecutar_rama(herramientas_rama: list[Any]) -> tuple[
        list[int],
        list[int],
        dict[int, dict[str, Any]],
        dict[int, dict[str, Any]],
        list[CandidatoSemanticoDebugItem],
        bool,
        bool,
        bool,
        bool,
        str | None,
        bool,
        str | None,
        list[str],
    ]:
        herramientas = sorted(herramientas_rama, key=lambda h: h.orden)
        ids_candidatos_rama: list[int] = []
        ids_rutas_candidatos_rama: list[int] = []
        campos_rama: dict[int, dict[str, Any]] = defaultdict(dict)
        campos_rutas_rama: dict[int, dict[str, Any]] = defaultdict(dict)
        candidatos_semanticos_rama: list[CandidatoSemanticoDebugItem] = []
        semantic_fallback_rama = False
        gis_fallback_rama = False
        filtro_passthrough_rama = False
        gis_alcance_passthrough_rama = False
        recomendacion_fallback_rama = False
        recomendacion_turistica_rama: str | None = None
        hubo_alcance_previo = False
        criterio_semantico_rama: str | None = None
        tipo_sitio_rama: str | None = None
        categoria_rama: str | None = None

        for paso in herramientas:
            nombre_herr = paso.herramienta
            params = dict(paso.parametros)
            ids_antes_del_paso = list(ids_candidatos_rama)

            if ids_candidatos_rama:
                params["ids_sitios_candidatos"] = ids_candidatos_rama
            if ids_rutas_candidatos_rama:
                params["ids_rutas_candidatos"] = ids_rutas_candidatos_rama

            passthrough_sin_criterio = (
                nombre_herr in FILTROS_SECUNDARIOS
                and not _tiene_criterio_filtro(nombre_herr, params)
            )
            if passthrough_sin_criterio:
                if ids_antes_del_paso:
                    filtro_passthrough_rama = True
                    for id_sitio in ids_antes_del_paso:
                        campos_rama[id_sitio]["filtro_passthrough"] = nombre_herr
                else:
                    ids_candidatos_rama = []

            elif nombre_herr == "categoria_subcategoria":
                req = CategoriaSubcategoriaRequest(**params)
                res = categoria_subcategoria(db, req)
                if res.ok:
                    ids_candidatos_rama = res.ids_sitios
                    categoria_rama = (
                        res.categoria_resuelta
                        or params.get("categoria")
                        or categoria_rama
                    )
                    tipo_sitio_rama = (
                        res.subcategoria_resuelta
                        or params.get("subcategoria")
                        or tipo_sitio_rama
                    )
                else:
                    ids_candidatos_rama = []

            elif nombre_herr == "busqueda_aproximada":
                req = BusquedaAproximadaRequest(**params)
                res = busqueda_aproximada(db, req)
                if res.ok and res.tipo_resultado == "sitio":
                    ids_candidatos_rama = res.ids_sitios
                    for sitio in res.sitios:
                        campos_rama[sitio.id_sitio]["direccion"] = (
                            sitio.direccion_texto
                        )
                elif (
                    res.ok
                    and res.tipo_resultado == "parroquia"
                    and res.nombre
                    and ids_antes_del_paso
                ):
                    ids_candidatos_rama = _filtrar_ids_por_parroquia(
                        db,
                        ids_antes_del_paso,
                        res.nombre,
                    )
                    for id_sitio in ids_candidatos_rama:
                        campos_rama[id_sitio]["parroquia"] = res.nombre
                else:
                    ids_candidatos_rama = []

            elif nombre_herr == "campos_parametrizados":
                req = CamposParametrizadosRequest(**params)
                res = campos_parametrizados(db, req)
                if res.ok:
                    ids_candidatos_rama = res.ids_sitios
                    for sitio in res.sitios:
                        for campo, valor in res.filtros_aplicados.items():
                            campos_rama[sitio.id_sitio][campo] = valor
                else:
                    ids_candidatos_rama = []

            elif nombre_herr == "contactos":
                req = ContactosRequest(**params)
                res = contactos(db, req)
                if res.ok:
                    ids_candidatos_rama = res.ids_sitios
                    for sitio in res.sitios:
                        if sitio.tiene_contacto_sugerido:
                            contactos_sugeridos = [
                                c.contenido
                                for c in sitio.contactos
                                if c.tipo == res.contacto_sugerido_resuelto
                            ]
                            if contactos_sugeridos:
                                campos_rama[sitio.id_sitio][
                                    res.contacto_sugerido_resuelto
                                ] = contactos_sugeridos[0]
                else:
                    ids_candidatos_rama = []

            elif nombre_herr == "horario":
                req = HorarioRequest(**params)
                res = horario(db, req)
                if res.ok:
                    ids_candidatos_rama = res.ids_sitios
                    for sitio in res.sitios:
                        for campo, valor in res.filtros_aplicados.items():
                            campos_rama[sitio.id_sitio][campo] = valor
                        if sitio.abierto_24h:
                            campos_rama[sitio.id_sitio]["abierto_24h"] = True
                else:
                    ids_candidatos_rama = []

            elif nombre_herr == "precio":
                req = PrecioRequest(**params)
                res = precio(db, req)
                if res.ok:
                    ids_candidatos_rama = res.ids_sitios
                    for sitio in res.sitios:
                        for campo, valor in res.filtros_aplicados.items():
                            campos_rama[sitio.id_sitio][campo] = valor
                        campos_rama[sitio.id_sitio]["precio_min"] = sitio.precio_min
                        campos_rama[sitio.id_sitio]["precio_max"] = sitio.precio_max
                        if sitio.fuente_precio:
                            campos_rama[sitio.id_sitio]["fuente_precio"] = (
                                sitio.fuente_precio
                            )
                        if sitio.etiqueta_precio:
                            campos_rama[sitio.id_sitio]["etiqueta_precio"] = (
                                sitio.etiqueta_precio
                            )
                else:
                    ids_candidatos_rama = []

            elif nombre_herr == "tarifa_acceso":
                req = TarifaAccesoRequest(**params)
                res = tarifa_acceso(db, req)
                if res.ok:
                    ids_candidatos_rama = res.ids_sitios
                    for sitio in res.sitios:
                        for campo, valor in res.filtros_aplicados.items():
                            campos_rama[sitio.id_sitio][campo] = valor
                        campos_rama[sitio.id_sitio]["precio"] = sitio.precio
                        campos_rama[sitio.id_sitio]["fuente_precio"] = (
                            sitio.fuente_precio
                        )
                        campos_rama[sitio.id_sitio]["etiqueta_precio"] = (
                            sitio.etiqueta_precio
                        )
                        if sitio.condicion:
                            campos_rama[sitio.id_sitio]["condicion"] = sitio.condicion
                        if sitio.precio_min is not None:
                            campos_rama[sitio.id_sitio]["precio_min"] = sitio.precio_min
                        if sitio.precio_max is not None:
                            campos_rama[sitio.id_sitio]["precio_max"] = sitio.precio_max
                else:
                    ids_candidatos_rama = []

            elif nombre_herr == "ruta":
                req = RutaRequest(**params)
                res = ruta(db, req)
                if res.ok:
                    ids_rutas_candidatos_rama = res.ids_rutas
                    for ruta_item in res.rutas:
                        for campo, valor in res.filtros_aplicados.items():
                            campos_rutas_rama[ruta_item.id_ruta][campo] = valor
                        campos_rutas_rama[ruta_item.id_ruta]["tipo_ruta"] = (
                            ruta_item.tipo_ruta
                        )
                else:
                    ids_rutas_candidatos_rama = []

            elif nombre_herr == "gis":
                if not _gis_params_tienen_alcance_previo(params, ids_antes_del_paso):
                    gis_alcance_passthrough_rama = True
                    if ids_antes_del_paso:
                        for id_sitio in ids_antes_del_paso:
                            campos_rama[id_sitio]["gis_alcance_passthrough"] = True
                    else:
                        ids_candidatos_rama = []
                else:
                    req = GisRequest(**params)
                    res = gis(db, req, paso.ubicacion_usuario)
                    if res.ok:
                        ids_candidatos_rama = res.ids_sitios
                        for sitio in res.sitios:
                            for campo, valor in res.filtros_aplicados.items():
                                campos_rama[sitio.id_sitio][campo] = valor
                            campos_rama[sitio.id_sitio]["distancia_metros"] = round(
                                sitio.distancia_metros, 2
                            )
                            if res.radio_expandido:
                                campos_rama[sitio.id_sitio]["radio_expandido"] = True
                    elif res.gis_fallback_mapa and res.ids_sitios:
                        gis_fallback_rama = True
                        ids_candidatos_rama = res.ids_sitios
                        for sitio in res.sitios:
                            campos_rama[sitio.id_sitio]["gis_fallback_mapa"] = True
                            campos_rama[sitio.id_sitio]["gis_sin_cercania"] = True
                            campos_rama[sitio.id_sitio]["gis_mensaje_mapa"] = res.mensaje
                    elif ids_antes_del_paso:
                        gis_fallback_rama = True
                        ids_candidatos_rama = ids_antes_del_paso
                        for id_sitio in ids_candidatos_rama:
                            campos_rama[id_sitio]["gis_fallback_mapa"] = True
                            campos_rama[id_sitio]["gis_sin_cercania"] = True
                    else:
                        ids_candidatos_rama = []

            elif nombre_herr == "busqueda_semantica":
                criterio_semantico_rama = _extraer_criterio_semantico(params)
                req = BusquedaSemanticaRequest(**params)
                res = busqueda_semantica(db, req)
                candidatos_semanticos_rama.extend(res.top_sitios_semantica)
                if res.ok:
                    ids_candidatos_rama = res.ids_sitios
                    for sitio in res.sitios:
                        for campo, valor in res.filtros_aplicados.items():
                            campos_rama[sitio.id_sitio][campo] = valor
                        campos_rama[sitio.id_sitio]["score_similitud"] = round(
                            sitio.score_similitud, 4
                        )
                        campos_rama[sitio.id_sitio]["score_embedding"] = round(
                            sitio.score_embedding, 4
                        )
                        campos_rama[sitio.id_sitio]["score_palabras_clave"] = round(
                            sitio.score_palabras_clave, 4
                        )
                        campos_rama[sitio.id_sitio]["titulo_chunk"] = sitio.titulo_chunk
                        campos_rama[sitio.id_sitio]["contenido_chunk"] = (
                            sitio.contenido_chunk
                        )
                        campos_rama[sitio.id_sitio]["palabras_clave_match"] = (
                            sitio.palabras_clave_match
                        )
                else:
                    if ids_antes_del_paso:
                        ids_candidatos_rama = ids_antes_del_paso
                        semantic_fallback_rama = True
                        for id_sitio in ids_candidatos_rama:
                            campos_rama[id_sitio][
                                "semantica_sin_coincidencias"
                            ] = True
                            campos_rama[id_sitio][
                                "semantica_fallback"
                            ] = "Se conservaron los filtros previos."
                    else:
                        ids_candidatos_rama = []

            if (
                not passthrough_sin_criterio
                and debe_aplicar_recomendacion_calida(
                    nombre_herr,
                    params,
                    ids_antes_del_paso,
                    ids_candidatos_rama,
                    _tiene_criterio_filtro,
                )
            ):
                mensaje_recomendacion = construir_mensaje_recomendacion(
                    nombre_herr,
                    params,
                    subcategoria=tipo_sitio_rama,
                    categoria=categoria_rama,
                )
                ids_candidatos_rama = list(ids_antes_del_paso)
                recomendacion_fallback_rama = True
                recomendacion_turistica_rama = mensaje_recomendacion
                marcar_recomendacion_en_campos(
                    campos_rama,
                    ids_candidatos_rama,
                    nombre_herr,
                    mensaje_recomendacion,
                )

            if ids_candidatos_rama or ids_rutas_candidatos_rama:
                hubo_alcance_previo = True

            sin_resultados = False
            if nombre_herr == "ruta":
                sin_resultados = not ids_rutas_candidatos_rama
            elif nombre_herr in {
                "busqueda_aproximada",
                "categoria_subcategoria",
                "campos_parametrizados",
                "contactos",
                "horario",
                "precio",
                "tarifa_acceso",
                "gis",
                "busqueda_semantica",
            }:
                sin_resultados = not ids_candidatos_rama

            if sin_resultados and paso.orden > 1:
                break

        retroalimentacion_semantica_gis_rama = _aplicar_retroalimentacion_semantica_gis_rama(
            ids_candidatos_rama,
            campos_rama,
            criterio_semantico_rama,
            tipo_sitio_rama,
        )

        sugerencias_rama: list[str] = []
        if (
            not ids_candidatos_rama
            and not ids_rutas_candidatos_rama
            and not hubo_alcance_previo
        ):
            sugerencias_rama = generar_fallback_frio(herramientas)

        return (
            ids_candidatos_rama,
            ids_rutas_candidatos_rama,
            campos_rama,
            campos_rutas_rama,
            candidatos_semanticos_rama,
            semantic_fallback_rama,
            gis_fallback_rama,
            filtro_passthrough_rama,
            gis_alcance_passthrough_rama,
            retroalimentacion_semantica_gis_rama,
            recomendacion_fallback_rama,
            recomendacion_turistica_rama,
            sugerencias_rama,
        )

    def _agregar_ids(destino: list[int], nuevos: list[int]) -> None:
        vistos = set(destino)
        for item_id in nuevos:
            if item_id not in vistos:
                destino.append(item_id)
                vistos.add(item_id)

    ids_candidatos: list[int] = []
    ids_rutas_candidatos: list[int] = []
    campos_dinamicos: dict[int, dict[str, Any]] = defaultdict(dict)
    campos_dinamicos_rutas: dict[int, dict[str, Any]] = defaultdict(dict)
    candidatos_semanticos: list[CandidatoSemanticoDebugItem] = []
    semantic_fallback_aplicado = False
    gis_fallback_mapa_aplicado = False
    filtro_passthrough_aplicado = False
    gis_alcance_passthrough_aplicado = False
    recomendacion_fallback_aplicado = False
    recomendacion_turistica: str | None = None
    sugerencias_exploracion: list[str] = []

    retroalimentacion_semantica_gis: str | None = None

    if payload.tipo_ejecucion == "paralelo":
        grupos: dict[str, list[Any]] = defaultdict(list)
        for idx, herramienta in enumerate(payload.herramientas):
            grupo = herramienta.grupo or herramienta.rama or f"rama_{idx + 1}"
            grupos[grupo].append(herramienta)

        for herramientas_rama in grupos.values():
            (
                ids_rama,
                ids_rutas_rama,
                campos_rama,
                campos_rutas_rama,
                candidatos_semanticos_rama,
                semantic_fallback_rama,
                gis_fallback_rama,
                filtro_passthrough_rama,
                gis_alcance_passthrough_rama,
                retroalimentacion_semantica_gis_rama,
                recomendacion_fallback_rama,
                recomendacion_turistica_rama,
                sugerencias_rama,
            ) = _ejecutar_rama(herramientas_rama)
            _agregar_ids(ids_candidatos, ids_rama)
            _agregar_ids(ids_rutas_candidatos, ids_rutas_rama)
            candidatos_semanticos.extend(candidatos_semanticos_rama)
            semantic_fallback_aplicado = (
                semantic_fallback_aplicado or semantic_fallback_rama
            )
            gis_fallback_mapa_aplicado = (
                gis_fallback_mapa_aplicado or gis_fallback_rama
            )
            filtro_passthrough_aplicado = (
                filtro_passthrough_aplicado or filtro_passthrough_rama
            )
            gis_alcance_passthrough_aplicado = (
                gis_alcance_passthrough_aplicado or gis_alcance_passthrough_rama
            )
            if retroalimentacion_semantica_gis_rama and not retroalimentacion_semantica_gis:
                retroalimentacion_semantica_gis = retroalimentacion_semantica_gis_rama
            recomendacion_fallback_aplicado = (
                recomendacion_fallback_aplicado or recomendacion_fallback_rama
            )
            if recomendacion_turistica_rama and not recomendacion_turistica:
                recomendacion_turistica = recomendacion_turistica_rama
            for sugerencia in sugerencias_rama:
                if sugerencia not in sugerencias_exploracion:
                    sugerencias_exploracion.append(sugerencia)
            for id_sitio, campos in campos_rama.items():
                campos_dinamicos[id_sitio].update(campos)
            for id_ruta, campos in campos_rutas_rama.items():
                campos_dinamicos_rutas[id_ruta].update(campos)
    else:
        (
            ids_candidatos,
            ids_rutas_candidatos,
            campos_dinamicos,
            campos_dinamicos_rutas,
            candidatos_semanticos,
            semantic_fallback_aplicado,
            gis_fallback_mapa_aplicado,
            filtro_passthrough_aplicado,
            gis_alcance_passthrough_aplicado,
            retroalimentacion_semantica_gis,
            recomendacion_fallback_aplicado,
            recomendacion_turistica,
            sugerencias_exploracion,
        ) = _ejecutar_rama(payload.herramientas)

    sitios_relacionados = ids_candidatos[:25]

    if len(ids_candidatos) > 5:
        ids_candidatos = random.sample(ids_candidatos, 5)
    if len(ids_rutas_candidatos) > 5:
        ids_rutas_candidatos = random.sample(ids_rutas_candidatos, 5)

    tarjetas: list[TarjetaSitio] = []
    if ids_candidatos:
        # Obtener campos base para construir tarjetas en la app.
        rows = db.execute(
            text(
                """
                SELECT
                    s.id_sitio,
                    s.nombre,
                    sub.nombre AS subcategoria,
                    dir.direccion_texto,
                    media.url AS imagen,
                    contacto.tipo::text AS contacto_tipo,
                    contacto.contenido AS contacto_contenido,
                    tarifa.precio AS tarifa_precio,
                    tarifa.condicion AS tarifa_condicion,
                    rango.precio_min,
                    rango.precio_max,
                    rango.etiqueta_precio::text AS etiqueta_precio
                FROM turismo.sitio s
                LEFT JOIN turismo.subcategoria sub ON sub.id_subcategoria = s.id_subcategoria
                LEFT JOIN turismo.direccion dir ON dir.id_sitio = s.id_sitio
                LEFT JOIN LATERAL (
                    SELECT m.url
                    FROM turismo.multimedia m
                    WHERE m.id_sitio = s.id_sitio
                      AND m.activo = TRUE
                    ORDER BY m.es_principal DESC, m.id_multimedia ASC
                    LIMIT 1
                ) media ON TRUE
                LEFT JOIN LATERAL (
                    SELECT c.tipo, c.contenido
                    FROM turismo.contacto c
                    WHERE c.id_sitio = s.id_sitio
                      AND c.activo = TRUE
                    ORDER BY
                        CASE WHEN c.tipo::text ILIKE '%%whatsapp%%' THEN 0 ELSE 1 END,
                        c.id_contacto ASC
                    LIMIT 1
                ) contacto ON TRUE
                LEFT JOIN LATERAL (
                    SELECT ta.precio, ta.condicion
                    FROM turismo.tarifa_acceso ta
                    WHERE ta.id_sitio = s.id_sitio
                      AND ta.activo = TRUE
                    ORDER BY ta.precio ASC, ta.id_tarifa_acceso ASC
                    LIMIT 1
                ) tarifa ON TRUE
                LEFT JOIN LATERAL (
                    SELECT rp.precio_min, rp.precio_max, rp.etiqueta_precio
                    FROM turismo.rango_precio rp
                    WHERE rp.id_sitio = s.id_sitio
                      AND rp.activo = TRUE
                    ORDER BY rp.precio_min ASC, rp.id_rango_precio ASC
                    LIMIT 1
                ) rango ON TRUE
                WHERE s.id_sitio = ANY(:ids)
                """
            ),
            {"ids": ids_candidatos},
        ).mappings().all()

        for row in rows:
            id_sitio = int(row["id_sitio"])
            dinamicos = campos_dinamicos.get(id_sitio, {})

            contacto_base = None
            if row["contacto_contenido"] and "contacto" not in dinamicos:
                contacto_base = {
                    "tipo": row["contacto_tipo"],
                    "contenido": row["contacto_contenido"],
                }

            precio_base = None
            tiene_precio_dinamico = any(
                key in dinamicos
                for key in (
                    "precio",
                    "precio_min",
                    "precio_max",
                    "fuente_precio",
                    "etiqueta_precio",
                )
            )
            if not tiene_precio_dinamico:
                if row["tarifa_precio"] is not None:
                    precio_base = {
                        "fuente": "tarifa_acceso",
                        "precio": float(row["tarifa_precio"]),
                        "condicion": row["tarifa_condicion"],
                    }
                elif row["precio_min"] is not None or row["precio_max"] is not None:
                    precio_base = {
                        "fuente": "rango_precio",
                        "precio_min": (
                            float(row["precio_min"])
                            if row["precio_min"] is not None
                            else None
                        ),
                        "precio_max": (
                            float(row["precio_max"])
                            if row["precio_max"] is not None
                            else None
                        ),
                        "etiqueta_precio": row["etiqueta_precio"],
                    }

            tarjeta = TarjetaSitio(
                id_sitio=id_sitio,
                nombre=row["nombre"],
                subcategoria=row["subcategoria"],
                imagen=row["imagen"],
                contacto=contacto_base,
                precio=precio_base,
                direccion=(
                    row["direccion_texto"]
                    if "direccion" not in dinamicos
                    else None
                ),
                campos_dinamicos=dinamicos,
            )
            tarjetas.append(tarjeta)

    tarjetas_rutas: list[TarjetaRuta] = []
    if ids_rutas_candidatos:
        rows_rutas = db.execute(
            text(
                """
                SELECT id_ruta, titulo, tipo_ruta::text AS tipo_ruta
                FROM gis.rutas_turistica
                WHERE id_ruta = ANY(:ids)
                """
            ),
            {"ids": ids_rutas_candidatos},
        ).mappings().all()

        for row in rows_rutas:
            id_ruta = int(row["id_ruta"])
            tarjetas_rutas.append(
                TarjetaRuta(
                    id_ruta=id_ruta,
                    titulo=row["titulo"],
                    tipo_ruta=row["tipo_ruta"],
                    campos_dinamicos=campos_dinamicos_rutas.get(id_ruta, {}),
                )
            )

    tiempo_ms = round((time.perf_counter() - inicio) * 1000, 2)
    total_sitios = len(tarjetas)
    total_rutas = len(tarjetas_rutas)
    if total_sitios and total_rutas:
        mensaje = (
            f"Plan ejecutado. Se encontraron {total_sitios} sitio(s) "
            f"y {total_rutas} ruta(s)."
        )
    elif total_rutas:
        mensaje = f"Plan ejecutado. Se encontraron {total_rutas} ruta(s)."
    elif total_sitios:
        if recomendacion_turistica:
            mensaje = recomendacion_turistica
        elif retroalimentacion_semantica_gis:
            mensaje = retroalimentacion_semantica_gis
        elif gis_fallback_mapa_aplicado:
            mensaje = (
                f"No encontramos sitios muy cerca, pero puedes observar "
                f"{total_sitios} sitio(s) en el mapa."
            )
        else:
            mensaje = f"Plan ejecutado. Se encontraron {total_sitios} sitio(s)."
    else:
        if sugerencias_exploracion:
            mensaje = MENSAJE_FALLBACK_FRIO
        else:
            mensaje = "No se encontraron resultados que cumplan con el plan."

    return EjecutarPlanResponse(
        ok=total_sitios > 0 or total_rutas > 0,
        client_mensaje_id=payload.client_mensaje_id,
        tarjetas=tarjetas,
        tarjetas_rutas=tarjetas_rutas,
        sitios_relacionados=sitios_relacionados,
        candidatos_semanticos=candidatos_semanticos,
        semantic_fallback_aplicado=semantic_fallback_aplicado,
        gis_fallback_mapa_aplicado=gis_fallback_mapa_aplicado,
        filtro_passthrough_aplicado=filtro_passthrough_aplicado,
        gis_alcance_passthrough_aplicado=gis_alcance_passthrough_aplicado,
        retroalimentacion_semantica_gis=retroalimentacion_semantica_gis,
        recomendacion_fallback_aplicado=recomendacion_fallback_aplicado,
        recomendacion_turistica=recomendacion_turistica,
        sugerencias_exploracion=sugerencias_exploracion,
        tiempo_ms=tiempo_ms,
        mensaje=mensaje,
    )
