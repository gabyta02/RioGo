import asyncio
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
from time import perf_counter
import traceback

CHATBOOT_ROOT = Path(__file__).resolve().parents[1]
APPLICATION_MAIN = CHATBOOT_ROOT / " application" / "main.py"
ENV_FILE = CHATBOOT_ROOT / ".env"

if str(CHATBOOT_ROOT) not in sys.path:
    sys.path.insert(0, str(CHATBOOT_ROOT))

from dotenv import load_dotenv

load_dotenv(ENV_FILE)

from infrastructure.config import get_settings
from infrastructure.config.settings import get_settings as _get_settings_cached
from infrastructure.memory.client import estado_fallback, leer_valor, obtener_cliente_redis
from infrastructure.memory.repository import cargar_memoria


def cargar_application_main():
    spec = importlib.util.spec_from_file_location(
        "chatboot_application_main",
        APPLICATION_MAIN,
    )
    if spec is None or spec.loader is None:
        raise RuntimeError(f"No se pudo cargar {APPLICATION_MAIN}")

    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def imprimir_json(titulo: str, data) -> None:
    print(f"\n{titulo}:")
    print(json.dumps(data, ensure_ascii=False, indent=2))


def imprimir_config_llm() -> None:
    settings = get_settings()
    exploracion = settings.llm.routes["exploracion"]
    provider = settings.llm.providers["deepseek"]

    print("\n--- Config LLM exploracion ---")
    print(f"modelo: {exploracion.model or settings.llm.default_model}")
    print(f"stream: {exploracion.stream}")
    print(f"stream_thinking: {exploracion.stream_thinking}")
    print(
        "thinking_enabled: "
        f"{exploracion.thinking_enabled if exploracion.thinking_enabled is not None else provider.thinking_enabled}"
    )
    print(f"sdk: {provider.sdk}")
    print(f"base_url: {provider.base_url}")


def _clave_memoria(sesion_id: str) -> str:
    settings = get_settings().memory
    return f"{settings.key_prefix}:{sesion_id}"


def _obtener_ttl_redis(clave: str) -> int | None:
    redis = obtener_cliente_redis()
    if redis is None:
        return None

    try:
        ttl = redis.ttl(clave)
        return int(ttl) if ttl is not None else None
    except Exception:
        return None


def _leer_memoria_desde_docker(clave: str) -> str | None:
    try:
        resultado = subprocess.run(
            ["docker", "exec", "redis-chatboot", "redis-cli", "GET", clave],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except Exception:
        return None

    if resultado.returncode != 0:
        return None

    valor = resultado.stdout.strip()
    if not valor or valor == "(nil)":
        return None

    return valor


def imprimir_memoria_redis(sesion_id: str) -> None:
    clave = _clave_memoria(sesion_id)
    memoria = cargar_memoria(sesion_id)
    redis_info = estado_fallback()
    raw_local = leer_valor(clave)
    raw_docker = _leer_memoria_desde_docker(clave)

    print("\n--- Memoria Redis ---")
    print(f"sesion_id: {sesion_id}")
    print(f"clave: {clave}")
    print(f"redis_disponible: {redis_info['redis_disponible']}")

    if raw_local:
        print("origen_lectura: cliente Redis local")
    elif raw_docker:
        print("origen_lectura: docker exec redis-chatboot")
    else:
        print("origen_lectura: memoria vacía o fallback del proceso")

    if not redis_info["redis_disponible"]:
        print("modo_almacenamiento_local: fallback en memoria del proceso")
        if redis_info["claves_fallback"]:
            print(f"claves_fallback: {redis_info['claves_fallback']}")
        if raw_docker:
            print("nota: Redis del contenedor sí tiene datos; agrega REDIS_URL=redis://127.0.0.1:6379/0 en chatboot/.env y publica el puerto 6379")

    ttl = _obtener_ttl_redis(clave)
    if ttl is not None:
        if ttl < 0:
            print("ttl_segundos: sin expiración o clave inexistente en cliente local")
        else:
            print(f"ttl_segundos: {ttl}")

    imprimir_json("contenido_memoria", memoria)

    if raw_docker and not raw_local:
        try:
            imprimir_json("contenido_redis_contenedor", json.loads(raw_docker))
        except json.JSONDecodeError:
            print("\ncontenido_redis_contenedor (raw):")
            print(raw_docker)


class ConsolaStream:
    def __init__(self) -> None:
        self.eventos: list[dict] = []
        self.chunks_pensamiento = 0
        self._pensamiento_abierto = False

    async def emitir(self, mensaje: dict) -> None:
        self.eventos.append(mensaje)
        if mensaje.get("tipo") != "stream":
            return

        contenido = mensaje.get("mensaje", {})
        fase = contenido.get("fase")

        if fase == "inicio":
            print("\n--- STREAM ---")
            print(
                f"[{contenido.get('estado')}] "
                f"{contenido.get('mensaje', '')}"
            )
            return

        if fase == "thinking":
            if not self._pensamiento_abierto:
                etiqueta = "[pensando del LLM] "
                if contenido.get("sintetico"):
                    etiqueta = "[pensando] "
                print(etiqueta, end="", flush=True)
                self._pensamiento_abierto = True
            self.chunks_pensamiento += 1
            print(contenido.get("contenido", ""), end="", flush=True)
            return

        if fase == "fin_thinking":
            if self._pensamiento_abierto:
                print()
                self._pensamiento_abierto = False
            print(
                f"[{contenido.get('estado')}] "
                f"{contenido.get('mensaje', '')}"
            )
            print("--- FIN STREAM ---\n")
            return

        imprimir_json("stream", contenido)


async def clasificar_texto_async(
    application_main,
    texto: str,
    contador: int,
    sesion_id: str | None = None,
) -> str | None:
    _get_settings_cached.cache_clear()

    payload = {
        "sesion_id": sesion_id,
        "mensaje": texto,
        "ubicacion_usuario": {
            "lat": -1.673,
            "lng": -78.648,
        },
        "client_menssaje_id": f"clasificacion-console-{contador}",
    }

    consola_stream = ConsolaStream()
    inicio = perf_counter()
    state = await application_main.procesar_mensaje_async(
        "exploracion",
        json.dumps(payload, ensure_ascii=False),
        stream_emit=consola_stream.emitir,
    )
    duracion = perf_counter() - inicio

    sesion_actual = state.get("sesion_id")
    exploracion = state.get("metadata_utilidades", {}).get("chatboot_exploracion", {})
    construir_plan = exploracion.get("metadata", {}).get("construir_plan", {})

    if not consola_stream.eventos:
        print("\n--- STREAM ---")
        print("No se emitieron eventos stream (revisa stream=true y _stream_emit).")
        print("--- FIN STREAM ---\n")

    print(f"Tiempo de clasificación: {duracion:.2f} segundos")
    print(f"eventos_stream: {len(consola_stream.eventos)}")
    print(f"chunks_pensamiento: {consola_stream.chunks_pensamiento}")

    imprimir_json("Enrutamiento DeepSeek", construir_plan.get("plan"))

    print("\nFormato válido:")
    print(construir_plan.get("plan_valido"))

    imprimir_json("Errores de formato", construir_plan.get("errores_formato", []))

    mensajes = state.get("mensajes_empaquetados", [])
    cards = [mensaje for mensaje in mensajes if mensaje.get("tipo") == "cards"]
    if cards:
        imprimir_json("Mensaje cards", cards[-1].get("mensaje", {}))

    if sesion_actual:
        imprimir_memoria_redis(sesion_actual)

    return sesion_actual


def clasificar_texto(
    application_main,
    texto: str,
    contador: int,
    sesion_id: str | None = None,
) -> str | None:
    return asyncio.run(
        clasificar_texto_async(application_main, texto, contador, sesion_id)
    )


def main() -> None:
    imprimir_config_llm()

    texto = " ".join(sys.argv[1:]).strip()
    application_main = cargar_application_main()

    if texto:
        clasificar_texto(application_main, texto, 1)
        return

    print("\nEscribe una consulta para clasificar.")
    print("Comandos: /salir  /nueva_sesion  /memoria")
    contador = 1
    sesion_id: str | None = None

    while True:
        texto = input("\nTexto para clasificar: ").strip()
        if texto.casefold() == "/salir":
            print("Saliendo.")
            return
        if texto.casefold() == "/nueva_sesion":
            sesion_id = None
            print("Nueva conversación: el próximo mensaje creará un sesion_id nuevo.")
            continue
        if texto.casefold() == "/memoria":
            if not sesion_id:
                print("Aún no hay sesion_id en esta consola. Envía un mensaje primero.")
                continue
            imprimir_memoria_redis(sesion_id)
            continue
        if not texto:
            print("No ingresaste texto.")
            continue

        try:
            sesion_id = clasificar_texto(application_main, texto, contador, sesion_id)
            contador += 1
        except Exception as exc:
            print("\nError al clasificar:")
            print(str(exc))
            print("\nDetalle técnico:")
            traceback.print_exc(limit=3)


if __name__ == "__main__":
    main()
