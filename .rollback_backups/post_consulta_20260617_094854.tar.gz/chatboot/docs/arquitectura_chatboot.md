# Arquitectura Chatboot

## Resumen

`chatboot` expone dos websockets públicos:

- `wss://riobambatour.org/ws/sitio`
- `wss://riobambatour.org/ws/exploracion`

Ambos entran por FastAPI y terminan delegando el procesamiento a la capa `application`, donde existe un flujo compartido de utilidades previas al chatbot final.

## Flujo actual

1. El frontend envía un JSON con esta estructura:

```json
{
  "sesion_id": null,
  "mensaje": "hola",
  "ubicacion_usuario": "Riobamba",
  "client_menssaje_id": "abc-123"
}
```

2. El websocket recibe el texto JSON y lo entrega a `application/main.py`.
3. `application/main.py`:
   - valida el payload
   - crea `sesion_id` si llega `null`
   - reutiliza `sesion_id` si ya existe
   - identifica el destino (`chatboot_sitio` o `chatboot_exploracion`)
   - construye el estado inicial compartido
4. El estado entra al flujo `shared`.
5. El flujo `shared` ejecuta las utilidades en este orden:
   - `limpieza`
   - `promp_inyection`
   - `inyectar_palabra`
6. Si una utilidad bloquea el mensaje, el flujo termina ahí.
7. Si no bloquea, el flujo continúa hacia la siguiente utilidad.

## Estado Compartido

El flujo usa `SharedState` como contrato común. Hoy incluye:

- `destino`
- `canal`
- `sesion_id`
- `client_message_id`
- `ubicacion_usuario`
- `mensaje_original`
- `mensaje_actual`
- `mensaje_limpio`
- `bloqueado`
- `motivo_bloqueo`
- `respuesta_final`
- `respuesta_generada_por`
- `mensajes_empaquetados`
- `utilities_ejecutadas`
- `metadata_utilidades`

Esto permite que cada utilidad lea y escriba sobre una misma estructura sin acoplarse a websockets ni a un proveedor LLM concreto.

## Websocket y API

- `api/main.py` registra las rutas websocket.
- `api/routes/websocket_routes.py` publica `/ws/sitio` y `/ws/exploracion`.
- `api/websockets/chat_handler.py`:
  - acepta la conexión
  - recibe el payload del frontend
  - carga `application/main.py`
  - ejecuta el flujo
  - envía de regreso los mensajes empaquetados

## Application

La carpeta real es `chatboot/ application` y actualmente contiene:

- `main.py`: punto de entrada del procesamiento de mensajes
- `shared/`: utilidades transversales
- `chatboot_sitio/`: reservado para lógica específica del chatbot de sitio
- `chatboot_exploracion/`: reservado para lógica específica del chatbot de exploración

## Utilidades Shared

### `limpieza`

Primera barrera del sistema. Se encarga de:

- normalizar el texto
- expandir contracciones
- filtrar ruido
- bloquear entradas sospechosas
- devolver un mensaje limpio o una respuesta de bloqueo

Su configuración vive en:

- `infrastructure/config/settings.json`
- `data/limpieza_data.json`

### `promp_inyection`

Segunda barrera del sistema. Evalúa intentos de:

- ignorar instrucciones
- revelar prompts internos
- modificar reglas del sistema
- aplicar técnicas de jailbreak

También contempla penalizaciones para consultas técnicas legítimas, para no bloquear falsos positivos.

Su configuración vive en:

- `infrastructure/config/settings.json`
- `data/promp_inyection.json`

### `inyectar_palabra`

Actualmente es un paso neutro. Queda reservado para enriquecer el mensaje antes de pasar al chatbot final.

## Empaquetado de mensajes

La salida hacia frontend se construye desde `shared/construir_mensaje.py`.

Hoy soporta estas estructuras:

- `globo`
- `cards`
- `stream`

Formato base de `globo`:

```json
{
  "tipo": "globo",
  "client_message_id": "abc-123",
  "sesion_id": "uuid-o-sesion-existente",
  "mensaje": {
    "contenido": "texto de salida"
  }
}
```

Cada utilidad puede empaquetar sus propias respuestas, pero la forma final del mensaje se centraliza en `construir_mensaje.py`.

## Configuración

La capa `infrastructure/config` concentra configuración tipada de la app:

- proveedores y modelos LLM
- herramientas shared
- parámetros de validación

Los secretos viven en `.env`.

## Regla de diseño actual

- `api` recibe tráfico
- `application` orquesta casos de uso
- `shared` ejecuta validaciones/utilidades comunes
- `infrastructure` resuelve configuración y adaptadores externos
- `data` guarda reglas declarativas y patrones

La idea es que las siguientes utilidades y chatbots reutilicen esta misma base sin redefinir el protocolo de entrada, el estado ni el formato de salida.
