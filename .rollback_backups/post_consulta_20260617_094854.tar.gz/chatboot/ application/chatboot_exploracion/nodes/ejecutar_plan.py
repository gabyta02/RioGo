import sys
from pathlib import Path

UTILITES_DIR = Path(__file__).resolve().parents[1] / "utilites"
SHARED_DIR = Path(__file__).resolve().parents[2] / "shared"

for path in (UTILITES_DIR, SHARED_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from construir_mensaje import construir_cards, construir_globo, construir_respuesta_herramienta
from ejecutar_plan_tools import ejecutar_plan

HERRAMIENTAS_FRONTEND = {"conversacional", "pregunta_directa", "fallback"}


def _empaquetar_salida_frontend(resultado: dict) -> list[dict]:
    mensajes: list[dict] = []

    for globo in resultado.get("globos", []):
        mensajes.append(
            {
                "tipo": "globo",
                "client_message_id": resultado["client_message_id"],
                "sesion_id": resultado["session_id"],
                "mensaje": globo,
            }
        )

    tarjetas = resultado.get("tarjetas", [])
    tarjetas_rutas = resultado.get("tarjetas_rutas", [])
    respuesta_api = resultado.get("respuesta_api", {})
    sin_tarjetas_finales = not tarjetas and not tarjetas_rutas
    retroalimentacion = respuesta_api.get("retroalimentacion_semantica_gis")
    recomendacion = respuesta_api.get("recomendacion_turistica")
    sugerencias = respuesta_api.get("sugerencias_exploracion") or []

    if retroalimentacion:
        mensajes.append(
            construir_globo(
                client_message_id=resultado["client_message_id"],
                sesion_id=resultado["session_id"],
                contenido=retroalimentacion,
            )
        )

    if recomendacion:
        mensajes.append(
            construir_globo(
                client_message_id=resultado["client_message_id"],
                sesion_id=resultado["session_id"],
                contenido=recomendacion,
            )
        )

    if sin_tarjetas_finales and sugerencias:
        mensajes.append(
            {
                "tipo": "globo",
                "client_message_id": resultado["client_message_id"],
                "sesion_id": resultado["session_id"],
                "mensaje": {
                    "contenido": respuesta_api.get("mensaje")
                    or "No encontré sitios que coincidan con tu búsqueda.",
                    "opciones": sugerencias,
                },
            }
        )
    elif sin_tarjetas_finales and respuesta_api.get("ok") is False:
        mensajes.append(
            construir_globo(
                client_message_id=resultado["client_message_id"],
                sesion_id=resultado["session_id"],
                contenido=respuesta_api.get("mensaje")
                or "No se encontraron sitios relacionados con tu consulta.",
            )
        )

    candidatos_semanticos = respuesta_api.get("candidatos_semanticos", [])
    if tarjetas or tarjetas_rutas or candidatos_semanticos:
        mensajes.append(
            construir_cards(
                client_message_id=resultado["client_message_id"],
                sesion_id=resultado["session_id"],
                contenido={
                    "tarjetas": tarjetas,
                    "tarjetas_rutas": tarjetas_rutas,
                    "sitios_relacionados": respuesta_api.get(
                        "sitios_relacionados", []
                    ),
                    "candidatos_semanticos": candidatos_semanticos,
                    "semantic_fallback_aplicado": respuesta_api.get(
                        "semantic_fallback_aplicado", False
                    ),
                    "gis_fallback_mapa_aplicado": respuesta_api.get(
                        "gis_fallback_mapa_aplicado", False
                    ),
                    "recomendacion_fallback_aplicado": respuesta_api.get(
                        "recomendacion_fallback_aplicado", False
                    ),
                    "recomendacion_turistica": recomendacion,
                    "sugerencias_exploracion": sugerencias,
                    "retroalimentacion_semantica_gis": retroalimentacion,
                    "respuesta_api": respuesta_api,
                },
            )
        )

    for ejecucion in resultado.get("resultados_ejecucion_interna", []):
        if ejecucion.get("herramienta") not in HERRAMIENTAS_FRONTEND:
            continue
        sub_herramientas = ejecucion.get("sub_herramientas") or []
        if not sub_herramientas:
            continue
        salida = sub_herramientas[0]
        if salida in resultado.get("globos", []):
            continue
        mensajes.append(
            construir_respuesta_herramienta(
                client_message_id=resultado["client_message_id"],
                sesion_id=resultado["session_id"],
                herramienta=salida["herramienta"],
                mensaje=salida["mensaje"],
                id_sitio=salida.get("id_sitio"),
            )
        )
    return mensajes


async def nodo_ejecutar_plan(state: dict) -> dict:
    if not state.get("plan_valido") or not state.get("plan"):
        metadata = {
            **state.get("metadata", {}),
            "ejecutar_plan": {"omitido": True, "motivo": "plan_invalido_o_ausente"},
        }
        return {**state, "metadata": metadata}

    resultado = await ejecutar_plan(state)
    mensajes = list(resultado.get("mensajes_empaquetados", []))
    mensajes.extend(_empaquetar_salida_frontend(resultado))

    metadata = {
        **resultado.get("metadata", {}),
        "ejecutar_plan": {
            **resultado.get("metadata", {}).get("ejecutar_plan", {}),
            "resultados_ejecucion": resultado.get("resultados_ejecucion", []),
            "resultados": resultado.get("resultados", {}),
        },
    }

    return {
        **resultado,
        "mensajes_empaquetados": mensajes,
        "metadata": metadata,
    }
