const STORAGE_KEY = "bootrio-debug-exploracion";

const els = {
  wsUrl: document.getElementById("wsUrl"),
  sesionId: document.getElementById("sesionId"),
  lat: document.getElementById("lat"),
  lng: document.getElementById("lng"),
  mensaje: document.getElementById("mensaje"),
  btnEnviar: document.getElementById("btnEnviar"),
  btnLimpiar: document.getElementById("btnLimpiar"),
  btnCopiarTimeline: document.getElementById("btnCopiarTimeline"),
  connectionStatus: document.getElementById("connectionStatus"),
  streamFase: document.getElementById("streamFase"),
  streamStatus: document.getElementById("streamStatus"),
  streamThinking: document.getElementById("streamThinking"),
  planBadge: document.getElementById("planBadge"),
  planErrores: document.getElementById("planErrores"),
  planJson: document.getElementById("planJson"),
  respuestasList: document.getElementById("respuestasList"),
  respuestasCount: document.getElementById("respuestasCount"),
  timeline: document.getElementById("timeline"),
  metricLatencia: document.getElementById("metricLatencia"),
  metricHastaGlobo: document.getElementById("metricHastaGlobo"),
  metricHastaCards: document.getElementById("metricHastaCards"),
  metricApiTiempo: document.getElementById("metricApiTiempo"),
  metricEventos: document.getElementById("metricEventos"),
  metricStream: document.getElementById("metricStream"),
  metricThinking: document.getElementById("metricThinking"),
  metricPlanValido: document.getElementById("metricPlanValido"),
  metricFallback: document.getElementById("metricFallback"),
  metricSesion: document.getElementById("metricSesion"),
  streamHint: document.getElementById("streamHint"),
  ejemplos: document.getElementById("ejemplos"),
};

const state = {
  ws: null,
  busy: false,
  inicioEnvio: 0,
  eventos: 0,
  streamEventos: 0,
  thinkingChars: 0,
  timeline: [],
  respuestas: 0,
  esperandoRespuesta: false,
  finalizarTimer: null,
  tiempos: {
    inicio: 0,
    primerGlobo: null,
    cardsSitios: null,
  },
  fallbackResumen: null,
};

function cargarPreferencias() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return;
    const prefs = JSON.parse(raw);
    if (prefs.wsUrl) els.wsUrl.value = prefs.wsUrl;
    if (prefs.sesionId) els.sesionId.value = prefs.sesionId;
    if (prefs.lat) els.lat.value = prefs.lat;
    if (prefs.lng) els.lng.value = prefs.lng;
  } catch {
    /* ignorar */
  }
}

function guardarPreferencias() {
  localStorage.setItem(
    STORAGE_KEY,
    JSON.stringify({
      wsUrl: els.wsUrl.value,
      sesionId: els.sesionId.value,
      lat: els.lat.value,
      lng: els.lng.value,
    }),
  );
}

function setConnection(mode, label) {
  els.connectionStatus.className = `connection ${mode}`;
  els.connectionStatus.querySelector(".label").textContent = label;
}

function resetVista() {
  state.eventos = 0;
  state.streamEventos = 0;
  state.thinkingChars = 0;
  state.timeline = [];
  state.respuestas = 0;
  els.streamHint.hidden = true;

  if (state.finalizarTimer) {
    clearTimeout(state.finalizarTimer);
    state.finalizarTimer = null;
  }

  els.streamFase.textContent = "esperando";
  els.streamStatus.textContent = "";
  els.streamThinking.textContent = "";
  els.planBadge.textContent = "—";
  els.planBadge.className = "badge";
  els.planErrores.hidden = true;
  els.planErrores.textContent = "";
  els.planJson.textContent = "{}";
  els.respuestasList.innerHTML = "";
  els.respuestasCount.textContent = "0";
  els.timeline.innerHTML = "";
  els.metricLatencia.textContent = "—";
  els.metricHastaGlobo.textContent = "—";
  els.metricHastaCards.textContent = "—";
  els.metricApiTiempo.textContent = "—";
  els.metricFallback.textContent = "—";
  els.metricEventos.textContent = "0";
  els.metricStream.textContent = "0";
  els.metricThinking.textContent = "0 chars";
  els.metricPlanValido.textContent = "—";
  state.tiempos = { inicio: 0, primerGlobo: null, cardsSitios: null };
  state.fallbackResumen = null;
}

function formatoSegundos(ms) {
  if (ms == null) return "—";
  return `${(ms / 1000).toFixed(2)}s`;
}

function textoGlobo(contenido) {
  if (!contenido) return "";
  if (typeof contenido.mensaje === "string") return contenido.mensaje;
  if (typeof contenido.contenido === "string") return contenido.contenido;
  return "";
}

function extraerRespuestaApi(contenido) {
  return contenido?.respuesta_api || contenido || {};
}

function analizarFallback(contenido) {
  const api = extraerRespuestaApi(contenido);
  const dinamicos = (contenido?.tarjetas || [])
    .map((t) => t.campos_dinamicos || {})
    .filter((d) => Object.keys(d).length > 0);

  const passthroughPasos = [
    ...new Set(
      dinamicos
        .map((d) => d.filtro_passthrough)
        .filter(Boolean),
    ),
  ];
  const recomendacionTarjetas = dinamicos.some((d) => d.recomendacion_fallback);

  return {
    api,
    recomendacion_fallback_aplicado:
      contenido?.recomendacion_fallback_aplicado
      || api.recomendacion_fallback_aplicado
      || recomendacionTarjetas,
    recomendacion_turistica:
      contenido?.recomendacion_turistica
      || api.recomendacion_turistica
      || dinamicos.find((d) => d.recomendacion_turistica)?.recomendacion_turistica
      || null,
    sugerencias_exploracion:
      contenido?.sugerencias_exploracion
      || api.sugerencias_exploracion
      || [],
    semantic_fallback_aplicado:
      contenido?.semantic_fallback_aplicado
      || api.semantic_fallback_aplicado
      || false,
    gis_fallback_mapa_aplicado:
      contenido?.gis_fallback_mapa_aplicado
      || api.gis_fallback_mapa_aplicado
      || false,
    retroalimentacion_semantica_gis:
      contenido?.retroalimentacion_semantica_gis
      || api.retroalimentacion_semantica_gis
      || null,
    filtro_passthrough_aplicado:
      api.filtro_passthrough_aplicado
      || passthroughPasos.length > 0,
    passthrough_pasos: passthroughPasos,
    tiempo_ms: api.tiempo_ms,
    ok: api.ok,
    mensaje_api: api.mensaje,
  };
}

function crearBannerFallback(clase, titulo, cuerpo) {
  const banner = document.createElement("div");
  banner.className = `fallback-banner ${clase}`;
  banner.innerHTML = `<strong>${titulo}</strong><p>${cuerpo}</p>`;
  return banner;
}

function crearOpcionesExploracion(opciones, onClick) {
  const opcionesDiv = document.createElement("div");
  opcionesDiv.className = "opciones-globo";
  opciones.forEach((opcion) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "btn-opcion";
    btn.textContent = opcion;
    btn.onclick = () => onClick(opcion);
    opcionesDiv.appendChild(btn);
  });
  return opcionesDiv;
}

function renderPanelFallback(contenido, host) {
  const fb = analizarFallback(contenido);
  state.fallbackResumen = fb;

  if (fb.tiempo_ms != null) {
    els.metricApiTiempo.textContent = `${fb.tiempo_ms} ms`;
  }

  const flags = [];
  if (fb.recomendacion_fallback_aplicado) flags.push("recomendación cálida");
  if (fb.sugerencias_exploracion?.length) flags.push("fallback frío");
  if (fb.semantic_fallback_aplicado) flags.push("semántica");
  if (fb.gis_fallback_mapa_aplicado) flags.push("GIS mapa");
  if (fb.filtro_passthrough_aplicado) flags.push("passthrough");
  els.metricFallback.textContent = flags.length ? flags.join(" · ") : "ninguno";

  const panel = document.createElement("div");
  panel.className = "fallback-panel";

  if (fb.recomendacion_turistica) {
    panel.appendChild(
      crearBannerFallback(
        "recomendacion",
        "Recomendación turística",
        fb.recomendacion_turistica,
      ),
    );
  }

  if (fb.retroalimentacion_semantica_gis) {
    panel.appendChild(
      crearBannerFallback(
        "gis-semantica",
        "Retroalimentación semántica + GIS",
        fb.retroalimentacion_semantica_gis,
      ),
    );
  }

  if (fb.recomendacion_fallback_aplicado && !fb.recomendacion_turistica) {
    panel.appendChild(
      crearBannerFallback(
        "warn",
        "Recomendación cálida sin mensaje",
        "La API marcó recomendacion_fallback_aplicado pero no envió recomendacion_turistica.",
      ),
    );
  }

  if (fb.filtro_passthrough_aplicado && !fb.recomendacion_fallback_aplicado) {
    const pasos = fb.passthrough_pasos.length
      ? fb.passthrough_pasos.join(", ")
      : "H3–H7";
    panel.appendChild(
      crearBannerFallback(
        "passthrough",
        "Filtro omitido (passthrough)",
        `Paso(s) ${pasos} llegaron sin criterio de filtrado. Se conservaron los IDs previos pero no aplica recomendación cálida. Para ver el globo de “no encontré económicos…”, el plan debe incluir criterio explícito (p. ej. etiqueta: economico en precio).`,
      ),
    );
  }

  if (
    fb.sugerencias_exploracion?.length
    && !(contenido?.tarjetas || []).length
    && !(contenido?.tarjetas_rutas || []).length
  ) {
    panel.appendChild(
      crearBannerFallback(
        "frio",
        "Fallback en frío",
        fb.mensaje_api
          || "No hubo alcance previo. Explora estas categorías:",
      ),
    );
    panel.appendChild(
      crearOpcionesExploracion(fb.sugerencias_exploracion, (opcion) => {
        els.mensaje.value = opcion;
        enviarMensaje();
      }),
    );
  }

  const meta = document.createElement("pre");
  meta.className = "fallback-meta";
  meta.textContent = JSON.stringify(
    {
      ok: fb.ok,
      recomendacion_fallback_aplicado: fb.recomendacion_fallback_aplicado,
      filtro_passthrough_aplicado: fb.filtro_passthrough_aplicado,
      semantic_fallback_aplicado: fb.semantic_fallback_aplicado,
      gis_fallback_mapa_aplicado: fb.gis_fallback_mapa_aplicado,
      sugerencias_exploracion: fb.sugerencias_exploracion,
      tiempo_ms: fb.tiempo_ms,
    },
    null,
    2,
  );
  panel.appendChild(meta);

  if (panel.childNodes.length) {
    host.prepend(panel);
  }
}

function registrarTiemposMensaje(msg) {
  const ahora = performance.now();
  if (!state.tiempos.inicio) return;

  if (msg.tipo === "globo" && state.tiempos.primerGlobo == null) {
    state.tiempos.primerGlobo = ahora - state.tiempos.inicio;
    els.metricHastaGlobo.textContent = formatoSegundos(state.tiempos.primerGlobo);
  }

  const contenido = msg.mensaje || {};
  const esCardsSitios =
    msg.tipo === "cards"
    && !contenido.plan
    && ((contenido.tarjetas && contenido.tarjetas.length > 0)
      || (contenido.tarjetas_rutas && contenido.tarjetas_rutas.length > 0));

  if (esCardsSitios && state.tiempos.cardsSitios == null) {
    state.tiempos.cardsSitios = ahora - state.tiempos.inicio;
    els.metricHastaCards.textContent = formatoSegundos(state.tiempos.cardsSitios);
    const fb = analizarFallback(contenido);
    if (fb.tiempo_ms != null) {
      els.metricApiTiempo.textContent = `${fb.tiempo_ms} ms`;
    }
  }
}

function actualizarMetricas() {
  els.metricEventos.textContent = String(state.eventos);
  els.metricStream.textContent = String(state.streamEventos);
  els.metricThinking.textContent = `${state.thinkingChars} chars`;
  els.respuestasCount.textContent = String(state.respuestas);
}

function horaLocal() {
  return new Date().toLocaleTimeString("es-EC", { hour12: false });
}

function resumirEvento(msg) {
  const tipo = msg.tipo || "desconocido";
  const contenido = msg.mensaje || {};

  if (tipo === "stream") {
    const fase = contenido.fase || "?";
    if (fase === "thinking") return `thinking: ${(contenido.contenido || "").slice(0, 80)}`;
    return `${fase}: ${contenido.mensaje || contenido.estado || ""}`;
  }

  if (tipo === "globo") {
    if (contenido.herramienta) {
      return `${contenido.herramienta}: ${textoGlobo(contenido).slice(0, 100)}`;
    }
    const opciones = contenido.opciones?.length
      ? ` · ${contenido.opciones.length} opciones`
      : "";
    return `${textoGlobo(contenido).slice(0, 100)}${opciones}`;
  }

  if (tipo === "cards") {
    if (contenido.plan) return `plan · válido=${contenido.plan_valido}`;
    const fb = analizarFallback(contenido);
    const partes = ["cards"];
    if (fb.recomendacion_fallback_aplicado) partes.push("recom");
    if (fb.filtro_passthrough_aplicado) partes.push("passthrough");
    if (fb.sugerencias_exploracion?.length) partes.push("frío");
    return partes.join(" · ");
  }

  return JSON.stringify(contenido).slice(0, 100);
}

function agregarTimeline(msg) {
  state.eventos += 1;
  state.timeline.push({ t: Date.now(), msg });

  const item = document.createElement("div");
  item.className = "timeline-item";
  item.innerHTML = `
    <span class="hora">${horaLocal()}</span>
    <span class="tipo-tag ${msg.tipo || ""}">${msg.tipo || "?"}</span>
    <span class="resumen"></span>
  `;
  item.querySelector(".resumen").textContent = resumirEvento(msg);
  els.timeline.prepend(item);
  actualizarMetricas();
}

function renderRespuesta(msg) {
  state.respuestas += 1;
  const card = document.createElement("article");
  card.className = "respuesta-card";

  const tipo = document.createElement("span");
  tipo.className = `tipo ${msg.tipo}`;
  tipo.textContent = msg.tipo;
  card.appendChild(tipo);

  const contenido = msg.mensaje || {};
  const texto = document.createElement("div");
  texto.className = "texto";

  if (msg.tipo === "globo") {
    const cuerpo = textoGlobo(contenido);
    if (cuerpo) {
      texto.textContent = cuerpo;
      card.appendChild(texto);
    }
    
    if (contenido.herramienta) {
      const meta = document.createElement("pre");
      meta.textContent = [
        `herramienta: ${contenido.herramienta}`,
        contenido.id_sitio ? `id_sitio: ${contenido.id_sitio}` : null,
      ]
        .filter(Boolean)
        .join("\n");
      card.appendChild(meta);
    }
    
    if (contenido.opciones && contenido.opciones.length > 0) {
      card.appendChild(
        crearOpcionesExploracion(contenido.opciones, (opcion) => {
          els.mensaje.value = opcion;
          enviarMensaje();
        }),
      );
    }
    
    els.respuestasList.appendChild(card);
    return;
  } else if (msg.tipo === "cards" && contenido.plan) {
    texto.textContent = "Plan del clasificador recibido (ver panel Plan)";
  } else if (msg.tipo === "cards" && (contenido.tarjetas || contenido.tarjetas_rutas || contenido.candidatos_semanticos?.length)) {
    renderPanelFallback(contenido, card);

    const tarjetasDiv = document.createElement("div");
    tarjetasDiv.className = "tarjetas-container";
    
    if (contenido.tarjetas && contenido.tarjetas.length > 0) {
      const title = document.createElement("h4");
      title.textContent = "Sitios Turísticos";
      tarjetasDiv.appendChild(title);
      
      contenido.tarjetas.forEach(t => {
        const tCard = document.createElement("div");
        tCard.className = "tarjeta-item";
        const dinamicos = t.campos_dinamicos || {};
        const tieneDinamicos = Object.keys(dinamicos).length > 0;
        const precio = t.precio
          ? [
              t.precio.fuente ? `fuente: ${t.precio.fuente}` : null,
              t.precio.precio != null ? `$${t.precio.precio}` : null,
              t.precio.precio_min != null || t.precio.precio_max != null
                ? `$${t.precio.precio_min ?? "?"} - $${t.precio.precio_max ?? "?"}`
                : null,
              t.precio.etiqueta_precio ? `(${t.precio.etiqueta_precio})` : null,
              t.precio.condicion ? `condición: ${t.precio.condicion}` : null,
            ].filter(Boolean).join(" · ")
          : "";
        const contacto = t.contacto
          ? `${t.contacto.tipo || "contacto"}: ${t.contacto.contenido || ""}`
          : "";
        tCard.innerHTML = `
          ${t.imagen ? `<img class="tarjeta-img" src="${t.imagen}" alt="${t.nombre}" loading="lazy">` : ""}
          <div class="tarjeta-body">
            <strong>${t.nombre}</strong>
            ${t.subcategoria ? `<div class="subcat">${t.subcategoria}</div>` : ""}
            ${t.direccion ? `<div class="tarjeta-row">📍 ${t.direccion}</div>` : ""}
            ${contacto ? `<div class="tarjeta-row">☎ ${contacto}</div>` : ""}
            ${precio ? `<div class="tarjeta-row">💵 ${precio}</div>` : ""}
            ${tieneDinamicos ? `<pre>${JSON.stringify(dinamicos, null, 2)}</pre>` : ""}
          </div>
        `;
        tarjetasDiv.appendChild(tCard);
      });
    }
    
    if (contenido.tarjetas_rutas && contenido.tarjetas_rutas.length > 0) {
      const title = document.createElement("h4");
      title.textContent = "Rutas Turísticas";
      tarjetasDiv.appendChild(title);
      
      contenido.tarjetas_rutas.forEach(t => {
        const tCard = document.createElement("div");
        tCard.className = "tarjeta-item";
        tCard.innerHTML = `
          <strong>${t.titulo}</strong>
          <div class="subcat">${t.tipo_ruta}</div>
          <pre>${JSON.stringify(t.campos_dinamicos || {}, null, 2)}</pre>
        `;
        tarjetasDiv.appendChild(tCard);
      });
    }

    const sitiosRelacionados = contenido.sitios_relacionados || [];
    if (sitiosRelacionados.length > 0) {
      const relacionadosDiv = document.createElement("div");
      relacionadosDiv.className = "sitios-relacionados";
      relacionadosDiv.innerHTML = `
        <strong>Sitios relacionados (${sitiosRelacionados.length})</strong>
        <div class="ids-relacionados">${sitiosRelacionados.join(", ")}</div>
      `;
      tarjetasDiv.appendChild(relacionadosDiv);
    }

    const candidatosSemanticos = contenido.candidatos_semanticos || [];
    if (candidatosSemanticos.length > 0) {
      const idsTarjetas = new Set((contenido.tarjetas || []).map(t => t.id_sitio));
      const candidatosDiv = document.createElement("div");
      candidatosDiv.className = "candidatos-semanticos";
      const fallback = [
        contenido.semantic_fallback_aplicado
          ? `<div class="semantic-fallback">La semántica no refinó resultados; se conservaron filtros previos.</div>`
          : "",
        contenido.recomendacion_fallback_aplicado
          ? `<div class="semantic-fallback recomendacion">Recomendación cálida aplicada en la API.</div>`
          : "",
      ].join("");
      candidatosDiv.innerHTML = `
        <h4>Candidatos semánticos (${candidatosSemanticos.length})</h4>
        ${fallback}
        ${candidatosSemanticos.map(c => {
          const enTarjeta = idsTarjetas.has(c.id_sitio);
          const chunk = (c.contenido_chunk || "").replace(/\s+/g, " ").slice(0, 260);
          return `
            <div class="candidato-semantico ${c.supera_umbral ? "ok" : "descartado"}">
              <div class="candidato-head">
                <strong>${c.nombre}</strong>
                <span>ID ${c.id_sitio}</span>
              </div>
              <div class="score-row">
                <span>final: ${Number(c.score_similitud || 0).toFixed(4)}</span>
                <span>embedding: ${Number(c.score_embedding || 0).toFixed(4)}</span>
                <span>keywords: ${Number(c.score_palabras_clave || 0).toFixed(4)}</span>
              </div>
              <div class="estado-candidato">
                ${c.supera_umbral ? "supera umbral" : "descartado por umbral"}
                ${enTarjeta ? " · en tarjeta" : " · no mostrado"}
              </div>
              ${c.palabras_clave_match?.length ? `<div class="keywords">match: ${c.palabras_clave_match.join(", ")}</div>` : ""}
              <div class="chunk-preview">${chunk}${chunk.length >= 260 ? "..." : ""}</div>
            </div>
          `;
        }).join("")}
      `;
      tarjetasDiv.appendChild(candidatosDiv);
    }
    
    card.appendChild(tarjetasDiv);
  } else if (msg.tipo === "cards") {
    renderPanelFallback(contenido, card);
    texto.textContent = JSON.stringify(contenido, null, 2);
  } else {
    texto.textContent = JSON.stringify(contenido, null, 2);
  }

  if (texto.textContent) {
    card.appendChild(texto);
  }
  els.respuestasList.appendChild(card);
}

function procesarStream(msg) {
  state.streamEventos += 1;
  const contenido = msg.mensaje || {};
  const fase = contenido.fase || "desconocido";
  els.streamFase.textContent = fase;

  if (fase === "inicio" || fase === "preparando_consulta") {
    els.streamStatus.textContent = `[${contenido.estado || ""}] ${contenido.mensaje || ""}`;
    return;
  }

  if (fase === "thinking") {
    const delta = contenido.contenido || "";
    state.thinkingChars += delta.length;
    els.streamThinking.textContent += delta;
    els.streamStatus.textContent = contenido.sintetico
      ? "Pensamiento sintético (sin stream del proveedor)"
      : "Recibiendo pensamiento del LLM...";
    actualizarMetricas();
    return;
  }

  if (fase === "fin_thinking") {
    els.streamStatus.textContent = `[${contenido.estado || ""}] ${contenido.mensaje || "Validando plan..."}`;
    return;
  }

  if (fase === "ejecutando_plan" || fase === "fin_ejecucion") {
    els.streamStatus.textContent = `[${contenido.estado || fase}] ${contenido.mensaje || ""}`;
    return;
  }

  els.streamStatus.textContent = JSON.stringify(contenido);
}

function procesarPlan(msg) {
  const contenido = msg.mensaje || {};
  const plan = contenido.plan;
  const valido = contenido.plan_valido;
  const errores = contenido.errores_formato || [];

  els.planJson.textContent = JSON.stringify(plan || contenido, null, 2);
  els.metricPlanValido.textContent = valido === true ? "sí" : valido === false ? "no" : "—";

  if (valido === true) {
    els.planBadge.textContent = "válido";
    els.planBadge.className = "badge ok";
  } else if (valido === false) {
    els.planBadge.textContent = "inválido";
    els.planBadge.className = "badge error";
  } else {
    els.planBadge.textContent = "sin plan";
    els.planBadge.className = "badge warn";
  }

  if (errores.length) {
    els.planErrores.hidden = false;
    els.planErrores.textContent = `Errores: ${JSON.stringify(errores)}`;
  }
}

function cerrarSocket() {
  if (state.ws) {
    state.ws.onopen = null;
    state.ws.onmessage = null;
    state.ws.onerror = null;
    state.ws.onclose = null;
    if (state.ws.readyState === WebSocket.OPEN) {
      state.ws.close();
    }
    state.ws = null;
  }
}

function conectar() {
  return new Promise((resolve, reject) => {
    cerrarSocket();
    const url = els.wsUrl.value.trim();
    const ws = new WebSocket(url);
    state.ws = ws;

    ws.onopen = () => {
      setConnection("connected", "Conectado");
      resolve(ws);
    };

    ws.onerror = () => {
      setConnection("error", "Error de conexión");
      reject(new Error("No se pudo conectar al WebSocket"));
    };

    ws.onclose = () => {
      if (!state.busy) {
        setConnection("", "Desconectado");
      }
    };

    ws.onmessage = (event) => {
      let msg;
      try {
        msg = JSON.parse(event.data);
      } catch {
        agregarTimeline({ tipo: "raw", mensaje: { contenido: event.data } });
        return;
      }

      agregarTimeline(msg);
      registrarTiemposMensaje(msg);

      if (msg.sesion_id) {
        els.sesionId.value = msg.sesion_id;
        els.metricSesion.textContent = msg.sesion_id;
        guardarPreferencias();
      }

      if (msg.tipo === "stream") {
        procesarStream(msg);
      } else if (msg.tipo === "cards" && msg.mensaje?.plan !== undefined) {
        procesarPlan(msg);
        renderRespuesta(msg);
      } else if (msg.tipo === "globo" || msg.tipo === "cards") {
        renderRespuesta(msg);
      }

      if (state.esperandoRespuesta) {
        programarFinalizacion();
      }
    };
  });
}

function programarFinalizacion() {
  if (state.finalizarTimer) {
    clearTimeout(state.finalizarTimer);
  }
  state.finalizarTimer = setTimeout(() => {
    if (!state.esperandoRespuesta) return;
    finalizarTurno();
  }, 1500);
}

function finalizarTurno() {
  const latencia = ((performance.now() - state.inicioEnvio) / 1000).toFixed(2);
  els.metricLatencia.textContent = `${latencia}s`;
  state.busy = false;
  state.esperandoRespuesta = false;
  els.btnEnviar.disabled = false;
  setConnection("connected", "Conectado");
  guardarPreferencias();

  if (state.streamEventos === 0 && state.eventos > 0) {
    els.streamHint.hidden = false;
    els.streamStatus.textContent =
      "Sin eventos stream: el servidor respondió solo con mensajes finales (cards/globo).";
  }
}

async function enviarMensaje() {
  if (state.busy) return;

  const texto = els.mensaje.value.trim();
  if (!texto) return;

  resetVista();
  state.busy = true;
  state.esperandoRespuesta = true;
  state.inicioEnvio = performance.now();
  state.tiempos.inicio = state.inicioEnvio;
  els.btnEnviar.disabled = true;
  setConnection("busy", "Procesando...");

  const payload = {
    sesion_id: els.sesionId.value.trim() || null,
    mensaje: texto,
    ubicacion_usuario: {
      lat: Number(els.lat.value),
      lng: Number(els.lng.value),
    },
    client_menssaje_id: `debug-${Date.now()}`,
  };

  try {
    const ws = state.ws?.readyState === WebSocket.OPEN ? state.ws : await conectar();
    ws.send(JSON.stringify(payload));

    setTimeout(() => {
      if (state.esperandoRespuesta) {
        finalizarTurno();
        els.streamStatus.textContent += " · turno cerrado por timeout (45s)";
      }
    }, 45000);
  } catch (err) {
    state.busy = false;
    state.esperandoRespuesta = false;
    els.btnEnviar.disabled = false;
    setConnection("error", "Error");
    agregarTimeline({
      tipo: "error",
      mensaje: { contenido: String(err.message || err) },
    });
  }
}

els.btnEnviar.addEventListener("click", enviarMensaje);
els.btnLimpiar.addEventListener("click", resetVista);

els.btnCopiarTimeline.addEventListener("click", async () => {
  const data = JSON.stringify(state.timeline, null, 2);
  try {
    await navigator.clipboard.writeText(data);
    els.btnCopiarTimeline.textContent = "Copiado";
    setTimeout(() => {
      els.btnCopiarTimeline.textContent = "Copiar JSON";
    }, 1500);
  } catch {
    /* ignorar */
  }
});

els.ejemplos.addEventListener("click", (event) => {
  const btn = event.target.closest("button[data-msg]");
  if (!btn) return;
  els.mensaje.value = btn.dataset.msg;
});

["wsUrl", "sesionId", "lat", "lng"].forEach((id) => {
  els[id].addEventListener("change", guardarPreferencias);
});

document.addEventListener("keydown", (event) => {
  if ((event.ctrlKey || event.metaKey) && event.key === "Enter") {
    event.preventDefault();
    enviarMensaje();
  }
});

cargarPreferencias();
