from typing import Any

from state import MensajeEmpaquetado


def construir_globo(
    *,
    client_message_id: str,
    sesion_id: str,
    contenido: str,
) -> MensajeEmpaquetado:
    return {
        "tipo": "globo",
        "client_message_id": client_message_id,
        "sesion_id": sesion_id,
        "mensaje": {
            "contenido": contenido,
        },
    }


def construir_cards(
    *,
    client_message_id: str,
    sesion_id: str,
    contenido: dict[str, Any],
) -> MensajeEmpaquetado:
    return {
        "tipo": "cards",
        "client_message_id": client_message_id,
        "sesion_id": sesion_id,
        "mensaje": contenido,
    }


def construir_stream(
    *,
    client_message_id: str,
    sesion_id: str,
    contenido: dict[str, Any],
) -> MensajeEmpaquetado:
    return {
        "tipo": "stream",
        "client_message_id": client_message_id,
        "sesion_id": sesion_id,
        "mensaje": contenido,
    }


def construir_respuesta_herramienta(
    *,
    client_message_id: str,
    sesion_id: str,
    herramienta: str,
    mensaje: str,
    id_sitio: int | None = None,
) -> MensajeEmpaquetado:
    contenido: dict[str, Any] = {
        "herramienta": herramienta,
        "mensaje": mensaje,
    }
    if id_sitio is not None:
        contenido["id_sitio"] = id_sitio
    return {
        "tipo": "globo",
        "client_message_id": client_message_id,
        "sesion_id": sesion_id,
        "mensaje": contenido,
    }
